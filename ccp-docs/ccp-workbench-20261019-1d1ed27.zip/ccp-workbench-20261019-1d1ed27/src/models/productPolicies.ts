// 表 product_policies の、1 行の型と選択肢。列を変えたら、server/schema.json と一緒に直す(scripts/check-schema.mjs が食い違いを見つける)。

/** 書き込める列 */
export interface ProductPolicyFields {
  name: string
  product_code?: string
  policy?: string
  promo_plan?: string
  promo_period?: string
  stage?: string
  state_code?: number
}

/** 読んだ 1 行 */
export interface ProductPolicy extends ProductPolicyFields {
  id: string
  created_on?: string
  modified_on?: string
}
