import type { Product } from './models/products'
import type { HeroImage } from './models/heroImages'
import { askAgent, type AiCard, type CopyLanguage } from './aiSelect'
import { tr } from './i18n'
import { THEME_TYPES, type ThemeType } from './themeTypes'
import { DEFAULT_PUSH_TEMPLATE, hasTemplate, templateOptions, type EmailTemplateId, type TemplateChannel } from './templates'

// テーマ・コピー・制作指示の「案」の生成。出力形式はメッセージ内で毎回指定する(aiSelect.ts と同じ理由)

const THEME_PROMPT = `あなたは、ファッション通販の配信(メール・プッシュ)を企画するアシスタントです。
下の「入力」の JSON を読み、この配信にふさわしい「配信テーマ」(配信全体の前提。メールには表示しない)の案を 3 つ、理由とともに JSON だけで返してください。

# 出力の形式(厳守)
次の JSON オブジェクト 1 つだけを返す。説明文、見出し、箇条書き、コードフェンス(\`\`\`)、前置き、あとがきは一切付けない。
{"themes":[{"theme":"...","reason":"..."}]}

# ルール
1. テーマは日本語で 20 文字以内の名詞句(例:「秋の新作を先取り」「雨の日でも快適」)。
2. 配信日(card.scheduledAt)の季節と時期、国、チャネル、配信種別(department)、配信名(card.name)を手がかりにする。
3. otherThemes(他の配信で使用中のテーマ)と、同じ・似たテーマは避ける。
4. products の中で、在庫(stock)が十分あり、売上トレンド(salesTrend)が「上昇」の商品が活きるテーマを優先する。
5. 3 案は、切り口を変える(例: 季節感、商品カテゴリ、シーンや天候)。
6. 理由(reason)は日本語で 60 文字以内。時期や商品の傾向など、根拠を具体的に書く。
7. themeHint(担当者が書いたテーマのヒント)があるときは、それを最優先し、3 案ともその方向に沿わせる(文言をそのまま使わなくてよい)。
8. card.themeType(担当者が決めた配信の種類)と card.name(担当者が決めた配信名)があるときは、それに沿うテーマにする(種類と食い違うテーマは出さない)。

# 入力
`

const COPY_PROMPT = `あなたは、ファッション通販の配信(メール・プッシュ)のコピーライターです。
下の「入力」の JSON を読み、メイン画像に載せる「ヘッドライン」と、その下に入る「コピー」の組を、3 案、JSON だけで返してください。

# 出力の形式(厳守)
次の JSON オブジェクト 1 つだけを返す。説明文、見出し、箇条書き、コードフェンス(\`\`\`)、前置き、あとがきは一切付けない。
{"copies":[{"headline":"...","lead":"...","angle":"..."}]}

# ルール
1. 言語は language に従う('ja' は日本語、'en' は英語)。'auto' のときは card.country に合わせる(US は英語、JP は日本語)。
2. ヘッドラインは、メイン画像の上に大きく載る短い言葉。15 文字前後(10〜18 文字。英語も文字数で数える)で、目を引き、テーマの魅力が一瞬で伝わるようにする。card.theme(配信全体の前提)の文言をそのまま使わず、印象的な表現にする。
3. コピーは、ヘッドラインの下に入る導入の 1 文。30 文字前後(25〜35 文字)で、ヘッドラインを補い、商品や使う場面の魅力が伝わるようにする。ヘッドラインの言い換えだけにしない。
4. ヘッドラインとコピーは、組として自然につながるようにする。3 案は、切り口を変える(例: 季節感、商品の魅力、行動の呼びかけ)。angle には、その切り口を日本語 10 文字以内で書く。
5. 商品名や価格を、そのまま羅列しない。誇大な表現や、根拠のない断定(「最安値」「絶対」など)は使わない。
6. 既存のヘッドライン(card.headline)やコピー(card.copy)がある場合は、それとは別の案にする。

# 入力
`

const INSTRUCTIONS_PROMPT = `あなたは、ファッション通販の配信(メール・プッシュ)の制作ディレクターです。
下の「入力」の JSON を読み、制作担当者向けの「制作指示」の案を 3 つ、JSON だけで返してください。

# 出力の形式(厳守)
次の JSON オブジェクト 1 つだけを返す。JSON の外には、説明文、コードフェンス(\`\`\`)、前置き、あとがきを一切付けない。
{"instructions":[{"text":"...","angle":"..."}]}

# ルール
1. text は Markdown で書く(JSON の文字列の中の改行は \\n)。次の 5 つの見出し(### で始める)を、この順に置き、それぞれの下に「- 」の箇条書きを 1〜3 行ずつ書く。1 行は短く、具体的に。
   ### レイアウト(メインビジュアルと商品グリッドの構成、商品数)
   ### メイン画像(雰囲気、見せ方)
   ### 色とトーン
   ### 商品の見せ方(強調する商品、並び)
   ### ボタン・注意点
   全体で 250〜400 文字。制作担当者が、読んですぐに作業できるようにする。
2. 見出しの言葉は上のとおりにする(画面が英語のときは Layout / Main image / Color & tone / Products / Buttons & notes)。
3. products の並び順(先頭が最も重要)と、hero(メイン画像)の内容を踏まえる。
4. 3 案は、方針を変える(例: 王道の構成、商品を主役にする、世界観を重視する)。angle には、その方針を日本語 10 文字以内で書く。
5. 既存の制作指示(card.instructions)がある場合は、その方針を尊重しつつ、別の案にする。
6. card.headline(ヘッドライン)と card.copy(コピー)がある場合は、その世界観に合わせる。

# 入力
`

export interface ThemeSuggestion {
  theme: string
  reason: string
}

export async function suggestThemes(args: {
  card: AiCard
  otherThemes: string[]
  products: Product[]
  /** 担当者が書いたテーマのヒント(まとめて作るときの行ごと。W14) */
  themeHint?: string
}): Promise<ThemeSuggestion[]> {
  const { card, otherThemes, products, themeHint } = args
  const parsed = (await askAgent(THEME_PROMPT, {
    task: 'suggest_themes',
    today: new Date().toISOString().slice(0, 10),
    card,
    otherThemes,
    ...(themeHint?.trim() ? { themeHint: themeHint.trim() } : {}),
    products: products.map((p) => ({
      name: p.name,
      category: p.category_name,
      stock: p.stock,
      season: p.season_name,
      salesTrend: p.sales_trend_name,
      weather: p.weather_name,
    })),
  })) as { themes?: { theme?: string; reason?: string }[] }

  const list = (parsed.themes ?? [])
    .filter((t) => t.theme)
    .map((t) => ({ theme: String(t.theme), reason: String(t.reason ?? '') }))
  if (list.length === 0) throw new Error(tr('テーマ案を取得できませんでした', 'Could not get theme ideas'))
  return list
}

interface DraftContext {
  card: AiCard
  /** コピー・ヘッドラインの言語 */
  language: CopyLanguage
  items: { product?: Product; reason: string }[]
  hero?: HeroImage
}

const contextPayload = ({ card, language, items, hero }: DraftContext) => ({
  card,
  language,
  products: items.map((i) => ({
    name: i.product?.name,
    category: i.product?.category_name,
    price: i.product?.price,
    reason: i.reason,
  })),
  hero: hero
    ? { name: hero.name, purpose: hero.purpose_name, season: hero.season_name, tags: hero.tags, description: hero.description }
    : null,
})

export interface CopyIdea {
  headline: string
  lead: string
  angle: string
}

export async function suggestCopies(ctx: DraftContext): Promise<CopyIdea[]> {
  const parsed = (await askAgent(COPY_PROMPT, { task: 'suggest_copies', ...contextPayload(ctx) })) as {
    copies?: { headline?: string; lead?: string; angle?: string }[]
  }
  const list = (parsed.copies ?? [])
    .filter((c) => c.headline)
    .map((c) => ({ headline: String(c.headline), lead: String(c.lead ?? ''), angle: String(c.angle ?? '') }))
  if (list.length === 0) throw new Error(tr('ヘッドラインとコピーの案を取得できませんでした', 'Could not get headline and copy ideas'))
  return list
}

const PUSH_PROMPT = `あなたは、ファッション通販のアプリの通知(プッシュ通知)のコピーライターです。
下の「入力」の JSON を読み、アプリの通知の「タイトル」と「本文」の組を、3 案、JSON だけで返してください。
通知を押すと、アプリの中で、この配信のメッセージ(card.headline と card.copy が見出しの画面)が開きます。

# 出力の形式(厳守)
次の JSON オブジェクト 1 つだけを返す。JSON の外には、説明文、コードフェンス、前置き、あとがきを一切付けない。
{"notifications":[{"title":"...","body":"...","angle":"..."}]}

# ルール
1. 言語は language に従う('ja' は日本語、'en' は英語)。'auto' のときは card.country に合わせる(US は英語、JP は日本語)。
2. title は 40 文字以内(英語も文字数で数える)。開きたくなる、具体的な一言。メッセージの見出し(card.headline)の言い換えだけにしない。
3. body は 120 文字以内。2〜3 行で読み切れる長さで、何が・いつまでか・押すと何が見られるかを伝える。
4. 3 案は、切り口を変える(例: 季節感、商品の魅力、期限の呼びかけ)。angle には、その切り口を日本語 10 文字以内で書く。
5. 誇大な表現や、根拠のない断定(「最安値」「絶対」など)は使わない。絵文字は使わない。

# 入力
`

/** アプリの通知のタイトル・本文の案(メッセージのヘッドライン・コピーと同じ形で返す。案の画面を共通にするため) */
export async function suggestPushNotifications(ctx: DraftContext): Promise<CopyIdea[]> {
  const parsed = (await askAgent(PUSH_PROMPT, { task: 'suggest_push', ...contextPayload(ctx) })) as { notifications?: { title?: string; body?: string; angle?: string }[] }
  const list = (parsed.notifications ?? []).filter((n) => n.title).map((n) => ({ headline: String(n.title), lead: String(n.body ?? ''), angle: String(n.angle ?? '') }))
  if (list.length === 0) throw new Error(tr('通知の案を取得できませんでした', 'Could not get notification ideas'))
  return list
}

export interface InstructionIdea {
  text: string
  angle: string
}

export async function suggestInstructions(ctx: DraftContext): Promise<InstructionIdea[]> {
  const parsed = (await askAgent(INSTRUCTIONS_PROMPT, { task: 'suggest_instructions', ...contextPayload(ctx) })) as {
    instructions?: { text?: string; angle?: string }[]
  }
  const list = (parsed.instructions ?? []).filter((c) => c.text).map((c) => ({ text: String(c.text), angle: String(c.angle ?? '') }))
  if (list.length === 0) throw new Error(tr('制作指示の案を取得できませんでした', 'Could not get production instruction ideas'))
  return list
}

const TEMPLATE_PROMPT = `あなたは、ファッション通販の配信(メール・プッシュ)を企画するアシスタントです。
下の「入力」の JSON を読み、この配信にふさわしいメールの構成(テンプレート)を 1 つ選んで、JSON だけで返してください。

# 出力の形式(厳守)
次の JSON オブジェクト 1 つだけを返す。説明文、見出し、箇条書き、コードフェンス(\`\`\`)、前置き、あとがきは一切付けない。
{"template":"standard4","reason":"..."}

# テンプレート
入力の templates は、選べるテンプレートの一覧。id、name(名前)、description(説明)、hero(ヒーローの種類)、heroText(ヘッドラインの見せ方。band=写真に帯で重ねる / overlay=写真に大きく重ねる / below=写真の下)、sections(商品の枠の構成。kind は grid=名前・価格つきのグリッド / photos=写真だけのタイル / wide=全幅で大きく 1 点 / mosaic=大 1 点 + 小 2 点の組 / story=写真と説明を左右交互 / feature=特集、columns=列の数(省略は 2)、slots=商品の数、categoryHeading=見出し付き、buttons=セクションの後のボタンの数)を持つ。
標準の id: standard4(標準。迷ったときは、これ)、collab(コラボや特別企画)、offer(期間限定・セール)、cat2 / cat3(カテゴリごとの見出し付き)、free(自由な構成)、sale(セール。目玉の商品を大きく見せる)、spotlight(主役の商品を大きく見せる特集)、story(1 点ずつ丁寧に紹介)、editorial(新作・コレクションを写真中心に見せる)。
ユーザーが作ったテンプレートも、description と構成を読んで、配信に合うなら選ぶ。

# ルール
1. template は、入力の templates の id のどれか 1 つ。
2. 配信テーマ(card.theme)を最優先にする。次に、配信日の時期、チャネル、配信種別(department)を考慮する。
3. セール、タイムセール、期間限定などのテーマは offer。コラボや特別企画のテーマは collab。card.themeType(担当者が決めた配信の種類)があるときは、それを優先する(セール・期間限定価格は offer、コラボは collab)。
4. 特定の商品を絞って訴求するテーマ(例:「ブーツ特集」)は standard4。複数の切り口を見せたいテーマは cat2 か cat3。
5. reason は日本語で 60 文字以内。

# 入力
`

export interface TemplateChoice {
  template: EmailTemplateId
  reason: string
}

/** テーマなどから、テンプレートを選ばせる(配信カードのチャネルのテンプレートだけから) */
export async function suggestTemplate(args: { card: AiCard; channel?: TemplateChannel }): Promise<TemplateChoice> {
  const channel = args.channel ?? 'email'
  const options = templateOptions(channel)
  const parsed = (await askAgent(TEMPLATE_PROMPT, {
    task: 'suggest_template',
    today: new Date().toISOString().slice(0, 10),
    card: args.card,
    templates: options.map((o) => ({ id: o.id, name: o.label, description: o.description, hero: o.hero, heroText: o.heroText ?? 'band', sections: o.sections, push: o.push })),
  })) as { template?: string; reason?: string }
  const id = String(parsed.template ?? '') as EmailTemplateId
  // 想定外の値・別のチャネルのテンプレートは、そのチャネルの標準にする
  const fallback = channel === 'push' ? DEFAULT_PUSH_TEMPLATE : 'standard4'
  return { template: hasTemplate(id) && options.some((o) => o.id === id) ? id : fallback, reason: String(parsed.reason ?? '') }
}

const NAME_PROMPT = `あなたは、ファッション通販の配信(メール・プッシュ)を企画するアシスタントです。
下の「入力」の JSON の slots(週の計画の、まだ中身のない配信の枠)それぞれに、配信名の案を 1 つずつ、理由とともに JSON だけで返してください。

# 出力の形式(厳守)
次の JSON オブジェクト 1 つだけを返す。説明文、見出し、箇条書き、コードフェンス(\`\`\`)、前置き、あとがきは一切付けない。
{"names":[{"id":"...","name":"...","themeType":"...","reason":"..."}]}

# ルール
1. 入力のすべての枠について、id をそのまま返す。
2. 配信名は、社内で配信を見分けるための短い名前。日本向け(country が JP)は日本語で 15 文字以内、アメリカ向け(US)は英語で 4 語以内。
3. 配信日(scheduledAt)の曜日・季節・行事、チャネル、配信の種類(themeType)を手がかりにする。種類があるときは、名前から種類が分かるようにする。
4. others(前後の週の、ほかの配信の名前とテーマ)や、ほかの枠の案と、同じ・似た名前にしない。
5. 理由(reason)は日本語で 40 文字以内。
6. themeType が空の枠は、種類も 1 つ選び、次のキーで themeType に入れる(配信名は、その種類に合わせる)。同じ週で同じ種類ばかりにならないようにし、others の種類の並びも参考にする。themeType が入っている枠は、それをそのまま返す。
   - price: 値下げ / limited: 期間限定価格 / sale: セール / new: 新作 / collab: コラボ / member: 会員向け / season: 季節の特集 / restock: 再入荷 / other: どれにも当てはまらない
7. name が入っている枠は、人が決めた配信名なので、name をそのまま返し、その名前に合う種類を選ぶ。

# 入力
`

export interface NameSlot {
  id: string
  scheduledAt: string
  country: string
  channel: string
  department: string
  themeType?: string
  /** 人がもう入れた配信名(あれば、名前は変えずに返し、種類を選ぶ手がかりにする) */
  name?: string
}

/**
 * 週の枠(中身のない配信)の、配信名の案。1 枠でも、まとめてでも、1 回の呼び出しで出す(枠どうしで名前が重ならないように)。
 * 種類(themeType)が空の枠は、種類の案も返す(種類を 1 行ずつ選ぶ手間を減らす。使うかは呼び出し側が決める)
 */
export async function suggestNames(args: { slots: NameSlot[]; others: { name: string; theme?: string; scheduledAt?: string }[] }): Promise<{ id: string; name: string; reason: string; themeType?: ThemeType }[]> {
  const parsed = (await askAgent(NAME_PROMPT, {
    task: 'suggest_names',
    today: new Date().toISOString().slice(0, 10),
    slots: args.slots,
    others: args.others,
  })) as { names?: { id?: string; name?: string; reason?: string; themeType?: string }[] }
  const ids = new Set(args.slots.map((s) => s.id))
  const list = (parsed.names ?? [])
    .filter((n) => n.id && ids.has(String(n.id)) && n.name)
    .map((n) => ({
      id: String(n.id),
      name: String(n.name).trim(),
      reason: String(n.reason ?? ''),
      // 知らない値は捨てる(AI が日本語の名前などで返すことがあるため)
      themeType: (THEME_TYPES as string[]).includes(String(n.themeType)) ? (n.themeType as ThemeType) : undefined,
    }))
  if (list.length === 0) throw new Error(tr('配信名の案を取得できませんでした', 'Could not get name ideas'))
  return list
}
