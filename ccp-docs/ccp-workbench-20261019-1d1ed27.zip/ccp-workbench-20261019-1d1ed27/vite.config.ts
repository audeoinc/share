import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// ビルドの設定(サーバーが配信する版。Workbench でも動く)。
//   開発:   npm run dev      (別のターミナルで、サーバーを 8080 で起動しておく。/api はそこへ中継する)
//   ビルド: npm run build    (dist-gcp/ にできる。サーバーがこれを配信する)
// 撮影・デモ用(サンプルデータで動かす)は、vite.mock.config.ts。
export default defineConfig({
  plugins: [react()],
  // 開いたときの初期値。国の絞り込みは US、画面の言語は English
  define: {
    'import.meta.env.VITE_DEFAULT_COUNTRY': JSON.stringify('US'),
    'import.meta.env.VITE_DEFAULT_LANG': JSON.stringify('en'),
    // API・画像のパスを、読み込んだ JS の場所から求める(src/appRoot.ts。Workbench の /proxy/8081/ の下でも動くように)
    'import.meta.env.VITE_APP_ROOT_FROM_SCRIPT': JSON.stringify('true'),
  },
  // 画面のファイル(assets/…)を、相対パスで読み込む(置き場所が「/」でなくても読めるように)
  base: './',
  build: {
    outDir: 'dist-gcp',
    // SVG は、大きさにかかわらず、アプリの中に埋め込む(既定は 4KB 以下だけ)
    assetsInlineLimit: (file) => (file.endsWith('.svg') ? true : undefined),
  },
  server: { port: 5191, strictPort: true, proxy: { '/api': 'http://localhost:8080' } },
})
