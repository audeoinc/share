'use strict';
/**
 * Export to Diff HTML — VS Code 拡張（プレーン JS / ビルド不要）
 *
 * 提供機能（Phase 0 / R1〜R7）:
 *  - エクスプローラー右クリック「Export to Diff HTML」
 *  - 2 or 3 ファイル選択で 2-way / 3-way を自動分岐（それ以外はエラー）
 *  - div ルート＋インライン CSS のフラグメント生成
 *  - Webview: 左=ソース / 右=プレビュー（幅可変・折り返し表示）、コピーアイコン＋トースト
 *  - HTML ファイルは保存しない（メモリ / Webview のみ）
 *
 * 出力HTMLの折り返し: セルは white-space:pre-wrap（インデント保持のまま画面幅で折り返し）。
 */

const vscode = require('vscode');
const path = require('path');
const { build2Way, build3Way, splitLines } = require('./lib/diff');
const { renderFragment2, renderFragment3, esc } = require('./lib/render');

async function readText(uri) {
  const bytes = await vscode.workspace.fs.readFile(uri);
  return Buffer.from(bytes).toString('utf8');
}

function pickUris(clicked, selected) {
  if (Array.isArray(selected) && selected.length > 0) return selected;
  return clicked ? [clicked] : [];
}

/** VS Code 設定（exportToDiffHtml.*）を読み、render 用の上書きオプションに変換 */
function readThemeOptions() {
  const cfg = vscode.workspace.getConfiguration('exportToDiffHtml');
  return {
    fontFamily: cfg.get('fontFamily') || undefined,
    fontSize: cfg.get('fontSize'),
    lineHeight: cfg.get('lineHeight'),
    colors: {
      baseColor: cfg.get('colors.baseColor'),
      afterColor: cfg.get('colors.afterColor'),
      refColor: cfg.get('colors.refColor'),
    },
    diffLineOpacity: cfg.get('diffLineOpacity'),
    diffCharOpacity: cfg.get('diffCharOpacity'),
    syntax: {
      keyword: cfg.get('syntax.keyword'),
      literal: cfg.get('syntax.literal'),
      comment: cfg.get('syntax.comment'),
    },
  };
}

async function exportCommand(clickedUri, selectedUris) {
  const uris = pickUris(clickedUri, selectedUris);

  if (uris.length < 2 || uris.length > 3) {
    vscode.window.showErrorMessage('2または3 個のファイルを選択してください');
    return;
  }

  let texts;
  try {
    texts = await Promise.all(uris.map(readText));
  } catch (e) {
    vscode.window.showErrorMessage('ファイルの読み込みに失敗しました: ' + (e && e.message ? e.message : String(e)));
    return;
  }

  const names = uris.map((u) => path.basename(u.fsPath || u.path));
  const linesArr = texts.map(splitLines);
  const opts = readThemeOptions();

  let fragment;
  if (uris.length === 2) {
    fragment = renderFragment2(names[0], names[1], build2Way(linesArr[0], linesArr[1]), opts);
  } else {
    fragment = renderFragment3(names, build3Way(linesArr[0], linesArr[1], linesArr[2]), opts);
  }

  const seed = {
    base: normalizeHex(opts.colors && opts.colors.baseColor, '#E17B7B'),
    after: normalizeHex(opts.colors && opts.colors.afterColor, '#93AE68'),
    ref: normalizeHex(opts.colors && opts.colors.refColor, '#7E9BC8'),
  };

  const panel = vscode.window.createWebviewPanel(
    'exportToDiffHtml',
    'Diff HTML: ' + names.join(' / '),
    vscode.ViewColumn.Active,
    { enableScripts: true, retainContextWhenHidden: true }
  );
  panel.webview.html = webviewHtml(panel.webview, fragment, seed);

  panel.webview.onDidReceiveMessage((msg) => {
    if (!msg) return;
    if (msg.type === 'copy') {
      vscode.env.clipboard.writeText(fragment); // トーストは Webview 側で表示
    } else if (msg.type === 'copyText' && typeof msg.text === 'string') {
      vscode.env.clipboard.writeText(msg.text);
    }
  });
}

/** #rrggbb 形式に正規化。不正なら fallback。 */
function normalizeHex(v, fallback) {
  if (typeof v !== 'string') return fallback;
  let h = v.trim();
  if (/^#?[0-9a-fA-F]{3}$/.test(h)) {
    h = h.replace('#', '');
    h = '#' + h.split('').map((x) => x + x).join('');
    return h.toUpperCase();
  }
  if (/^#?[0-9a-fA-F]{6}$/.test(h)) return ('#' + h.replace('#', '')).toUpperCase();
  return fallback;
}

function webviewHtml(webview, fragment, seed) {
  const nonce = String(Date.now()) + Math.floor(Math.random() * 1e6);
  const csp =
    `default-src 'none'; style-src 'unsafe-inline'; img-src data:; script-src 'nonce-${nonce}';`;
  const sourceEscaped = esc(fragment);
  seed = seed || { base: '#E17B7B', after: '#93AE68', ref: '#7E9BC8' };

  // 2枚重ねのコピーアイコン
  const copyIcon =
    '<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">' +
    '<rect x="5.5" y="5.5" width="8" height="9" rx="1.5" stroke="currentColor"/>' +
    '<path d="M10.5 5.5V3A1.5 1.5 0 0 0 9 1.5H3A1.5 1.5 0 0 0 1.5 3v7A1.5 1.5 0 0 0 3 11.5h2.5" stroke="currentColor"/>' +
    '</svg>';

  return `<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="utf-8">
<meta http-equiv="Content-Security-Policy" content="${csp}">
<style>
  html,body{height:100%;margin:0;}
  body{font-family:var(--vscode-font-family);color:var(--vscode-foreground);background:var(--vscode-editor-background);}
  .outer{display:flex;flex-direction:column;height:100vh;}
  .wrap{display:flex;flex:1 1 auto;min-height:0;box-sizing:border-box;}
  .pane{min-width:80px;display:flex;flex-direction:column;overflow:hidden;}
  #paneL{flex:0 0 50%;}
  #paneR{flex:1 1 0;}
  .pane > header{display:flex;align-items:center;justify-content:space-between;gap:8px;
    padding:6px 10px;font-size:12px;letter-spacing:.02em;text-transform:uppercase;
    color:var(--vscode-descriptionForeground);border-bottom:1px solid var(--vscode-panel-border,#3334);}
  .body{flex:1 1 auto;overflow:auto;padding:12px;}
  /* ソース表示: 画面幅で折り返し（表示専用。コピー内容は変わらない） */
  pre{margin:0;font-family:var(--vscode-editor-font-family,monospace);font-size:12px;
    white-space:pre-wrap;overflow-wrap:anywhere;word-break:break-word;}
  #copyBtn{display:inline-flex;align-items:center;justify-content:center;gap:6px;
    background:transparent;border:1px solid var(--vscode-panel-border,#8884);border-radius:4px;
    color:var(--vscode-foreground);padding:2px 8px;cursor:pointer;font-size:12px;}
  #copyBtn:hover{background:var(--vscode-toolbar-hoverBackground,#8882);}
  /* ドラッグで幅を変えられる仕切り */
  .divider{flex:0 0 6px;cursor:col-resize;background:var(--vscode-panel-border,#3335);}
  .divider:hover,.divider.active{background:var(--vscode-focusBorder,#3794ff);}
  .preview{background:#ffffff;border-radius:6px;padding:12px;max-width:100%;overflow:hidden;}
  .preview table{max-width:100%;}
  /* トースト */
  #toast{position:fixed;bottom:16px;left:50%;transform:translateX(-50%) translateY(8px);
    background:var(--vscode-notifications-background,#2b2b2b);color:var(--vscode-notifications-foreground,#fff);
    border:1px solid var(--vscode-notifications-border,#0004);border-radius:6px;padding:6px 14px;
    font-size:12px;opacity:0;pointer-events:none;transition:opacity .15s ease,transform .15s ease;
    box-shadow:0 2px 10px #0005;z-index:20;}
  #toast.show{opacity:1;transform:translateX(-50%) translateY(0);}
  /* 色を選ぶバー */
  .pickerbar{display:flex;align-items:center;gap:14px;flex-wrap:wrap;
    padding:6px 12px;border-top:1px solid var(--vscode-panel-border,#3334);
    background:var(--vscode-editorWidget-background,var(--vscode-editor-background));font-size:12px;}
  .pk-title{font-weight:600;}
  .pk{display:inline-flex;align-items:center;gap:6px;}
  .pk > label{color:var(--vscode-descriptionForeground);text-transform:capitalize;}
  .pk input[type=color]{width:26px;height:20px;padding:0;border:1px solid var(--vscode-panel-border,#8884);border-radius:4px;background:none;cursor:pointer;}
  .pk code{font-family:var(--vscode-editor-font-family,monospace);min-width:66px;}
  .pk-copy{display:inline-flex;align-items:center;background:transparent;border:1px solid var(--vscode-panel-border,#8884);
    border-radius:4px;color:var(--vscode-foreground);padding:1px 5px;cursor:pointer;}
  .pk-copy:hover{background:var(--vscode-toolbar-hoverBackground,#8882);}
  .pk-hint{color:var(--vscode-descriptionForeground);margin-left:auto;}
</style>
</head>
<body>
  <div class="outer">
    <div class="wrap" id="wrap">
      <section class="pane" id="paneL">
        <header>
          <span>Source (HTML fragment)</span>
          <button id="copyBtn" title="コピー">${copyIcon}<span>Copy</span></button>
        </header>
        <div class="body"><pre id="src">${sourceEscaped}</pre></div>
      </section>
      <div class="divider" id="divider" title="ドラッグで幅を調整"></div>
      <section class="pane" id="paneR">
        <header><span>Preview</span></header>
        <div class="body"><div class="preview">${fragment}</div></div>
      </section>
    </div>
    <div class="pickerbar">
      <span class="pk-title">🎨 色を選ぶ</span>
      <span class="pk"><label>base</label><input type="color" id="pk_base" value="${seed.base}"><code id="hx_base">${seed.base}</code><button class="pk-copy" data-hx="hx_base" title="コードをコピー">${copyIcon}</button></span>
      <span class="pk"><label>after</label><input type="color" id="pk_after" value="${seed.after}"><code id="hx_after">${seed.after}</code><button class="pk-copy" data-hx="hx_after" title="コードをコピー">${copyIcon}</button></span>
      <span class="pk"><label>ref</label><input type="color" id="pk_ref" value="${seed.ref}"><code id="hx_ref">${seed.ref}</code><button class="pk-copy" data-hx="hx_ref" title="コードをコピー">${copyIcon}</button></span>
      <span class="pk-hint">選んだコードを settings.json の colors.*Color に貼り付け</span>
    </div>
  </div>
  <div id="toast">コピーしました</div>
  <script nonce="${nonce}">
    const vscode = acquireVsCodeApi();
    const toast = document.getElementById('toast');
    let toastTimer;
    function showToast() {
      toast.classList.add('show');
      clearTimeout(toastTimer);
      toastTimer = setTimeout(function () { toast.classList.remove('show'); }, 1600);
    }
    document.getElementById('copyBtn').addEventListener('click', function () {
      vscode.postMessage({ type: 'copy' });
      showToast();
    });

    // 色を選ぶバー: ピッカーで選ぶと 16進コードを表示、コピーで settings 用にクリップボードへ
    ['base', 'after', 'ref'].forEach(function (id) {
      var input = document.getElementById('pk_' + id);
      var hx = document.getElementById('hx_' + id);
      input.addEventListener('input', function () { hx.textContent = input.value.toUpperCase(); });
    });
    Array.prototype.forEach.call(document.querySelectorAll('.pk-copy'), function (btn) {
      btn.addEventListener('click', function () {
        var code = document.getElementById(btn.getAttribute('data-hx')).textContent;
        vscode.postMessage({ type: 'copyText', text: code });
        showToast();
      });
    });

    // ペイン幅のドラッグ調整
    (function () {
      const wrap = document.getElementById('wrap');
      const divider = document.getElementById('divider');
      const paneL = document.getElementById('paneL');
      let dragging = false;
      divider.addEventListener('mousedown', function (e) {
        dragging = true;
        divider.classList.add('active');
        document.body.style.userSelect = 'none';
        e.preventDefault();
      });
      window.addEventListener('mousemove', function (e) {
        if (!dragging) return;
        const rect = wrap.getBoundingClientRect();
        let pct = ((e.clientX - rect.left) / rect.width) * 100;
        pct = Math.max(15, Math.min(85, pct));
        paneL.style.flex = '0 0 ' + pct + '%';
      });
      window.addEventListener('mouseup', function () {
        dragging = false;
        divider.classList.remove('active');
        document.body.style.userSelect = '';
      });
    })();
  </script>
</body>
</html>`;
}

function activate(context) {
  context.subscriptions.push(
    vscode.commands.registerCommand('exportToDiffHtml.export', exportCommand)
  );
}

function deactivate() {}

module.exports = { activate, deactivate };
