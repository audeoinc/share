'use strict';
/**
 * Export to Diff HTML — VS Code 拡張（プレーン JS / ビルド不要）
 *
 * 提供機能（Phase 0 / R1〜R7）:
 *  - エクスプローラー右クリック「Export to Diff HTML」
 *  - 2 or 3 ファイル選択で 2-way / 3-way を自動分岐（それ以外はエラー）
 *  - div ルート＋インライン CSS のフラグメント生成
 *  - Webview: 左=ソース / 右=プレビュー、コピーアイコン（完了FBなし）
 *  - HTML ファイルは保存しない（メモリ / Webview のみ）
 */

const vscode = require('vscode');
const path = require('path');
const { build2Way, build3Way, splitLines } = require('./lib/diff');
const { renderFragment2, renderFragment3, esc } = require('./lib/render');

async function readText(uri) {
  const bytes = await vscode.workspace.fs.readFile(uri);
  return Buffer.from(bytes).toString('utf8');
}

function pickUris(clicked, selected) {
  if (Array.isArray(selected) && selected.length > 0) return selected;
  return clicked ? [clicked] : [];
}

async function exportCommand(clickedUri, selectedUris) {
  const uris = pickUris(clickedUri, selectedUris);

  if (uris.length < 2 || uris.length > 3) {
    vscode.window.showErrorMessage('2または3 個のファイルを選択してください');
    return;
  }

  let texts;
  try {
    texts = await Promise.all(uris.map(readText));
  } catch (e) {
    vscode.window.showErrorMessage('ファイルの読み込みに失敗しました: ' + (e && e.message ? e.message : String(e)));
    return;
  }

  const names = uris.map((u) => path.basename(u.fsPath || u.path));
  const linesArr = texts.map(splitLines);

  let fragment;
  if (uris.length === 2) {
    fragment = renderFragment2(names[0], names[1], build2Way(linesArr[0], linesArr[1]));
  } else {
    fragment = renderFragment3(names, build3Way(linesArr[0], linesArr[1], linesArr[2]));
  }

  const panel = vscode.window.createWebviewPanel(
    'exportToDiffHtml',
    'Diff HTML: ' + names.join(' / '),
    vscode.ViewColumn.Active,
    { enableScripts: true, retainContextWhenHidden: true }
  );
  panel.webview.html = webviewHtml(panel.webview, fragment);

  panel.webview.onDidReceiveMessage((msg) => {
    if (msg && msg.type === 'copy') {
      // 完了フィードバックは出さない（R5）
      vscode.env.clipboard.writeText(fragment);
    }
  });
}

function webviewHtml(webview, fragment) {
  const nonce = String(Date.now()) + Math.floor(Math.random() * 1e6);
  const csp =
    `default-src 'none'; style-src 'unsafe-inline'; img-src data:; script-src 'nonce-${nonce}';`;
  const sourceEscaped = esc(fragment);

  // 2枚重ねのコピーアイコン
  const copyIcon =
    '<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">' +
    '<rect x="5.5" y="5.5" width="8" height="9" rx="1.5" stroke="currentColor"/>' +
    '<path d="M10.5 5.5V3A1.5 1.5 0 0 0 9 1.5H3A1.5 1.5 0 0 0 1.5 3v7A1.5 1.5 0 0 0 3 11.5h2.5" stroke="currentColor"/>' +
    '</svg>';

  return `<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="utf-8">
<meta http-equiv="Content-Security-Policy" content="${csp}">
<style>
  html,body{height:100%;margin:0;}
  body{font-family:var(--vscode-font-family);color:var(--vscode-foreground);background:var(--vscode-editor-background);}
  .wrap{display:flex;height:100vh;box-sizing:border-box;}
  .pane{flex:1 1 50%;min-width:0;display:flex;flex-direction:column;border-right:1px solid var(--vscode-panel-border,#3334);}
  .pane:last-child{border-right:none;}
  .pane > header{display:flex;align-items:center;justify-content:space-between;gap:8px;
    padding:6px 10px;font-size:12px;letter-spacing:.02em;text-transform:uppercase;
    color:var(--vscode-descriptionForeground);border-bottom:1px solid var(--vscode-panel-border,#3334);}
  .body{flex:1 1 auto;overflow:auto;padding:12px;}
  pre{margin:0;font-family:var(--vscode-editor-font-family,monospace);font-size:12px;white-space:pre;}
  #copyBtn{display:inline-flex;align-items:center;justify-content:center;gap:6px;
    background:transparent;border:1px solid var(--vscode-panel-border,#8884);border-radius:4px;
    color:var(--vscode-foreground);padding:2px 8px;cursor:pointer;font-size:12px;}
  #copyBtn:hover{background:var(--vscode-toolbar-hoverBackground,#8882);}
  .preview{background:#ffffff;border-radius:6px;padding:12px;overflow:auto;}
</style>
</head>
<body>
  <div class="wrap">
    <section class="pane">
      <header>
        <span>Source (HTML fragment)</span>
        <button id="copyBtn" title="コピー">${copyIcon}<span>Copy</span></button>
      </header>
      <div class="body"><pre id="src">${sourceEscaped}</pre></div>
    </section>
    <section class="pane">
      <header><span>Preview</span></header>
      <div class="body"><div class="preview">${fragment}</div></div>
    </section>
  </div>
  <script nonce="${nonce}">
    const vscode = acquireVsCodeApi();
    document.getElementById('copyBtn').addEventListener('click', function () {
      vscode.postMessage({ type: 'copy' });
    });
  </script>
</body>
</html>`;
}

function activate(context) {
  context.subscriptions.push(
    vscode.commands.registerCommand('exportToDiffHtml.export', exportCommand)
  );
}

function deactivate() {}

module.exports = { activate, deactivate };
