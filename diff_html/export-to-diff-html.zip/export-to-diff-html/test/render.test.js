'use strict';
const test = require('node:test');
const assert = require('node:assert');
const { build2Way } = require('../lib/diff');
const { renderFragment2, DEFAULTS } = require('../lib/render');

const rows = build2Way(['SELECT a', 'FROM t'], ['SELECT a', 'FROM t2']);

test('render: 既定では既定色・既定サイズで出力', () => {
  const html = renderFragment2('a.sql', 'b.sql', rows);
  assert.ok(html.includes('font-size:12px'));
  assert.ok(html.includes('line-height:1.35'));
  assert.ok(html.includes(DEFAULTS.PANES.after.bg)); // 既定の緑
});

test('render: 設定で色・サイズ・行間を上書きできる', () => {
  const html = renderFragment2('a.sql', 'b.sql', rows, {
    fontSize: 16,
    lineHeight: 2,
    fontFamily: "'Consolas', monospace",
    colors: { afterLine: '#123456', afterChar: '#654321' },
    syntax: { keyword: '#ABCDEF' },
  });
  assert.ok(html.includes('font-size:16px'));
  assert.ok(html.includes('line-height:2'));
  assert.ok(html.includes("'Consolas', monospace"));
  assert.ok(html.includes('#123456'));   // afterLine 反映
  assert.ok(html.includes('#ABCDEF'));   // keyword 反映
});

test('render: 上書き後に既定へ戻る（状態が残らない）', () => {
  renderFragment2('a.sql', 'b.sql', rows, { fontSize: 20 });
  const html = renderFragment2('a.sql', 'b.sql', rows); // opts なし
  assert.ok(html.includes('font-size:12px'));
  assert.ok(!html.includes('font-size:20px'));
});
