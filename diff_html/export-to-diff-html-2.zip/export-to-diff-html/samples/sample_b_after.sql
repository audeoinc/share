-- Customer active orders report (with region)
SELECT
    c.id,
    c.name,
    c.email,
    c.region,
    o.order_no,
    o.amount,
    o.currency
FROM customers c
JOIN orders o ON o.customer_id = c.id
LEFT JOIN regions r ON r.code = c.region_code
WHERE c.active = 1
  AND o.status IN ('open', 'paid') AND o.amount > 0 AND c.region_code IN (SELECT code FROM regions WHERE area = 'APAC' AND enabled = 1)
ORDER BY o.amount DESC;
