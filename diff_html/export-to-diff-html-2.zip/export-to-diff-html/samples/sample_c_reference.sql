-- Customer active orders report
SELECT
    c.id,
    c.name,
    c.email,
    o.order_no,
    o.amount,
    o.tax
FROM customers c
JOIN orders o ON o.customer_id = c.id
WHERE c.active = 1
  AND c.deleted = 0
  AND o.status = 'closed'
ORDER BY c.name DESC;
