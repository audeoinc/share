-- Customer active orders report
SELECT
    c.id,
    c.name,
    c.email,
    o.order_no,
    o.amount
FROM customers c
JOIN orders o ON o.customer_id = c.id
WHERE c.active = 1
  AND c.deleted = 0
  AND o.status = 'open'
ORDER BY c.name;
