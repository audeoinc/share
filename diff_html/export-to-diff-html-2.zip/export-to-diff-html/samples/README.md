# 検証用サンプル SQL

差分表示のデザインを網羅確認するためのテストデータです。

## ファイル
- `sample_a_base.sql` … 基準（before / base）
- `sample_b_after.sql` … 修正後（after）
- `sample_c_reference.sql` … 参考（reference）

## 使い方
- **2ファイル比較:** `sample_a_base.sql` と `sample_b_after.sql` を選択 → 右クリック →「Export to Diff HTML」
- **3ファイル比較:** A → B → C の順に3つ選択 → 同上（選択順に左から配置。基準は左端 A）

## 網羅している差分デザイン

### 2ファイル比較（A vs B）
- **一致（equal）**: `SELECT` / `FROM customers c` など
- **変更（mod, 行内ハイライト）**: 1行目コメント、`o.amount` → `o.amount,`、`ORDER BY c.name;` → `ORDER BY o.amount DESC;`
- **追加（add）**: `c.region,` / `o.currency` / `LEFT JOIN regions ...`
- **削除（del）**: `  AND c.deleted = 0`（B で削除）
- **長い行の折り返し**: B の `WHERE ... IN (SELECT code FROM regions WHERE area = 'APAC' ...)` の長い1行
- **インデント保持**: 4スペース / 2スペースのインデントがそのまま表示

### 3ファイル比較（A / B / C, 基準=左端A）
- **列ごとに異なる差分**: `AND c.deleted = 0` は A/C にあり B で削除 → B 列だけ空
- **基準に対する変更ハイライト**: C の `o.status = 'closed'`、`ORDER BY c.name DESC;`
- **片方だけの挿入**: B のみの `o.currency` / `LEFT JOIN` 行、C のみの `o.tax` 行
