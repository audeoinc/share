# Export to Diff HTML（社内 VS Code 拡張 / 開発版 v0.1.0）

選択した **2〜3 個のファイル**の差分を、**Confluence の HTML マクロにそのまま貼れるインライン CSS のフラグメント**として生成し、VS Code 内で「左=ソース / 右=プレビュー」で確認・コピーできる拡張です。

- ビルド不要の**プレーン JavaScript**（依存ライブラリ 0 個）。フォルダを置くだけで動きます。
- 差分は拡張内で計算（LCS ベース）。VSIX が使いにくい環境向けに JS をそのまま配置できます。

---

## 使い方

1. VS Code のエクスプローラーで、比較したいファイルを **2 個または 3 個**選択（Ctrl / Cmd + クリック）。
2. 右クリック → **「Export to Diff HTML」**。
3. パネルが開き、**左にソース / 右にプレビュー**が並びます（選択順に左から配置）。
4. 左上の**コピーアイコン**で HTML をコピー → Confluence の HTML マクロに貼り付け。

- 2 個選択 → 2ファイル差分（サイドバイサイド）
- 3 個選択 → 3ファイル差分（3ペイン, 基準=左端）
- 1 個 / 4 個以上 → 「2または3 個のファイルを選択してください」

HTML **ファイルは保存されません**（メモリ / パネル上のみ。git に影響しません）。

---

## インストール

### 方法A: JavaScript をそのまま配置（VSIX を使わない場合）

このフォルダ（`export-to-diff-html/`）を、VS Code の拡張ディレクトリに置くだけです。

- Windows: `%USERPROFILE%\.vscode\extensions\export-to-diff-html\`
- macOS / Linux: `~/.vscode/extensions/export-to-diff-html/`

置いたら VS Code を再起動（またはウィンドウの再読み込み）。`npm install` は不要です（依存ゼロ）。

### 方法B: VSIX を作って配布

```bash
npx @vscode/vsce package
# → export-to-diff-html-0.1.0.vsix が生成される
# VS Code: 拡張ビュー → 「…」→「VSIX からのインストール」
```

社内 Git へは、生成した VSIX を**手動でアップロード**してリリースする運用です。

---

## 開発 / テスト

```bash
node --test        # 差分ロジックのユニットテスト（依存ゼロ / Node 標準）
```

VS Code でこのフォルダを開き `F5`（拡張機能の開発ホスト）でも動作確認できます。

---

## ファイル構成

```
export-to-diff-html/
├─ package.json        # 拡張マニフェスト（コマンド / 右クリックメニュー）
├─ extension.js        # エントリ。コマンド・Webview・コピー
├─ lib/
│  ├─ diff.js          # LCS 差分（2-way / 3-way / 行内）※依存ゼロ
│  └─ render.js        # HTML フラグメント生成（div ルート＋インライン CSS）
├─ test/
│  └─ diff.test.js     # ユニットテスト（node:test）
├─ samples/            # 検証用サンプル SQL（全差分デザイン網羅）
│  ├─ sample_a_base.sql
│  ├─ sample_b_after.sql
│  ├─ sample_c_reference.sql
│  └─ README.md
├─ .vscodeignore       # VSIX 同梱除外
└─ README.md
```

## 動作確認（サンプル）

`samples/` に、表示しうる全差分デザインを網羅した SQL を同梱しています。
- 2ファイル比較: `sample_a_base.sql` + `sample_b_after.sql`
- 3ファイル比較: A → B → C の順に選択

詳細は `samples/README.md` を参照。

---

## 現在の範囲（Phase 0）と今後

**入っているもの:** 右クリック起動、2/3 自動分岐、フラグメント生成、プレビュー＋コピー、非保存、ライト×ミニマル Cool 固定テーマ、背景剥がれ対策（左端ボーダー＋ +/− マーカー）。

**Phase 1 以降:** レイアウト設定（フォント / 色 / 背景 / 行間）、並べ替え・基準入替、コピー範囲切替、シンタックスハイライト強化。
