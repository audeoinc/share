# diff.js 徹底解説（学習用・コードリーディング）

`lib/diff.js` を**上から順に、1ブロックずつ**読み解きます。差分アルゴリズムの中核である **LCS（最長共通部分列）** を、具体例つきで理解することを目標にします。

前提知識は「配列」「for ループ」「二次元配列（DP表）」くらいで読めるように書いています。

---

## 0. このファイルは何をするのか

入力: 2つ（または3つ）の「行の配列」。
出力: 画面に並べるための「行データ（どこが一致・追加・削除・変更か）」。

**色や HTML は一切扱いません**。「何が差分か」だけを決めるのがこのファイルの責任です（見た目は `render.js` の担当）。

関数は大きく5種類:
- `diffLines` … 行単位の差分（LCS）… **すべての土台**
- `wordDiff` / `tokenize` / `mergeSegs` / `lcsMatchFlags` … 行内（文字単位）の差分
- `build2Way` … 2ファイルのサイドバイサイド行を作る
- `mapToBase` / `baseCell` / `build3Way` … 3ファイルの3ペイン行を作る
- `splitLines` … テキスト→行配列

---

## 1. 予備知識: LCS（最長共通部分列）とは

2つの列に共通して、**順番を保ったまま**取り出せる最長の並びが LCS です。

```
a = [A, B, C, D]
b = [A, C, D, E]
LCS = [A, C, D]   （長さ3）
```

差分は「LCS に含まれる要素＝共通（equal）、含まれない要素＝削除 or 追加」と考えると求まります。上の例なら、`B` は a だけ→削除、`E` は b だけ→追加。これが diff の基本原理です。

LCS の長さは **DP（動的計画法）** で求めます。`dp[i][j]` を「`a[i..]` と `b[j..]`（それぞれ i 番目・j 番目以降）の LCS の長さ」と定義すると:

- `a[i] === b[j]` のとき: `dp[i][j] = dp[i+1][j+1] + 1`（両方1つ進めて +1）
- 違うとき: `dp[i][j] = max(dp[i+1][j], dp[i][j+1])`（どちらかを1つ進めた方の大きい値）

この表を**後ろから**埋めていきます。

---

## 2. `diffLines(a, b)` — 行単位の差分（14〜35行目）

```js
function diffLines(a, b) {
  const n = a.length, m = b.length;
  const dp = [];
  for (let i = 0; i <= n; i++) dp.push(new Int32Array(m + 1));
```

- `n`, `m` は各配列の長さ。
- `dp` は `(n+1) × (m+1)` の二次元配列。`+1` するのは「配列の終端（何も残っていない状態）」を表す番兵（0 で初期化された最終行・列）を用意するため。
- `Int32Array` は「整数専用の軽量配列」。`new Int32Array(m+1)` は 0 で埋まった長さ `m+1` の行。普通の配列より速く省メモリです。

```js
  for (let i = n - 1; i >= 0; i--) {
    for (let j = m - 1; j >= 0; j--) {
      dp[i][j] = a[i] === b[j]
        ? dp[i + 1][j + 1] + 1
        : Math.max(dp[i + 1][j], dp[i][j + 1]);
    }
  }
```

- **後ろから**（`i=n-1`→0、`j=m-1`→0）埋めます。`dp[i][j]` は「1つ後ろの値」を参照するので、後ろが先に確定している必要があるためです。
- 中身は §1 の漸化式そのもの。行が一致すれば斜め下＋1、しなければ下と右の大きい方。
- ループを抜けると `dp[0][0]` に「a 全体と b 全体の LCS 長」が入ります。

### バックトラック（経路の復元）

長さだけでなく「どれが equal/del/add か」を知るため、`dp` を**前から**たどります。

```js
  const ops = [];
  let i = 0, j = 0;
  while (i < n && j < m) {
    if (a[i] === b[j]) { ops.push({ type: 'equal', aIndex: i, bIndex: j, text: a[i] }); i++; j++; }
    else if (dp[i + 1][j] >= dp[i][j + 1]) { ops.push({ type: 'del', aIndex: i, text: a[i] }); i++; }
    else { ops.push({ type: 'add', bIndex: j, text: b[j] }); j++; }
  }
```

現在位置 `(i, j)` で3択:
- `a[i] === b[j]` → **equal**。両方1つ進める（`i++; j++`）。
- そうでなく `dp[i+1][j] >= dp[i][j+1]` → **del**（a 側の行を消した扱い）。`i` だけ進める。
  - 「下に進んだ方が LCS が長い（同じ）＝a[i] を捨てる方が得」という判断。`>=` なので同点のときは del を優先（結果の安定性のため）。
- それ以外 → **add**（b 側の行を足した扱い）。`j` だけ進める。

各 `ops` 要素が持つ情報:
- `type`: 'equal' | 'del' | 'add'
- `aIndex` / `bIndex`: 元の行番号（0 始まり）。行番号表示に使う。
- `text`: 行の中身。

```js
  while (i < n) { ops.push({ type: 'del', aIndex: i, text: a[i] }); i++; }
  while (j < m) { ops.push({ type: 'add', bIndex: j, text: b[j] }); j++; }
  return ops;
}
```

- 片方が先に終端に達したら、残りは全部 del（a の残り）か add（b の残り）。
- `ops` は「先頭から順に並んだ操作列」。**この時点では「変更（mod）」という概念はまだ無い**点に注意（変更は「del が続いた直後に add が続く」形で現れる。まとめるのは `build2Way` の仕事）。

### 具体例

```
a = ["SELECT", "  x,", "FROM t"]
b = ["SELECT", "  x,", "  y,", "FROM t"]
```

結果:
```
equal SELECT
equal   x,
add     y,      ← b だけにある
equal FROM t
```

---

## 3. `lcsMatchFlags(a, b)` — 一致フラグの配列（38〜53行目）

```js
function lcsMatchFlags(a, b) { ... }
```

`diffLines` とほぼ同じ DP ですが、返すものが違います。**a の各要素が LCS に入っている（=b にも共通で存在する）か**を `true/false` の配列で返します。

```js
  const flags = new Array(n).fill(false);
  let i = 0, j = 0;
  while (i < n && j < m) {
    if (a[i] === b[j]) { flags[i] = true; i++; j++; }   // 共通 → true
    else if (dp[i + 1][j] >= dp[i][j + 1]) { i++; }      // a[i] は共通でない（false のまま）
    else { j++; }
  }
  return flags;
}
```

- 一致した位置だけ `flags[i] = true`。それ以外は初期値の `false` のまま。
- これは後で「base 行の各トークンが、相手（after/ref）に**存在するか**」を判定し、**存在しない＝変わった箇所**をハイライトするために使います（`baseCell`）。

---

## 4. 行内差分のための小道具

### 4.1 `tokenize(s)`（56〜58行目）

```js
function tokenize(s) {
  return s.match(/([A-Za-z0-9_]+|\s+|[^\sA-Za-z0-9_])/g) || [];
}
```

文字列を**トークン**に分割します。正規表現は「英数字と `_` の連続」「空白の連続」「それ以外の記号1文字」のいずれかにマッチ。

```
"u.name = 'A'"
→ ["u", ".", "name", " ", "=", " ", "'", "A", "'"]
```

- 文字単位より「語・記号」単位の方が、差分が意味的に読みやすくなります（`name`→`id` を「単語まるごと変わった」と扱える）。
- `|| []` は「マッチ 0 個（空文字列など）」のとき `null` を空配列に変える保険。

### 4.2 `mergeSegs(segs)`（61〜69行目）

```js
function mergeSegs(segs) {
  const out = [];
  for (const seg of segs) {
    const last = out[out.length - 1];
    if (last && last.hi === seg.hi) last.text += seg.text; // 直前と同じ hi なら結合
    else out.push({ text: seg.text, hi: seg.hi });
  }
  return out;
}
```

`{text, hi}`（hi=ハイライトするか）の並びで、**隣り合う同じ hi をくっつけて**セグメント数を減らします。これで HTML の `<span>` が無駄に増えません。

```
[{a,false},{b,false},{c,true}] → [{ab,false},{c,true}]
```

### 4.3 `wordDiff(oldStr, newStr)`（72〜90行目）

変更行の「どの文字（トークン）が変わったか」を求めます。中身は §2 と同じ LCS ですが、**トークン列**に対して行い、旧・新それぞれの「ハイライトすべき部分」を返します。

```js
  const A = tokenize(oldStr), B = tokenize(newStr);
  ... DP を埋める（diffLines と同型）...
  const oldSegs = [], newSegs = [];
  let i = 0, j = 0;
  while (i < n && j < m) {
    if (A[i] === B[j]) { oldSegs.push({text:A[i],hi:false}); newSegs.push({text:B[j],hi:false}); i++; j++; }
    else if (dp[i+1][j] >= dp[i][j+1]) { oldSegs.push({text:A[i],hi:true}); i++; } // 旧だけにある → 旧を強調
    else { newSegs.push({text:B[j],hi:true}); j++; }                               // 新だけにある → 新を強調
  }
  ... 残りを push（旧は hi:true、新は hi:true）...
  return { oldSegs: mergeSegs(oldSegs), newSegs: mergeSegs(newSegs) };
```

- 共通トークンは両側 `hi:false`（変わっていない）。
- 旧だけのトークンは `oldSegs` に `hi:true`、新だけのトークンは `newSegs` に `hi:true`。
- 最後に `mergeSegs` で整えて返す。

例: `"ORDER BY u.name;"` → `"ORDER BY u.created_at DESC;"`
- `newSegs` は `u.` の後の `name` の代わりに入った `created_at DESC` 付近が `hi:true` になる。

---

## 5. `build2Way(aLines, bLines)` — 2ファイルの行データ（98〜143行目）

`diffLines` の `ops` を、画面の左右に並べる行に変換します。**肝は「del の連続 → 直後の add の連続」をペアにして「変更（mod）」にまとめる**こと。

```js
  const ops = diffLines(aLines, bLines);
  const rows = [];
  let k = 0;
  while (k < ops.length) {
    if (ops[k].type === 'equal') { ...左右同じ行を push...; k++; continue; }
```

- `equal` はそのまま左右に同じ内容を置く（`kind:'plain'`）。行番号は `aIndex+1` / `bIndex+1`（表示は1始まり）。

```js
    const dels = [];
    while (k < ops.length && ops[k].type === 'del') dels.push(ops[k++]);
    const adds = [];
    while (k < ops.length && ops[k].type === 'add') adds.push(ops[k++]);
    const max = Math.max(dels.length, adds.length);
```

- equal でなければ、**連続する del をすべて集め**、続いて**連続する add をすべて集める**。
- `max` は多い方の件数。

```js
    for (let p = 0; p < max; p++) {
      const d = dels[p], a = adds[p];
      if (d && a) {                       // del と add が揃う → 変更(mod)
        const w = wordDiff(d.text, a.text);
        rows.push({ type:'mod',
          left:  { num:d.aIndex+1, segs:w.oldSegs, kind:'del' },
          right: { num:a.bIndex+1, segs:w.newSegs, kind:'add' } });
      } else if (d) {                     // del だけ余る → 削除
        rows.push({ type:'del', left:{num:d.aIndex+1, segs:[{text:d.text,hi:false}], kind:'del'}, right:null });
      } else {                            // add だけ余る → 追加
        rows.push({ type:'add', left:null, right:{num:a.bIndex+1, segs:[{text:a.text,hi:false}], kind:'add'} });
      }
    }
```

位置 `p` ごとにペアを見て:
- **両方ある** → 変更行。左は旧テキストのハイライト（`oldSegs`）、右は新テキストのハイライト（`newSegs`）。
- **del だけ** → 削除行（右は `null`＝空セル）。
- **add だけ** → 追加行（左は `null`）。

この「連続 del と連続 add を位置で突き合わせる」やり方が、一般的な差分ツールの「変更行」表示と同じ挙動になります。

row の構造まとめ:
```
row = { type:'equal'|'mod'|'del'|'add', left, right }
left/right = { num:行番号, segs:[{text,hi}...], kind:'plain'|'add'|'del' } | null
```

---

## 6. 3ファイル（3-way）のための関数

3ペインは「左端 base を基準」に、after と ref を base に対応づけます。

### 6.1 `segsText(cell)`（145〜147行目）

```js
function segsText(cell) {
  return cell && cell.segs ? cell.segs.map((s) => s.text).join('') : '';
}
```

セグメント配列 `[{text},{text}...]` を連結して**元の1行テキストに戻す**だけのヘルパー。次の `mapToBase` で使います。

### 6.2 `mapToBase(base, other)`（156〜174行目）

base の各行に対して、other 側が「同じ／変更／削除／該当なし」のどれかを表す対応表を作ります。**ポイントは、独自ロジックではなく `build2Way` を再利用**していること（過去に独自実装で行がズレる不具合があったため）。

```js
  const rows = build2Way(base, other);      // ← 正しいペアリングを再利用
  const of = new Array(base.length).fill(undefined);
  const inserts = new Map();
  let lastBaseIdx = 0;
  for (const r of rows) {
    if (r.left) {                           // base 行がある（equal / mod / del）
      const b = r.left.num - 1;
      if (r.right) of[b] = { text: segsText(r.right), changed: r.type === 'mod' }; // equal or mod
      else of[b] = null;                    // del: other で削除された
      lastBaseIdx = b + 1;
    } else if (r.right) {                   // base 行がない（other だけの追加）
      const arr = inserts.get(lastBaseIdx) || [];
      arr.push(segsText(r.right));           // 「base 何行目の前に挿入するか」で貯める
      inserts.set(lastBaseIdx, arr);
    }
  }
  return { of, inserts };
```

出力の意味:
- `of[b]`:
  - `{ text, changed:false }` … base の b 行目は other でも同じ（equal）
  - `{ text, changed:true }` … 変更されている（mod）。`text` は other 側の新しい行
  - `null` … other で削除された
  - `undefined` … （通常起きないが）未対応
- `inserts`: `Map(アンカー番号 → [other だけの行テキスト...])`。「base の何行目の直前に差し込むか」を記録。

### 6.3 `baseCell(baseText, aOf, rOf)`（180〜204行目）

3-way の**左端 base セル**を作ります。目的は「after か ref のどちらかと違う文字を、base 側でもハイライトする」こと。

```js
  const removed = (aOf === null) || (rOf === null);
  const afterChanged = aOf && aOf.changed;
  const refChanged = rOf && rOf.changed;

  if (!afterChanged && !refChanged && !removed) {
    return { kind: 'base', segs: [{ text: baseText, hi: false }] };   // どこも差分なし
  }
  if (removed && !afterChanged && !refChanged) {
    return { kind: 'diff', segs: [{ text: baseText, hi: false }] };   // 相手が削除だけ → 行全体を差分色（文字単位は無し）
  }
```

- どちらとも同じ → `kind:'base'`（ハイライト無し）。
- 片方が「削除」なだけ（変更ではない）→ `kind:'diff'` で**行全体**を差分扱い（背景色＋左バーで表現、文字ハイライトはしない）。

```js
  const toks = tokenize(baseText);
  const matchedAll = new Array(toks.length).fill(true);
  const targets = [];
  if (afterChanged) targets.push(aOf.text);
  if (refChanged) targets.push(rOf.text);
  for (const tgt of targets) {
    const m = lcsMatchFlags(toks, tokenize(tgt));
    for (let i = 0; i < toks.length; i++) matchedAll[i] = matchedAll[i] && m[i];
  }
  const segs = mergeSegs(toks.map((t, i) => ({ text: t, hi: !matchedAll[i] })));
  return { kind: 'diff', segs };
```

- base の行をトークン化。
- 変更相手（after が変更なら after のテキスト、ref も変更ならそれも）を `targets` に集める。
- 各相手に対し `lcsMatchFlags` で「base の各トークンが相手にも在るか」を求め、`matchedAll` に **AND** で畳み込む。
  - `matchedAll[i]` が `true` = **すべての相手に共通**して存在するトークン。
  - `false` = **少なくとも1つの相手と違う**トークン → ハイライト対象（`hi: !matchedAll[i]`）。
- つまり「after・ref のどれかと食い違う文字」を base 上で強調できます。

### 6.4 `build3Way(base, after, ref)`（210〜241行目）

```js
  const A = mapToBase(base, after);   // base に対する after の対応表
  const R = mapToBase(base, ref);     // base に対する ref の対応表
  const rows = [];
```

まず after と ref それぞれの対応表を作ります。

```js
  const otherCell = (m, b) => {
    const v = m.of[b];
    if (v === null || v === undefined) return { kind: 'empty' };            // 相手に対応行なし → 空（斜線ハッチ）
    if (!v.changed) return { kind: 'plain', segs: [{ text: v.text, hi: false }] }; // 同じ
    const w = wordDiff(base[b], v.text);
    return { kind: 'add', segs: w.newSegs };                                 // 変更 → 新テキストの変更箇所を強調
  };
```

after / ref 側のセルを作るヘルパー。空 / 同じ / 変更（`wordDiff` の `newSegs` で文字強調）を返します。

```js
  const emitInserts = (k) => {
    for (const t of (A.inserts.get(k) || [])) {   // after だけの行 → 中央列に追加、両端は空
      rows.push({ c1:{kind:'empty'}, c2:{kind:'add', segs:[{text:t,hi:false}]}, c3:{kind:'empty'} });
    }
    for (const t of (R.inserts.get(k) || [])) {   // ref だけの行 → 右列に追加
      rows.push({ c1:{kind:'empty'}, c2:{kind:'empty'}, c3:{kind:'add', segs:[{text:t,hi:false}]} });
    }
  };
```

「base の k 行目の直前に差し込む、other だけの行」を出力するヘルパー。after 由来は中央（c2）、ref 由来は右（c3）に置き、他の列は空にします。

```js
  for (let b = 0; b < base.length; b++) {
    emitInserts(b);                       // まず b の直前の挿入を出す
    const aCell = otherCell(A, b);
    const rCell = otherCell(R, b);
    rows.push({
      c1: baseCell(base[b], A.of[b], R.of[b]),  // 左=base（差分なら強調）
      c2: aCell,                                // 中央=after
      c3: rCell,                                // 右=ref
    });
  }
  emitInserts(base.length);                // 末尾（最後の base 行より後）の挿入
  return rows;
```

base の各行について「直前の挿入行 → その base 行（3列そろい）」の順で積みます。最後にファイル末尾の挿入を出して完成。

row の構造:
```
row = { c1, c2, c3 }
各セル = { kind:'base'|'diff'|'plain'|'add'|'empty', segs? }
```

---

## 7. `splitLines(text)`（244〜248行目）

```js
function splitLines(text) {
  const lines = String(text).split(/\r\n|\r|\n/);
  if (lines.length > 1 && lines[lines.length - 1] === '') lines.pop();
  return lines;
}
```

- 改行コード（Windows `\r\n` / 旧Mac `\r` / Unix `\n`）のどれでも分割。
- ファイル末尾が改行で終わると分割結果の最後に空文字列 `''` が付くので、それを1つだけ取り除く（幻の最終行を防ぐ）。

---

## 8. エクスポート（250行目）

```js
module.exports = { diffLines, wordDiff, build2Way, build3Way, mapToBase, splitLines, tokenize };
```

外部（`extension.js` やテスト）から使う関数を公開。`render.js` は `build2Way` / `build3Way` / `splitLines` を使います。

---

## 9. 全体の呼び出しフロー（まとめ）

```
splitLines(テキスト)           … 各ファイルを行配列に
        │
        ▼
2ファイル:  build2Way(a, b)
              └ diffLines(a,b) → equal/del/add
                 └ del×add をペア化 → mod、余りは del/add
                    └ mod は wordDiff で行内強調
        │
3ファイル:  build3Way(base, after, ref)
              ├ mapToBase(base, after)  ← build2Way を再利用
              ├ mapToBase(base, ref)
              └ 各 base 行を baseCell / otherCell で3列に
                 └ baseCell は lcsMatchFlags で「相手と違う文字」を強調
        │
        ▼
   render.js が色と HTML を付けて出力
```

### 学習のための確認クイズ
1. `dp` を「後ろから」埋めるのはなぜ？（ヒント: 参照する値がどこにあるか）
2. `diffLines` の時点で「変更(mod)」が無いのはなぜ？ どこで mod になる？
3. `baseCell` で `matchedAll` を **AND** で畳み込むと、どんなトークンが `hi:true` になる？
4. `mapToBase` が独自実装ではなく `build2Way` を再利用している利点は？

（答えは本文中にすべてあります。探してみてください。）
