'use strict';
const test = require('node:test');
const assert = require('node:assert');
const { build2Way } = require('../lib/diff');
const { renderFragment2 } = require('../lib/render');

const rows = build2Way(['SELECT a', 'FROM t'], ['SELECT a', 'FROM t2']);

test('render: 既定では既定サイズ・行間・既定フォントで出力', () => {
  const html = renderFragment2('a.sql', 'b.sql', rows);
  assert.ok(html.includes('font-size:12px'));
  assert.ok(html.includes('line-height:1.35'));
  assert.ok(html.includes('Roboto Mono'));
});

test('render: フォント/サイズ/行間/シンタックス色を上書きできる', () => {
  const html = renderFragment2('a.sql', 'b.sql', rows, {
    fontSize: 16,
    lineHeight: 2,
    fontFamily: "'Consolas', monospace",
    syntax: { keyword: '#ABCDEF' },
  });
  assert.ok(html.includes('font-size:16px'));
  assert.ok(html.includes('line-height:2'));
  assert.ok(html.includes("'Consolas', monospace"));
  assert.ok(html.includes('#ABCDEF'));
});

test('render: ペイン基本色を変えると出力（導出色）が変わる', () => {
  const base = renderFragment2('a.sql', 'b.sql', rows);
  const changed = renderFragment2('a.sql', 'b.sql', rows, { colors: { afterColor: '#3366CC' } });
  assert.notEqual(base, changed);
  // カラーバー（基本色そのもの）が出力に含まれる＝補助色が追従
  assert.ok(changed.includes('#3366CC') || changed.toUpperCase().includes('#3366CC'));
});

test('render: 透過度で濃さが変わる', () => {
  const light = renderFragment2('a.sql', 'b.sql', rows, { diffLineOpacity: 0.1 });
  const dark = renderFragment2('a.sql', 'b.sql', rows, { diffLineOpacity: 0.6 });
  assert.notEqual(light, dark);
});

test('render: 不正なカラー値は無視して既定を使う', () => {
  const html = renderFragment2('a.sql', 'b.sql', rows, { colors: { baseColor: 'not-a-color' } });
  assert.ok(html.includes('<table')); // 例外なく描画される
});

test('render: 上書き後に既定へ戻る（状態が残らない）', () => {
  renderFragment2('a.sql', 'b.sql', rows, { fontSize: 20 });
  const html = renderFragment2('a.sql', 'b.sql', rows);
  assert.ok(html.includes('font-size:12px'));
  assert.ok(!html.includes('font-size:20px'));
});
