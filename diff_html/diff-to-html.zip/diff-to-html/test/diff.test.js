'use strict';
const test = require('node:test');
const assert = require('node:assert');
const { diffLines, wordDiff, build2Way, build3Way, splitLines } = require('../lib/diff');

test('diffLines: 完全一致は全て equal', () => {
  const ops = diffLines(['a', 'b'], ['a', 'b']);
  assert.deepEqual(ops.map((o) => o.type), ['equal', 'equal']);
});

test('diffLines: 追加を検出', () => {
  const ops = diffLines(['a', 'c'], ['a', 'b', 'c']);
  assert.deepEqual(ops.map((o) => o.type), ['equal', 'add', 'equal']);
});

test('diffLines: 削除を検出', () => {
  const ops = diffLines(['a', 'b', 'c'], ['a', 'c']);
  assert.deepEqual(ops.map((o) => o.type), ['equal', 'del', 'equal']);
});

test('build2Way: 置換は mod 行になり行内ハイライトを持つ', () => {
  const rows = build2Way(['ORDER BY u.name;'], ['ORDER BY u.created_at DESC;']);
  assert.equal(rows.length, 1);
  assert.equal(rows[0].type, 'mod');
  assert.ok(rows[0].left.segs.some((s) => s.hi));
  assert.ok(rows[0].right.segs.some((s) => s.hi));
});

test('build2Way: 追加行は左が空(null)・右が add', () => {
  const rows = build2Way(['FROM t'], ['FROM t', 'WHERE x=1']);
  const added = rows.find((r) => r.type === 'add');
  assert.ok(added);
  assert.equal(added.left, null);
  assert.equal(added.right.kind, 'add');
});

test('wordDiff: 変更トークンのみ hi=true', () => {
  const { newSegs } = wordDiff("u.type = 'A'", "u.type = 'B'");
  const hi = newSegs.filter((s) => s.hi).map((s) => s.text).join('');
  assert.equal(hi, 'B');
});

test('build3Way: base 行が並び、base差分ハイライト・挿入・reference変更を検出', () => {
  const base = ['WHERE u.active = 1', "  AND u.type = 'A'"];
  const after = ['WHERE u.active = 1', "  AND u.type = 'A'", '  AND u.flag = 1'];
  const ref = ['WHERE u.active = 1', "  AND u.type = 'B'"];
  const rows = build3Way(base, after, ref);
  // base 行（kind: 'base' or 'diff'）が2つ
  const baseRows = rows.filter((r) => r.c1 && r.c1.segs && (r.c1.kind === 'base' || r.c1.kind === 'diff'));
  assert.equal(baseRows.length, 2);
  // after 側に挿入行（c2 が add で c1/c3 empty）がある
  assert.ok(rows.some((r) => r.c1.kind === 'empty' && r.c2.kind === 'add' && r.c3.kind === 'empty'));
  // reference 側の変更行（c3 が add）がある
  assert.ok(rows.some((r) => r.c3.kind === 'add'));
  // reference が変わった base 行は 'diff' になり、行内ハイライトを持つ
  const changedBase = rows.find((r) => r.c1 && r.c1.kind === 'diff' && r.c1.segs.some((s) => s.hi));
  assert.ok(changedBase);
});

test('splitLines: 末尾改行の余分な空行を除去', () => {
  assert.deepEqual(splitLines('a\nb\n'), ['a', 'b']);
  assert.deepEqual(splitLines('a\nb'), ['a', 'b']);
});
