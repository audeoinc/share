-- Monthly sales summary report
-- Aggregates paid orders only by customer and month
WITH monthly AS (
    SELECT
        o.customer_id,
        DATE_TRUNC('month', o.created_at) AS month,
        COUNT(*) AS order_count,
        SUM(o.amount) AS total_amount,
        MAX(o.amount) AS max_amount
    FROM orders o
    WHERE o.status = 'paid'
      AND o.channel = 'web'
      AND o.created_at >= '2026-01-01'
    GROUP BY o.customer_id, DATE_TRUNC('month', o.created_at)
)
SELECT
    c.id,
    c.name,
    c.email,
    m.month,
    m.order_count,
    m.total_amount,
    m.max_amount,
    CASE
        WHEN m.total_amount >= 100000 THEN 'Gold'
        WHEN m.total_amount >= 10000 THEN 'Silver'
        ELSE 'Bronze'
    END AS grade
FROM customers c
JOIN monthly m ON m.customer_id = c.id
WHERE c.active = 1
  AND c.deleted = 0
  AND c.type <> 'test'
ORDER BY m.month, m.total_amount DESC;
