# 検証用サンプル SQL

差分表示のデザインを網羅確認するためのテストデータです。月次売上サマリ（CTE・サブクエリ・CASE 式を含む、約30〜36行）を題材にしています。

## ファイル
- `sample_a_base.sql` … 基準（before / base）
- `sample_b_after.sql` … 修正後（after）
- `sample_c_reference.sql` … 参考（reference）

## 使い方
- **2ファイル比較:** `sample_a_base.sql` と `sample_b_after.sql` を選択 → 右クリック →「Diff to HTML」
- **3ファイル比較:** A → B → C の順に3つ選択 → 同上（選択順に左から。基準は左端 A）

## 網羅している差分デザイン

### 2ファイル比較（A vs B）
- **一致（equal）**、**追加（add）**、**削除（del）**、**変更（mod, 行内ハイライト）** の4種すべて
- 変更例: 先頭コメント、CTE の集計列（`SUM`/`COUNT` の増減）、`WHERE` の条件（`status = 'paid'` → `IN ('paid','refunded')`）、日付、`CASE` のしきい値とラベル、`ORDER BY`
- 追加例: `c.region` / `m.total_tax` / `LEFT JOIN regions ...`
- 削除例: `AND c.type <> 'test'`（B で削除）
- **長い行の折り返し**（`WHERE ... IN (...)` など）、**インデント保持**

### 3ファイル比較（A / B / C, 基準=左端A）
- **base の差分ハイライト**: after / reference のどちらかと異なる base 行を、行内まで含めて強調
- **列ごとに異なる変更**: 例）2行目コメントは A/B/C すべて異なる、`CASE` のラベルは B=`S/A/B/C`・C=`Gold/Silver/Bronze` と別々
- **片側だけの挿入**: B だけの `SUM(o.tax)` / `LEFT JOIN`、C だけの `MAX(o.amount)` / `AND o.channel = 'web'`
- **片側だけ削除された行**: `AND c.deleted = 0` / `AND c.type <> 'test'` は A・C にあり B で削除（B 列は斜線ハッチ）
