-- Monthly sales summary report (v2, with region & tax)
-- Aggregates paid/refunded orders by customer and month
WITH monthly AS (
    SELECT
        o.customer_id,
        DATE_TRUNC('month', o.created_at) AS month,
        COUNT(*) AS order_count,
        SUM(o.amount) AS total_amount,
        SUM(o.tax) AS total_tax
    FROM orders o
    WHERE o.status IN ('paid', 'refunded')
      AND o.amount > 0
      AND o.created_at >= '2026-04-01'
    GROUP BY o.customer_id, DATE_TRUNC('month', o.created_at)
)
SELECT
    c.id,
    c.name,
    c.email,
    c.region,
    m.month,
    m.order_count,
    m.total_amount,
    m.total_tax,
    CASE
        WHEN m.total_amount >= 150000 THEN 'S'
        WHEN m.total_amount >= 50000 THEN 'A'
        WHEN m.total_amount >= 20000 THEN 'B'
        ELSE 'C'
    END AS grade
FROM customers c
JOIN monthly m ON m.customer_id = c.id
LEFT JOIN regions r ON r.code = c.region_code
WHERE c.active = 1
  AND c.region_code IS NOT NULL
ORDER BY m.total_amount DESC, c.name;
