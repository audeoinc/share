# Debug SQL array type fix

`JSON_QUERY_ARRAY()` returns `ARRAY<JSON>`.
All fallback empty arrays used with it must therefore be explicitly typed as:

```sql
CAST([] AS ARRAY<JSON>)
```

Do not use `ARRAY<STRING>[]` in the same `COALESCE()` expression.

Files checked:

- `sql/pipeline/03_run_daily_lineage_pipeline_debug.sql`
- `sql/debug/debug_v_customer_primary_contact.sql`
