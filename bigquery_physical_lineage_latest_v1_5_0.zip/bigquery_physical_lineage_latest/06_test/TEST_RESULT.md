# Regression Test Result

Version: 1.5.0  
Date: 2026-07-21  
Runtime: Node.js v22.16.0

```text
PASS 01_test_statement_parser.js
PASS 02_test_query_regression.js
PASS 03_test_bigquery_entry.js
PASS 04_test_failure_contract.js
PASS 05_test_statement_integration.js
PASS 06_test_registry_sync_contract.js
PASS 07_test_struct_array_physical_lineage.js

Test files: 7
Passed:     7
Failed:     0
```

The STRUCT / ARRAY suite verifies exact nested field matching, UNNEST alias
propagation, and the public BigQuery compact-export lineage path contract.
