'use strict';

const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');

const root = path.join(__dirname, '..');
const syncSql = fs.readFileSync(
  path.join(root, '04_pipeline', '01_sync_definition_registry.sql'),
  'utf8'
);
const repositorySql = fs.readFileSync(
  path.join(root, '03_repository', '01_create_repository_tables.sql'),
  'utf8'
);

function contains(pattern, label) {
  assert.match(syncSql, pattern, label);
}

contains(/INFORMATION_SCHEMA\.VIEWS/, 'VIEW source must be present');
contains(/INFORMATION_SCHEMA\.JOBS_BY_PROJECT/, 'JOBS source must be present');
contains(/CREATE TEMP TABLE definition_inventory/i, 'unified inventory must be present');
contains(/query_text\s+AS\s+definition_text/i, 'raw JOB SQL must be retained');
contains(/TO_HEX\(SHA256\(query_text\)\)/i, 'raw JOB SQL must drive the hash');
contains(/QUALIFY\s+ROW_NUMBER\(\)\s+OVER/i, 'latest generated-table job selection must be present');
contains(/creation_time\s+DESC,\s*job_id\s+DESC/i, 'latest job ordering must be deterministic');
contains(/audeodb@appspot\.gserviceaccount\.com/i, 'approved DAG service account must be configured');
contains(/INACTIVE_OBJECT_NOT_FOUND/i, 'missing-object inactivation must be present');
contains(/INFORMATION_SCHEMA\.TABLES/i, 'physical TABLE existence check must be present');
contains(/MERGE\s+`audeodb\.lineage_repository\.lineage_definition_registry`/i, 'definition registry MERGE must be present');

assert.doesNotMatch(
  syncSql,
  /extract_ctas_query|REGEXP_REPLACE\s*\([^)]*CREATE\s+TABLE/is,
  'CTAS extraction must not be implemented in synchronization SQL'
);
assert.doesNotMatch(
  syncSql,
  /CREATE TABLE IF NOT EXISTS\s+`audeodb\.lineage_repository\.lineage_job_registry`/i,
  'daily pipeline must not own persistent repository DDL'
);
assert.match(
  repositorySql,
  /CREATE TABLE IF NOT EXISTS\s+`audeodb\.lineage_repository\.lineage_job_registry`/i,
  'initial repository setup must create lineage_job_registry'
);

console.log('Registry synchronization contract assertions passed.');
