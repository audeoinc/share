SET @@location = 'asia-northeast1';

-- Run the following before this validation:
--   1. 01_sample/03_struct_array_regression.sql
--   2. 04_pipeline/01_sync_definition_registry.sql
--   3. 04_pipeline/02_analyze_changed_objects.sql
--   4. 04_pipeline/03_rebuild_impact_table.sql

DECLARE failed_test_count INT64 DEFAULT 0;

CREATE TEMP TABLE validation_results AS
WITH expected_direct_dependencies AS (
  SELECT *
  FROM UNNEST([
    STRUCT(
      'v_lineage_struct_level1' AS target_object,
      'customer_name' AS target_column,
      'customer.name' AS expected_source_column
    ),
    STRUCT(
      'v_lineage_struct_level1',
      'customer_city',
      'customer.address.city'
    ),
    STRUCT(
      'v_lineage_array_struct_level1',
      'order_id',
      'orders.order_id'
    ),
    STRUCT(
      'v_lineage_array_struct_level1',
      'amount',
      'orders.amount'
    ),
    STRUCT(
      'v_lineage_array_struct_level1',
      'product_id',
      'orders.product.product_id'
    ),
    STRUCT(
      'v_lineage_array_struct_level1',
      'product_category',
      'orders.product.category'
    )
  ])
),
direct_dependency_tests AS (
  SELECT
    FORMAT(
      'direct:%s.%s',
      expected.target_object,
      expected.target_column
    ) AS test_name,
    COUNTIF(
      dependency.source_project = 'audeodb'
      AND dependency.source_dataset = 'sample_ds'
      AND dependency.source_object = 'lineage_nested_source'
      AND dependency.source_column = expected.expected_source_column
    ) > 0 AS passed,
    expected.expected_source_column AS expected_value,
    STRING_AGG(
      DISTINCT dependency.source_column,
      ', '
      ORDER BY dependency.source_column
    ) AS actual_value
  FROM expected_direct_dependencies AS expected
  LEFT JOIN
    `audeodb.lineage_repository.lineage_direct_dependency` AS dependency
    ON dependency.target_project = 'audeodb'
   AND dependency.target_dataset = 'sample_ds'
   AND dependency.target_object = expected.target_object
   AND dependency.target_column = expected.target_column
  GROUP BY
    expected.target_object,
    expected.target_column,
    expected.expected_source_column
),
false_positive_tests AS (
  SELECT
    FORMAT(
      'exact-path:%s.%s',
      expected.target_object,
      expected.target_column
    ) AS test_name,
    COUNTIF(
      dependency.source_column != expected.expected_source_column
      AND STARTS_WITH(
        dependency.source_column,
        SPLIT(expected.expected_source_column, '.')[SAFE_OFFSET(0)]
      )
    ) = 0 AS passed,
    expected.expected_source_column AS expected_value,
    STRING_AGG(
      DISTINCT dependency.source_column,
      ', '
      ORDER BY dependency.source_column
    ) AS actual_value
  FROM expected_direct_dependencies AS expected
  LEFT JOIN
    `audeodb.lineage_repository.lineage_direct_dependency` AS dependency
    ON dependency.target_project = 'audeodb'
   AND dependency.target_dataset = 'sample_ds'
   AND dependency.target_object = expected.target_object
   AND dependency.target_column = expected.target_column
  GROUP BY
    expected.target_object,
    expected.target_column,
    expected.expected_source_column
),
field_path_metadata_tests AS (
  SELECT
    FORMAT('metadata:%s', expected_field_path) AS test_name,
    COUNTIF(
      LOWER(field_path) = expected_field_path
    ) > 0 AS passed,
    expected_field_path AS expected_value,
    STRING_AGG(
      DISTINCT LOWER(field_path),
      ', '
      ORDER BY LOWER(field_path)
    ) AS actual_value
  FROM UNNEST([
    'customer.name',
    'customer.address.city',
    'orders.order_id',
    'orders.amount',
    'orders.product.product_id',
    'orders.product.category'
  ]) AS expected_field_path
  LEFT JOIN
    `audeodb.sample_ds.INFORMATION_SCHEMA.COLUMN_FIELD_PATHS`
      AS field_info
    ON LOWER(field_info.table_name) = 'lineage_nested_source'
   AND LOWER(field_info.field_path) = expected_field_path
  GROUP BY expected_field_path
),
rank_two_tests AS (
  SELECT
    FORMAT(
      'rank2:%s.%s',
      expected.impacted_object,
      expected.impacted_column
    ) AS test_name,
    COUNT(impact.path_hash) > 0 AS passed,
    FORMAT(
      '%s.%s',
      expected.expected_origin_object,
      expected.expected_origin_column
    ) AS expected_value,
    STRING_AGG(
      DISTINCT FORMAT(
        '%s.%s',
        impact.origin_object,
        impact.origin_column
      ),
      ', '
      ORDER BY FORMAT(
        '%s.%s',
        impact.origin_object,
        impact.origin_column
      )
    ) AS actual_value
  FROM UNNEST([
    STRUCT(
      'v_lineage_nested_level2' AS impacted_object,
      'customer_city' AS impacted_column,
      'lineage_nested_source' AS expected_origin_object,
      'customer.address.city' AS expected_origin_column
    ),
    STRUCT(
      'v_lineage_nested_level2',
      'product_category',
      'lineage_nested_source',
      'orders.product.category'
    )
  ]) AS expected
  LEFT JOIN
    `audeodb.lineage_repository.lineage_impact` AS impact
    ON impact.impact_rank >= 2
   AND impact.impacted_project = 'audeodb'
   AND impact.impacted_dataset = 'sample_ds'
   AND impact.impacted_object = expected.impacted_object
   AND impact.impacted_column = expected.impacted_column
   AND impact.origin_project = 'audeodb'
   AND impact.origin_dataset = 'sample_ds'
   AND impact.origin_object = expected.expected_origin_object
   AND impact.origin_column = expected.expected_origin_column
  GROUP BY
    expected.impacted_object,
    expected.impacted_column,
    expected.expected_origin_object,
    expected.expected_origin_column
)
SELECT * FROM direct_dependency_tests
UNION ALL
SELECT * FROM false_positive_tests
UNION ALL
SELECT * FROM field_path_metadata_tests
UNION ALL
SELECT * FROM rank_two_tests;

SET failed_test_count = (
  SELECT COUNT(*)
  FROM validation_results
  WHERE passed = FALSE
);

SELECT
  test_name,
  passed,
  expected_value,
  actual_value
FROM validation_results
ORDER BY
  passed,
  test_name;

ASSERT failed_test_count = 0
AS 'STRUCT / ARRAY<STRUCT> lineage regression failed.';
