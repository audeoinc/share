'use strict';

const fs = require('node:fs');
const path = require('node:path');
const { spawnSync } = require('node:child_process');

const testDirectory = __dirname;
const testFiles = fs.readdirSync(testDirectory)
  .filter((name) => /^\d+_test_.*\.js$/.test(name))
  .sort();

let passed = 0;
const failures = [];

for (const testFile of testFiles) {
  const startedAt = Date.now();
  const result = spawnSync(
    process.execPath,
    [path.join(testDirectory, testFile)],
    { encoding: 'utf8' }
  );
  const elapsedMs = Date.now() - startedAt;

  if (result.status === 0) {
    passed += 1;
    console.log(`PASS ${testFile} (${elapsedMs} ms)`);
    continue;
  }

  failures.push(testFile);
  console.error(`FAIL ${testFile} (${elapsedMs} ms)`);
  if (result.stdout) {
    console.error(result.stdout.trim());
  }
  if (result.stderr) {
    console.error(result.stderr.trim());
  }
}

console.log('');
console.log(`Test files: ${testFiles.length}`);
console.log(`Passed:     ${passed}`);
console.log(`Failed:     ${failures.length}`);

if (failures.length > 0) {
  process.exitCode = 1;
}
