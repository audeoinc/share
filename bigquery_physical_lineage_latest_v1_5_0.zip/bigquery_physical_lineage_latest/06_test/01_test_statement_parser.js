'use strict';

const {
  assert,
  analyze,
  assertCompleted,
  assertCtasEquivalent
} = require('./test_helpers.js');

const baseSelect = `
SELECT
  customer_id,
  SUM(amount) AS total_amount
FROM \`audeodb.sample_ds.sales\`
GROUP BY customer_id
`;

const cases = [
  {
    name: 'plain SELECT',
    sql: 'SELECT 1 AS value'
  },
  {
    name: 'WITH query',
    sql: 'WITH x AS (SELECT 1 AS value) SELECT value FROM x'
  },
  {
    name: 'WITH RECURSIVE query',
    sql: `WITH RECURSIVE nums AS (
      SELECT 1 AS n
      UNION ALL
      SELECT n + 1 FROM nums WHERE n < 3
    ) SELECT n FROM nums`
  },
  {
    name: 'leading comments',
    sql: '-- heading\n/* block */\nSELECT 1 AS value'
  },
  {
    name: 'CREATE TABLE AS SELECT',
    sql: `CREATE TABLE \`audeodb.sample_ds.out\` AS ${baseSelect}`
  },
  {
    name: 'CREATE OR REPLACE TABLE AS SELECT',
    sql: `CREATE OR REPLACE TABLE \`audeodb.sample_ds.out\` AS ${baseSelect}`
  },
  {
    name: 'CREATE TABLE IF NOT EXISTS AS SELECT',
    sql: `CREATE TABLE IF NOT EXISTS \`audeodb.sample_ds.out\` AS ${baseSelect}`
  },
  {
    name: 'CREATE TEMP TABLE AS SELECT',
    sql: 'CREATE TEMP TABLE temp_out AS SELECT 1 AS value'
  },
  {
    name: 'CREATE TEMPORARY TABLE AS SELECT',
    sql: 'CREATE TEMPORARY TABLE temp_out AS SELECT 1 AS value'
  },
  {
    name: 'CTAS with PARTITION CLUSTER OPTIONS',
    sql: `CREATE OR REPLACE TABLE \`audeodb.sample_ds.out\`
      PARTITION BY DATE(created_at)
      CLUSTER BY customer_id
      OPTIONS(
        description = 'AS SELECT inside string',
        labels = [('purpose', 'lineage')]
      )
      AS WITH x AS (
        SELECT customer_id, CURRENT_TIMESTAMP() AS created_at
        FROM \`audeodb.sample_ds.sales\`
      )
      SELECT * FROM x`
  },
  {
    name: 'CTAS ignores AS SELECT in comments',
    sql: `CREATE TABLE \`audeodb.sample_ds.out\`
      OPTIONS(description='safe')
      /* AS SELECT fake */
      AS SELECT 1 AS value`
  },
  {
    name: 'CTAS ignores nested AS SELECT tokens',
    sql: `CREATE TABLE \`audeodb.sample_ds.out\`
      OPTIONS(description=('x'))
      AS SELECT 1 AS value`
  }
];

for (const testCase of cases) {
  const result = analyze(testCase.sql);
  assertCompleted(result, testCase.name);
}

assertCtasEquivalent(
  baseSelect,
  `CREATE OR REPLACE TABLE \`audeodb.sample_ds.out\` AS ${baseSelect}`,
  'simple CTAS equivalence'
);

const withSelect = `WITH x AS (
  SELECT customer_id FROM \`audeodb.sample_ds.sales\`
)
SELECT customer_id FROM x`;

assertCtasEquivalent(
  withSelect,
  `CREATE TABLE \`audeodb.sample_ds.out\`
    PARTITION BY customer_id
    OPTIONS(description='test')
    AS ${withSelect}`,
  'WITH CTAS equivalence'
);

assertCtasEquivalent(
  'SELECT 1 AS value',
  'CREATE VIEW `audeodb.sample_ds.v_out` AS SELECT 1 AS value',
  'CREATE VIEW equivalence'
);

assertCtasEquivalent(
  withSelect,
  `CREATE OR REPLACE MATERIALIZED VIEW ` +
    '`audeodb.sample_ds.mv_out`' +
    ` OPTIONS(enable_refresh=true) AS ${withSelect}`,
  'CREATE MATERIALIZED VIEW equivalence'
);
