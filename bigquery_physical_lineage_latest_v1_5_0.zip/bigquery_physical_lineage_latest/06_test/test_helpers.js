'use strict';

const assert = require('node:assert/strict');
const path = require('node:path');
const {
  LineageEngine,
  analyzeLineageForBigQuery
} = require(path.join('..', '02_udf', 'lineage_udf_bundle.js'));

function analyze(sql, options = {}) {
  const engine = new LineageEngine({
    strictMode: options.strictMode !== false,
    physicalColumns: options.physicalColumns ?? []
  });
  return engine.analyze(sql, options.analyzeOptions ?? {});
}

function assertCompleted(result, label) {
  assert.ok(result, `${label}: result is missing`);
  assert.equal(result.failed_stage, null, `${label}: failed_stage must be null`);
  assert.ok(
    result.analysis_status === 'COMPLETED'
      || result.analysis_status === 'COMPLETED_WITH_WARNINGS',
    `${label}: unexpected status ${result.analysis_status}`
  );
  const errors = (result.diagnostics ?? []).filter((item) => item.severity === 'ERROR');
  assert.equal(errors.length, 0, `${label}: ERROR diagnostics found`);
  assert.equal(result.query_ast?.node_type, 'QUERY', `${label}: QUERY AST missing`);
}

function clauseTypes(result) {
  return (result.query_ast?.clauses ?? []).map((item) => item.clause_type);
}

function outputAliases(result) {
  return (result.query_ast?.select ?? []).map((item) => item.output_alias);
}

function physicalSources(result) {
  const scopes = result.resolutions?.sources?.scopes ?? [];
  return scopes
    .flatMap((scope) => scope.sources ?? [])
    .filter((source) => source.source_type === 'PHYSICAL_TABLE')
    .map((source) => source.resolved_source_name ?? source.source_name)
    .sort();
}

function semanticSignature(result) {
  return {
    recursive: result.query_ast?.recursive ?? false,
    clauses: clauseTypes(result),
    outputs: outputAliases(result),
    sources: physicalSources(result),
    cteCount: result.query_ast?.common_table_expressions?.length ?? 0,
    setOperations: (result.query_ast?.set_operations ?? []).map(
      (item) => item.operator ?? item.operation_type ?? item.node_type
    )
  };
}

function assertCtasEquivalent(selectSql, ctasSql, label) {
  const selectResult = analyze(selectSql);
  const ctasResult = analyze(ctasSql);
  assertCompleted(selectResult, `${label}: SELECT`);
  assertCompleted(ctasResult, `${label}: CTAS`);
  assert.deepEqual(
    semanticSignature(ctasResult),
    semanticSignature(selectResult),
    `${label}: CTAS semantic result differs from SELECT`
  );
}

function analyzeViaBigQueryEntry(sql, options = {}) {
  const json = analyzeLineageForBigQuery(
    sql,
    JSON.stringify(options.physicalColumns ?? []),
    JSON.stringify({
      strict_mode: options.strictMode !== false,
      compact_export: options.compactExport === true
    }),
    options.exportMetadata ? JSON.stringify(options.exportMetadata) : null
  );
  return JSON.parse(json);
}

module.exports = {
  assert,
  analyze,
  assertCompleted,
  clauseTypes,
  outputAliases,
  physicalSources,
  semanticSignature,
  assertCtasEquivalent,
  analyzeViaBigQueryEntry
};
