'use strict';

const {
  assert,
  analyze
} = require('./test_helpers.js');

assert.throws(
  () => analyze('SELECT FROM'),
  /error|select|expression|parse|syntax/i,
  'strict mode must throw for malformed SQL'
);

const nonStrict = analyze('SELECT FROM', { strictMode: false });
assert.ok(
  nonStrict.analysis_status === 'PARTIAL_FAILURE'
    || nonStrict.analysis_status === 'FAILED'
    || nonStrict.analysis_status === 'COMPLETED_WITH_WARNINGS',
  `unexpected non-strict status: ${nonStrict.analysis_status}`
);
assert.ok(
  nonStrict.failed_stage !== null
    || (nonStrict.diagnostics ?? []).length > 0,
  'non-strict failure must preserve diagnostics or failed stage'
);
