'use strict';

const {
  assert,
  analyze,
  assertCompleted,
  semanticSignature,
  analyzeViaBigQueryEntry
} = require('./test_helpers.js');

const querySql = `WITH src AS (
  SELECT customer_id, amount
  FROM \`audeodb.sample_ds.sales\`
)
SELECT customer_id, SUM(amount) AS total_amount
FROM src
GROUP BY customer_id`;

const statements = [
  {
    type: 'QUERY',
    sql: querySql
  },
  {
    type: 'CREATE_TABLE_AS_SELECT',
    sql: `CREATE OR REPLACE TABLE \`audeodb.sample_ds.out_table\`
      PARTITION BY customer_id
      OPTIONS(description='formal integration')
      AS ${querySql}`
  },
  {
    type: 'CREATE_VIEW_AS_SELECT',
    sql: `CREATE OR REPLACE VIEW \`audeodb.sample_ds.out_view\`
      OPTIONS(description='formal integration')
      AS ${querySql}`
  },
  {
    type: 'CREATE_MATERIALIZED_VIEW_AS_SELECT',
    sql: `CREATE MATERIALIZED VIEW \`audeodb.sample_ds.out_mv\`
      OPTIONS(enable_refresh=true)
      AS ${querySql}`
  }
];

const baseResult = analyze(querySql);
assertCompleted(baseResult, 'base query');

for (const testCase of statements) {
  const engineResult = analyze(testCase.sql);
  assertCompleted(engineResult, testCase.type);
  assert.equal(
    engineResult.statement?.statement_type,
    testCase.type,
    `${testCase.type}: statement metadata mismatch`
  );
  assert.equal(
    engineResult.sql_text,
    testCase.sql,
    `${testCase.type}: original SQL must be preserved`
  );
  assert.ok(
    ['SELECT', 'WITH'].includes(engineResult.tokens[0]?.normalized_token),
    `${testCase.type}: QueryParser input must start with SELECT or WITH`
  );
  assert.deepEqual(
    semanticSignature(engineResult),
    semanticSignature(baseResult),
    `${testCase.type}: semantic result differs from base query`
  );

  const udfResult = analyzeViaBigQueryEntry(testCase.sql);
  assert.equal(
    udfResult.statement?.statement_type,
    testCase.type,
    `${testCase.type}: BigQuery entry statement metadata mismatch`
  );
  assert.equal(
    udfResult.sql_text,
    testCase.sql,
    `${testCase.type}: BigQuery entry must preserve original SQL`
  );

  const exportedResult = analyzeViaBigQueryEntry(testCase.sql, {
    exportMetadata: {
      analysis_id: `integration-${testCase.type}`,
      view_project: 'audeodb',
      view_dataset: 'sample_ds',
      view_name: 'statement_test',
      analyzed_at: '2026-07-21T00:00:00Z'
    }
  });
  assert.equal(
    exportedResult.analysis?.statement_type,
    testCase.type,
    `${testCase.type}: exported analysis statement metadata mismatch`
  );
}

assert.throws(
  () => analyze('INSERT INTO `audeodb.sample_ds.out` SELECT 1'),
  /STATEMENT_PARSER.*unsupported statement start/i,
  'unsupported statement must fail at STATEMENT_PARSER'
);
