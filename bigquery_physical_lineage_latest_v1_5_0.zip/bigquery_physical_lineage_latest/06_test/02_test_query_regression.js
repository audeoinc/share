'use strict';

const {
  assert,
  analyze,
  assertCompleted,
  clauseTypes,
  outputAliases,
  physicalSources
} = require('./test_helpers.js');

const cases = [
  {
    name: 'simple projection',
    sql: 'SELECT customer_id, customer_name FROM `p.d.customers`',
    clauses: ['SELECT', 'FROM'],
    outputs: ['CUSTOMER_ID', 'CUSTOMER_NAME'],
    sources: ['P.D.CUSTOMERS']
  },
  {
    name: 'explicit and implicit aliases',
    sql: 'SELECT customer_id AS id, customer_name name FROM `p.d.customers`',
    outputs: ['ID', 'NAME']
  },
  {
    name: 'join and on',
    sql: `SELECT c.customer_id, o.order_id
      FROM \`p.d.customers\` AS c
      LEFT JOIN \`p.d.orders\` AS o
        ON c.customer_id = o.customer_id`,
    sources: ['P.D.CUSTOMERS', 'P.D.ORDERS']
  },
  {
    name: 'where group having qualify order limit',
    sql: `SELECT customer_id, SUM(amount) AS total,
             ROW_NUMBER() OVER (ORDER BY SUM(amount) DESC) AS rn
      FROM \`p.d.sales\`
      WHERE amount > 0
      GROUP BY customer_id
      HAVING SUM(amount) > 10
      QUALIFY rn = 1
      ORDER BY total DESC
      LIMIT 10`,
    clauses: [
      'SELECT', 'FROM', 'WHERE', 'GROUP_BY', 'HAVING',
      'QUALIFY', 'ORDER_BY', 'LIMIT'
    ]
  },
  {
    name: 'cte',
    sql: `WITH base AS (
      SELECT customer_id, amount FROM \`p.d.sales\`
    )
    SELECT customer_id, SUM(amount) AS total
    FROM base GROUP BY customer_id`,
    sources: ['P.D.SALES']
  },
  {
    name: 'nested cte',
    sql: `WITH a AS (
      SELECT customer_id, amount FROM \`p.d.sales\`
    ), b AS (
      SELECT customer_id, SUM(amount) AS total FROM a GROUP BY customer_id
    )
    SELECT customer_id, total FROM b`,
    sources: ['P.D.SALES']
  },
  {
    name: 'scalar subquery',
    sql: `SELECT c.customer_id,
      (SELECT MAX(o.amount) FROM \`p.d.orders\` o
       WHERE o.customer_id = c.customer_id) AS max_amount
      FROM \`p.d.customers\` c`,
    sources: ['P.D.CUSTOMERS', 'P.D.ORDERS']
  },
  {
    name: 'derived table',
    sql: `SELECT x.customer_id
      FROM (SELECT customer_id FROM \`p.d.customers\`) AS x`,
    sources: ['P.D.CUSTOMERS']
  },
  {
    name: 'unnest array struct',
    sql: `SELECT s.customer_id, item.order_id, item.product.category AS category
      FROM \`p.d.source\` AS s
      CROSS JOIN UNNEST(s.orders) AS item`,
    sources: ['P.D.SOURCE']
  },
  {
    name: 'struct field path',
    sql: `SELECT customer.name AS customer_name,
      customer.address.city AS city
      FROM \`p.d.source\``,
    sources: ['P.D.SOURCE']
  },
  {
    name: 'case expression',
    sql: `SELECT CASE WHEN amount > 100 THEN 'HIGH' ELSE 'LOW' END AS band
      FROM \`p.d.sales\``
  },
  {
    name: 'cast safe cast',
    sql: `SELECT CAST(amount AS STRING) AS amount_text,
      SAFE_CAST(code AS INT64) AS code_int
      FROM \`p.d.sales\``
  },
  {
    name: 'array and struct constructors',
    sql: `SELECT ARRAY_AGG(STRUCT(order_id, amount)) AS orders
      FROM \`p.d.orders\``
  },
  {
    name: 'window function',
    sql: `SELECT customer_id,
      SUM(amount) OVER (
        PARTITION BY customer_id ORDER BY order_date
        ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
      ) AS running_total
      FROM \`p.d.orders\``
  },
  {
    name: 'select star',
    sql: 'SELECT * FROM `p.d.customers`'
  },
  {
    name: 'qualified star',
    sql: 'SELECT c.* FROM `p.d.customers` AS c'
  },
  {
    name: 'star except replace',
    sql: `SELECT * EXCEPT(secret), REPLACE(UPPER(name) AS name)
      FROM \`p.d.customers\``
  },
  {
    name: 'union all',
    sql: `SELECT customer_id FROM \`p.d.customers_2025\`
      UNION ALL
      SELECT customer_id FROM \`p.d.customers_2026\``,
    sources: ['P.D.CUSTOMERS_2025', 'P.D.CUSTOMERS_2026']
  },
  {
    name: 'union distinct',
    sql: `SELECT customer_id FROM \`p.d.a\`
      UNION DISTINCT
      SELECT customer_id FROM \`p.d.b\``
  },
  {
    name: 'intersect distinct',
    sql: `SELECT customer_id FROM \`p.d.a\`
      INTERSECT DISTINCT
      SELECT customer_id FROM \`p.d.b\``
  },
  {
    name: 'except distinct',
    sql: `SELECT customer_id FROM \`p.d.a\`
      EXCEPT DISTINCT
      SELECT customer_id FROM \`p.d.b\``
  },
  {
    name: 'group by ordinal',
    sql: `SELECT customer_id, SUM(amount) AS total
      FROM \`p.d.sales\` GROUP BY 1`
  },
  {
    name: 'order by ordinal',
    sql: `SELECT customer_id, amount FROM \`p.d.sales\` ORDER BY 2 DESC`
  },
  {
    name: 'comments and quoted text',
    sql: `-- SELECT fake FROM fake
      SELECT 'FROM not clause' AS text_value, customer_id
      FROM \`p.d.customers\` /* WHERE fake */`
  }
];

for (const testCase of cases) {
  const result = analyze(testCase.sql);
  assertCompleted(result, testCase.name);

  if (testCase.clauses) {
    assert.deepEqual(clauseTypes(result), testCase.clauses, `${testCase.name}: clauses`);
  }
  if (testCase.outputs) {
    assert.deepEqual(outputAliases(result), testCase.outputs, `${testCase.name}: outputs`);
  }
  if (testCase.sources) {
    assert.deepEqual(physicalSources(result), [...testCase.sources].sort(), `${testCase.name}: sources`);
  }
}
