'use strict';

const {
  assert,
  analyze,
  assertCompleted,
  analyzeViaBigQueryEntry
} = require('./test_helpers.js');

const physicalColumns = [
  { table_name: 'p.d.source', column_name: 'customer_id', field_path: 'customer_id', ordinal_position: 1 },
  { table_name: 'p.d.source', column_name: 'customer', field_path: 'customer', ordinal_position: 2 },
  { table_name: 'p.d.source', column_name: 'customer', field_path: 'customer.name', ordinal_position: 2 },
  { table_name: 'p.d.source', column_name: 'customer', field_path: 'customer.address.city', ordinal_position: 2 },
  { table_name: 'p.d.source', column_name: 'customer', field_path: 'customer.address.postal_code', ordinal_position: 2 },
  { table_name: 'p.d.source', column_name: 'orders', field_path: 'orders', ordinal_position: 3 },
  { table_name: 'p.d.source', column_name: 'orders', field_path: 'orders.order_id', ordinal_position: 3 },
  { table_name: 'p.d.source', column_name: 'orders', field_path: 'orders.amount', ordinal_position: 3 },
  { table_name: 'p.d.source', column_name: 'orders', field_path: 'orders.product.product_id', ordinal_position: 3 },
  { table_name: 'p.d.source', column_name: 'orders', field_path: 'orders.product.category', ordinal_position: 3 }
];

const sql = `SELECT
  source.customer_id,
  source.customer.name AS customer_name,
  source.customer.address.city AS customer_city,
  item.order_id,
  item.amount,
  item.product.product_id AS product_id,
  item.product.category AS product_category
FROM \`p.d.source\` AS source
CROSS JOIN UNNEST(source.orders) AS item`;

const expected = new Map([
  ['CUSTOMER_ID', ['CUSTOMER_ID']],
  ['CUSTOMER_NAME', ['CUSTOMER.NAME']],
  ['CUSTOMER_CITY', ['CUSTOMER.ADDRESS.CITY']],
  ['ORDER_ID', ['ORDERS.ORDER_ID']],
  ['AMOUNT', ['ORDERS.AMOUNT']],
  ['PRODUCT_ID', ['ORDERS.PRODUCT.PRODUCT_ID']],
  ['PRODUCT_CATEGORY', ['ORDERS.PRODUCT.CATEGORY']]
]);

function assertExpectedPaths(outputRows, label) {
  for (const [outputName, expectedPaths] of expected.entries()) {
    const row = outputRows.find((item) => item.output_column_name === outputName);
    assert.ok(row, `${label}: output ${outputName} is missing`);
    assert.equal(row.lineage_status, 'RESOLVED', `${label}: ${outputName} must be RESOLVED`);

    const paths = (row.dependencies ?? [])
      .filter((item) => item.dependency_type === 'PHYSICAL_COLUMN')
      .map((item) => item.field_path)
      .sort();

    assert.deepEqual(paths, [...expectedPaths].sort(), `${label}: ${outputName} field paths`);
  }
}

const directResult = analyze(sql, { physicalColumns });
assertCompleted(directResult, 'STRUCT / ARRAY direct engine');
assertExpectedPaths(directResult.lineage.root_output_lineages, 'direct engine');

const customerName = directResult.lineage.root_output_lineages.find(
  (item) => item.output_column_name === 'CUSTOMER_NAME'
);
assert.ok(
  !customerName.dependencies.some((item) => item.field_path === 'CUSTOMER.ADDRESS.CITY'),
  'STRUCT field reference must not expand to sibling nested fields'
);

const exportedResult = analyzeViaBigQueryEntry(sql, {
  physicalColumns,
  strictMode: true,
  compactExport: true,
  exportMetadata: {
    analysis_id: 'struct-array-test',
    view_project: 'p',
    view_dataset: 'd',
    view_name: 'v_struct_array'
  }
});

assert.equal(exportedResult.analysis.failed_stage, null, 'BigQuery entry: failed_stage');
assert.ok(
  exportedResult.analysis.analysis_status === 'COMPLETED'
    || exportedResult.analysis.analysis_status === 'COMPLETED_WITH_WARNINGS',
  `BigQuery entry: unexpected status ${exportedResult.analysis.analysis_status}`
);

const exportedPaths = exportedResult.exported_tables.lineage_paths;
for (const [outputName, expectedPaths] of expected.entries()) {
  const actualPaths = exportedPaths
    .filter((item) => item.output_column_name === outputName)
    .map((item) => item.field_path)
    .sort();
  assert.deepEqual(actualPaths, [...expectedPaths].sort(), `export: ${outputName} field paths`);
}
