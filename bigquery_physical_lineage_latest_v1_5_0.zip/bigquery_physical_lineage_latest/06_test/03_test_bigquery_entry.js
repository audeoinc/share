'use strict';

const {
  assert,
  analyzeViaBigQueryEntry
} = require('./test_helpers.js');

const sql = `CREATE OR REPLACE TABLE \`p.d.output\` AS
SELECT customer_id, amount FROM \`p.d.sales\``;

const raw = analyzeViaBigQueryEntry(sql);
assert.equal(raw.query_ast.node_type, 'QUERY');
assert.equal(raw.failed_stage, null);

const exportMetadata = {
  analysis_id: 'test-analysis-id',
  object_project: 'p',
  object_dataset: 'd',
  object_name: 'output',
  object_type: 'TABLE',
  definition_hash: 'test-hash',
  analyzed_at: '2026-07-21T00:00:00Z'
};

const exported = analyzeViaBigQueryEntry(sql, {
  exportMetadata,
  compactExport: true
});

assert.ok(exported.analysis, 'analysis object missing');
assert.ok(exported.exported_tables, 'exported_tables missing');
assert.ok(Array.isArray(exported.exported_tables.sources), 'sources must be an array');
assert.ok(Array.isArray(exported.exported_tables.output_columns), 'output_columns must be an array');
assert.equal(exported.exported_tables.analyses, undefined, 'analyses must not be duplicated');
