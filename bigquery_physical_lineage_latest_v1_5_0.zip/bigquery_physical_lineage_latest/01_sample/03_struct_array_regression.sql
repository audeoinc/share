SET @@location = 'asia-northeast1';

CREATE OR REPLACE TABLE `audeodb.sample_ds.lineage_nested_source`
(
  customer_id INT64,
  customer STRUCT<
    name STRING,
    address STRUCT<
      city STRING,
      postal_code STRING
    >
  >,
  orders ARRAY<STRUCT<
    order_id INT64,
    amount NUMERIC,
    product STRUCT<
      product_id STRING,
      category STRING
    >
  >>
);

INSERT INTO `audeodb.sample_ds.lineage_nested_source`
VALUES (
  1,
  STRUCT(
    'Alice',
    STRUCT('Tokyo', '100-0001')
  ),
  [
    STRUCT(
      101,
      NUMERIC '1200',
      STRUCT('P-001', 'BOOK')
    )
  ]
);

CREATE OR REPLACE VIEW
  `audeodb.sample_ds.v_lineage_struct_level1`
AS
SELECT
  customer_id,
  customer.name AS customer_name,
  customer.address.city AS customer_city
FROM
  `audeodb.sample_ds.lineage_nested_source`;

CREATE OR REPLACE VIEW
  `audeodb.sample_ds.v_lineage_array_struct_level1`
AS
SELECT
  source.customer_id,
  item.order_id,
  item.amount,
  item.product.product_id AS product_id,
  item.product.category AS product_category
FROM
  `audeodb.sample_ds.lineage_nested_source` AS source
CROSS JOIN
  UNNEST(source.orders) AS item;

CREATE OR REPLACE VIEW
  `audeodb.sample_ds.v_lineage_nested_level2`
AS
SELECT
  struct_view.customer_id,
  struct_view.customer_city,
  array_view.order_id,
  array_view.product_category
FROM
  `audeodb.sample_ds.v_lineage_struct_level1` AS struct_view
LEFT JOIN
  `audeodb.sample_ds.v_lineage_array_struct_level1` AS array_view
USING (customer_id);
