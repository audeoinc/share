# Changelog

## 1.2.0 - 2026-07-21

- Added `StatementParser` before `QueryParser`.
- Added CTAS query-token extraction inside the lineage bundle.
- Unified VIEW and JOB definition synchronization.
- Removed SQL-side regular-expression CTAS extraction.
- Preserved raw JOB SQL for hashing and auditability.
- Added generated TABLE inactivity detection using regional `INFORMATION_SCHEMA.TABLES`.
- Included STRUCT / ARRAY<STRUCT> validation files.
- Consolidated latest operational files into one versioned package.

## v1.2.1 - 2026-07-21

- Added a Node.js regression test foundation under `06_test/`.
- Added 39 SQL scenarios covering StatementParser, clauses, CTEs, joins,
  scalar subqueries, UNNEST, STRUCT paths, wildcards, set operations,
  BigQuery UDF entry/export contracts, and strict/non-strict failures.
- Fixed set-operation splitting for `UNION DISTINCT`, `INTERSECT DISTINCT`,
  and `EXCEPT DISTINCT`.
- Prevented `SELECT * EXCEPT(...)` from being misclassified as a set operation.
- Confirmed all four regression test suites pass on Node.js v22.16.0.

## v1.3.0 - 2026-07-21

### StatementParser formal integration

- Formally integrated `StatementParser` between Lexer and QueryParser.
- Added support for:
  - plain `SELECT` / `WITH`
  - `CREATE TABLE ... AS SELECT/WITH`
  - `CREATE VIEW ... AS SELECT/WITH`
  - `CREATE MATERIALIZED VIEW ... AS SELECT/WITH`
- Preserved the original SQL in `sql_text` while passing only query tokens to QueryParser.
- Added `statement.statement_type` and `statement.query_start_token_seq` to the engine result.
- Added `statement_type` and `query_start_token_seq` to the exported analysis row.
- Added formal integration regression tests covering the direct engine API and BigQuery UDF entry.

## v1.4.0 - 2026-07-21

### Definition Registry unification

- Finalized `04_pipeline/01_sync_definition_registry.sql` as the single synchronization entry point.
- Normalized `INFORMATION_SCHEMA.VIEWS` and latest successful generated-table JOBS into `definition_inventory`.
- Preserved the original JOB statement in `definition_text`; CTAS extraction remains exclusively in `StatementParser`.
- Retained deterministic latest-job selection by `creation_time DESC, job_id DESC`.
- Configured DAG detection with `audeodb@appspot.gserviceaccount.com`.
- Centralized `lineage_job_registry` creation in `03_repository/01_create_repository_tables.sql`.
- Kept missing VIEW and physically removed generated TABLE inactivation using `INACTIVE_OBJECT_NOT_FOUND`.
- Added `06_test/06_test_registry_sync_contract.js` to prevent synchronization responsibilities from drifting back into SQL parsing.


## v1.5.0 - 2026-07-21

### STRUCT / ARRAY<STRUCT> physical lineage completion

- Fixed physical metadata matching so a STRUCT field reference resolves only to
  its exact `COLUMN_FIELD_PATHS.field_path`.
- Prevented references such as `customer.name` from expanding to sibling paths
  such as `customer.address.city`.
- Added physical lineage propagation from `UNNEST(array_struct_column)` aliases
  to paths such as `orders.order_id` and `orders.product.category`.
- Strengthened the BigQuery ASSERT validation with false-positive checks.
- Added `06_test/07_test_struct_array_physical_lineage.js` covering both the
  direct engine API and the public BigQuery JSON entry/export contract.
