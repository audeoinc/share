-- EXECUTION ORDER: Initial setup 07 / Daily operation 01
SET @@location = 'asia-northeast1';

-- ============================================================================
-- Unified definition synchronization
--
-- Sources:
--   - INFORMATION_SCHEMA.VIEWS
--   - INFORMATION_SCHEMA.JOBS_BY_PROJECT
--
-- Design:
--   - VIEW and generated TABLE definitions are normalized into one inventory.
--   - JOBS SQL is stored as the original statement, including CREATE TABLE.
--   - CTAS query extraction is delegated to StatementParser in
--     lineage_udf_bundle.js during analysis.
--   - Latest successful generated-table job wins.
-- ============================================================================

DECLARE sync_timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP();
DECLARE initial_lookback_days INT64 DEFAULT 60;
DECLARE incremental_lookback_days INT64 DEFAULT 3;
DECLARE lookback_days INT64;

DECLARE dag_service_accounts ARRAY<STRING> DEFAULT [
  'audeodb@appspot.gserviceaccount.com'
];

-- Persistent repository tables are created by
-- 03_repository/01_create_repository_tables.sql.

SET lookback_days = IF(
  (
    SELECT COUNT(*)
    FROM `audeodb.lineage_repository.lineage_job_registry`
  ) = 0,
  initial_lookback_days,
  incremental_lookback_days
);

-- --------------------------------------------------------------------------
-- Collect recent successful Scheduled Query / DAG jobs.
-- The complete original query text is retained as definition_text.
-- --------------------------------------------------------------------------
CREATE TEMP TABLE recent_generated_table_jobs AS
WITH target_jobs AS (
  SELECT
    project_id AS job_project,
    job_id,
    creation_time,
    start_time,
    end_time,
    user_email,
    labels,
    statement_type,
    query AS query_text,
    LOWER(destination_table.project_id) AS destination_project,
    LOWER(destination_table.dataset_id) AS destination_dataset,
    LOWER(destination_table.table_id) AS destination_table,
    EXISTS (
      SELECT 1
      FROM UNNEST(labels) AS label
      WHERE label.key = 'data_source_id'
        AND label.value = 'scheduled_query'
    ) AS is_scheduled_query,
    user_email IN UNNEST(dag_service_accounts) AS is_dag
  FROM
    `audeodb.region-asia-northeast1`.INFORMATION_SCHEMA.JOBS_BY_PROJECT
  WHERE creation_time >= TIMESTAMP_SUB(
    sync_timestamp,
    INTERVAL lookback_days DAY
  )
    AND creation_time < sync_timestamp
    AND job_type = 'QUERY'
    AND state = 'DONE'
    AND error_result IS NULL
    AND query IS NOT NULL
    AND destination_table IS NOT NULL
    AND statement_type IN (
      'SELECT',
      'CREATE_TABLE_AS_SELECT'
    )
)
SELECT
  job_project,
  job_id,
  creation_time,
  start_time,
  end_time,
  CASE
    WHEN is_scheduled_query THEN 'SCHEDULED_QUERY'
    WHEN is_dag THEN 'DAG'
  END AS execution_source,
  CASE
    WHEN is_scheduled_query THEN 'LABEL'
    WHEN is_dag THEN 'USER_EMAIL'
  END AS source_detection_method,
  user_email,
  labels,
  statement_type,
  query_text,
  query_text AS definition_text,
  TO_HEX(SHA256(query_text)) AS definition_hash,
  destination_project,
  destination_dataset,
  destination_table,
  sync_timestamp AS collected_at,
  sync_timestamp AS updated_at
FROM target_jobs
WHERE is_scheduled_query
   OR is_dag;

MERGE
  `audeodb.lineage_repository.lineage_job_registry` AS target
USING recent_generated_table_jobs AS source
ON target.job_project = source.job_project
AND target.job_id = source.job_id
WHEN MATCHED THEN
  UPDATE SET
    target.creation_time = source.creation_time,
    target.start_time = source.start_time,
    target.end_time = source.end_time,
    target.execution_source = source.execution_source,
    target.source_detection_method = source.source_detection_method,
    target.user_email = source.user_email,
    target.labels = source.labels,
    target.statement_type = source.statement_type,
    target.query_text = source.query_text,
    target.definition_text = source.definition_text,
    target.definition_hash = source.definition_hash,
    target.destination_project = source.destination_project,
    target.destination_dataset = source.destination_dataset,
    target.destination_table = source.destination_table,
    target.collected_at = source.collected_at,
    target.updated_at = source.updated_at
WHEN NOT MATCHED THEN
  INSERT (
    job_project,
    job_id,
    creation_time,
    start_time,
    end_time,
    execution_source,
    source_detection_method,
    user_email,
    labels,
    statement_type,
    query_text,
    definition_text,
    definition_hash,
    destination_project,
    destination_dataset,
    destination_table,
    collected_at,
    updated_at
  )
  VALUES (
    source.job_project,
    source.job_id,
    source.creation_time,
    source.start_time,
    source.end_time,
    source.execution_source,
    source.source_detection_method,
    source.user_email,
    source.labels,
    source.statement_type,
    source.query_text,
    source.definition_text,
    source.definition_hash,
    source.destination_project,
    source.destination_dataset,
    source.destination_table,
    source.collected_at,
    source.updated_at
  );

-- --------------------------------------------------------------------------
-- Normalize VIEWS and latest generated TABLE jobs into one definition inventory.
-- --------------------------------------------------------------------------
CREATE TEMP TABLE definition_inventory AS
WITH source_views AS (
  SELECT
    LOWER(table_catalog) AS object_project,
    LOWER(table_schema) AS object_dataset,
    LOWER(table_name) AS object_name,
    'VIEW' AS object_type,
    'VIEW_DEFINITION' AS generation_type,
    'INFORMATION_SCHEMA.VIEWS' AS definition_source,
    view_definition AS definition_text,
    TO_HEX(SHA256(COALESCE(view_definition, ''))) AS definition_hash,
    CAST(NULL AS STRING) AS source_job_id,
    CAST(NULL AS TIMESTAMP) AS source_job_time,
    CAST(NULL AS STRING) AS source_user_email
  FROM `audeodb.sample_ds.INFORMATION_SCHEMA.VIEWS`
),
latest_generated_tables AS (
  SELECT
    destination_project AS object_project,
    destination_dataset AS object_dataset,
    destination_table AS object_name,
    'TABLE' AS object_type,
    execution_source AS generation_type,
    'INFORMATION_SCHEMA.JOBS' AS definition_source,
    definition_text,
    definition_hash,
    job_id AS source_job_id,
    creation_time AS source_job_time,
    user_email AS source_user_email
  FROM
    `audeodb.lineage_repository.lineage_job_registry`
  QUALIFY ROW_NUMBER() OVER (
    PARTITION BY
      destination_project,
      destination_dataset,
      destination_table
    ORDER BY
      creation_time DESC,
      job_id DESC
  ) = 1
)
SELECT * FROM source_views
UNION ALL
SELECT * FROM latest_generated_tables;

MERGE
  `audeodb.lineage_repository.lineage_definition_registry` AS target
USING definition_inventory AS source
ON LOWER(target.object_project) = source.object_project
AND LOWER(target.object_dataset) = source.object_dataset
AND LOWER(target.object_name) = source.object_name
AND target.object_type = source.object_type
WHEN MATCHED THEN
  UPDATE SET
    target.generation_type = source.generation_type,
    target.definition_source = source.definition_source,
    target.definition_text = source.definition_text,
    target.previous_definition_hash = CASE
      WHEN target.definition_hash IS DISTINCT FROM source.definition_hash
        THEN target.definition_hash
      ELSE target.previous_definition_hash
    END,
    target.definition_hash = source.definition_hash,
    target.source_job_id = source.source_job_id,
    target.source_job_time = source.source_job_time,
    target.source_user_email = source.source_user_email,
    target.is_changed = (
      target.is_changed
      OR target.definition_hash IS DISTINCT FROM source.definition_hash
      OR target.last_analyzed_hash IS NULL
      OR target.last_analyzed_hash IS DISTINCT FROM source.definition_hash
    ),
    target.is_active = TRUE,
    target.analysis_status = CASE
      WHEN target.definition_hash IS DISTINCT FROM source.definition_hash
        THEN NULL
      ELSE target.analysis_status
    END,
    target.last_seen_at = sync_timestamp,
    target.updated_at = sync_timestamp
WHEN NOT MATCHED THEN
  INSERT (
    object_project,
    object_dataset,
    object_name,
    object_type,
    generation_type,
    definition_source,
    definition_text,
    definition_hash,
    previous_definition_hash,
    source_job_id,
    source_job_time,
    source_user_email,
    is_changed,
    is_active,
    analysis_status,
    last_analyzed_hash,
    first_seen_at,
    last_seen_at,
    last_analyzed_at,
    updated_at
  )
  VALUES (
    source.object_project,
    source.object_dataset,
    source.object_name,
    source.object_type,
    source.generation_type,
    source.definition_source,
    source.definition_text,
    source.definition_hash,
    NULL,
    source.source_job_id,
    source.source_job_time,
    source.source_user_email,
    TRUE,
    TRUE,
    NULL,
    NULL,
    sync_timestamp,
    sync_timestamp,
    NULL,
    sync_timestamp
  );

-- VIEW no longer present in INFORMATION_SCHEMA.VIEWS.
UPDATE
  `audeodb.lineage_repository.lineage_definition_registry` AS registry
SET
  is_active = FALSE,
  is_changed = FALSE,
  analysis_status = 'INACTIVE_OBJECT_NOT_FOUND',
  updated_at = sync_timestamp
WHERE registry.object_type = 'VIEW'
  AND registry.generation_type = 'VIEW_DEFINITION'
  AND LOWER(registry.object_project) = 'audeodb'
  AND LOWER(registry.object_dataset) = 'sample_ds'
  AND registry.is_active = TRUE
  AND NOT EXISTS (
    SELECT 1
    FROM definition_inventory AS source
    WHERE source.object_type = 'VIEW'
      AND source.object_project = LOWER(registry.object_project)
      AND source.object_dataset = LOWER(registry.object_dataset)
      AND source.object_name = LOWER(registry.object_name)
  );

-- Generated TABLE no longer exists physically.
UPDATE
  `audeodb.lineage_repository.lineage_definition_registry` AS registry
SET
  is_active = FALSE,
  is_changed = FALSE,
  analysis_status = 'INACTIVE_OBJECT_NOT_FOUND',
  updated_at = sync_timestamp
WHERE registry.object_type = 'TABLE'
  AND registry.generation_type IN (
    'SCHEDULED_QUERY',
    'DAG'
  )
  AND registry.is_active = TRUE
  AND LOWER(registry.object_project) = 'audeodb'
  AND NOT EXISTS (
    SELECT 1
    FROM
      `audeodb.region-asia-northeast1`.INFORMATION_SCHEMA.TABLES AS table_info
    WHERE LOWER(table_info.table_catalog) =
      LOWER(registry.object_project)
      AND LOWER(table_info.table_schema) =
        LOWER(registry.object_dataset)
      AND LOWER(table_info.table_name) =
        LOWER(registry.object_name)
  );

SELECT
  sync_timestamp,
  lookback_days,
  (
    SELECT COUNT(*)
    FROM recent_generated_table_jobs
  ) AS recent_generated_job_count,
  (
    SELECT COUNT(*)
    FROM definition_inventory
    WHERE object_type = 'VIEW'
  ) AS current_view_count,
  (
    SELECT COUNT(*)
    FROM definition_inventory
    WHERE object_type = 'TABLE'
  ) AS known_generated_table_count,
  (
    SELECT COUNT(*)
    FROM
      `audeodb.lineage_repository.lineage_definition_registry`
    WHERE is_active = TRUE
  ) AS active_definition_count,
  (
    SELECT COUNT(*)
    FROM
      `audeodb.lineage_repository.lineage_definition_registry`
    WHERE is_active = FALSE
      AND analysis_status = 'INACTIVE_OBJECT_NOT_FOUND'
  ) AS inactive_missing_object_count;
