"use strict";

/**
 * SQL文字列を、Parserが扱いやすいToken配列へ変換する。
 *
 * Lexerの責務は「SQLの意味を解釈すること」ではない。
 * SQL文字列を左から右へ読み、文字のまとまりを次のようなTokenへ分類する。
 *
 * - KEYWORD
 * - IDENTIFIER
 * - BACKTICK_IDENTIFIER
 * - NUMBER
 * - STRING
 * - COMMENT
 * - SYMBOL
 * - OPERATOR
 * - UNKNOWN
 *
 * ParserはSQL文字列を直接解析せず、この関数が返すToken配列を解析する。
 * 文字列解析と構文解析を分離することで、問題が発生した際に
 * 「Token化が誤っているのか」「Parserの判定が誤っているのか」を切り分けられる。
 *
 * paren_depthの仕様:
 *
 *   SUM(amount)
 *
 *   SUM     depth 0
 *   (       depth 0
 *   amount  depth 1
 *   )       depth 0
 *
 * 開き括弧と閉じ括弧は、括弧の外側と同じdepthに記録する。
 * 括弧に囲まれた中身だけを1段深いdepthにする。
 *
 * この仕様により、対応する開き括弧と閉じ括弧は同じdepthとなる。
 * TokenReaderはこの性質を利用して、対応する閉じ括弧を検索する。
 *
 * @param {string} sqlText Token化するSQL文字列
 * @returns {Array<object>} SQL内のTokenを出現順に格納した配列
 */
function tokenize(sqlText) {
  // nullや数値などを誤って渡した場合、文字単位の処理を続けることはできない。
  // 呼び出し側の不具合を早期に発見するため、暗黙変換せず例外にする。
  if (typeof sqlText !== "string") {
    throw new TypeError("tokenize: sqlText must be a string.");
  }

  // pushToken()が生成したTokenを出現順に格納する。
  // Lexerはこの配列を最後に呼び出し元へ返す。
  const tokens = [];

  // Tokenへ付与する論理連番。
  // JavaScript配列のindexは0始まりだが、token_seqは1始まりとする。
  // ParserやBigQueryの中間テーブルでは、このtoken_seqを共通の位置情報として使う。
  let tokenSeq = 0;

  // 現在読んでいる文字の行番号と列番号。
  // Token開始位置を保持することで、解析エラー時にSQL上の場所を特定できる。
  let line = 1;
  let column = 1;

  // 現在位置が何段の括弧内にあるかを表す。
  // 開き括弧そのものを保存した後に増加し、閉じ括弧を保存する前に減少させる。
  let parenDepth = 0;

  // SQL文字列上の現在位置。
  // Lexer内部だけで利用する0始まりの文字indexであり、token_seqとは別物。
  let index = 0;

  /**
   * KEYWORDとして分類する語の集合。
   *
   * LexerはSQL文法が正しいかまでは判断しない。
   * 読み取った単語がこの集合に含まれていればKEYWORD、
   * 含まれていなければIDENTIFIERとして分類する。
   *
   * Setを使う理由は、配列を毎回先頭から検索するよりも
   * 「この値が存在するか」を意図どおりに記述できるため。
   */
  const KEYWORDS = new Set([
    "SELECT", "FROM", "WHERE", "GROUP", "BY", "HAVING", "QUALIFY",
    "ORDER", "LIMIT", "JOIN", "LEFT", "RIGHT", "FULL", "INNER",
    "OUTER", "CROSS", "ON", "USING", "WITH", "RECURSIVE", "AS",
    "UNION", "ALL", "DISTINCT", "AND", "OR", "NOT", "IN", "IS",
    "NULL", "TRUE", "FALSE", "CASE", "WHEN", "THEN", "ELSE", "END",
    "OVER", "PARTITION", "UNNEST", "STRUCT", "ARRAY", "EXCEPT",
    "REPLACE", "INTERSECT", "OFFSET", "ORDINAL", "ASC", "DESC",
    "ROWS", "RANGE", "GROUPS", "NULLS", "FIRST", "LAST", "BETWEEN",
    "PRECEDING", "FOLLOWING", "CURRENT", "ROW"
  ]);

  // SQLの構造や区切りを表す1文字の記号。
  // 括弧と角括弧だけはparenDepthの増減にも利用する。
  const SYMBOLS = new Set(["(", ")", ",", ".", ";", "[", "]"]);

  // 1文字で完結する演算子。
  // 2文字演算子を先に判定しないと、>=が>と=へ分割されるため判定順序が重要。
  const SINGLE_OPERATORS = new Set(["=", "+", "-", "*", "/", "%", "<", ">", "!"]);

  // 2文字で1つの意味を持つ演算子。
  // メインループではSINGLE_OPERATORSより先に評価する。
  const DOUBLE_OPERATORS = new Set([">=", "<=", "!=", "<>", "||"]);

  /**
   * Tokenを1件生成し、tokens配列へ追加する。
   *
   * Token生成を1か所に集約する理由:
   *
   * - token_seqの採番方法を統一できる
   * - line_no、column_no、paren_depthの付与漏れを防げる
   * - 将来Token項目を追加するときの修正箇所を1か所にできる
   *
   * @param {string} token SQLに記述されていた元の文字列
   * @param {string} normalizedToken 比較用に正規化した文字列
   * @param {string} tokenType Tokenの分類
   * @param {number} tokenLine Token開始行
   * @param {number} tokenColumn Token開始列
   */
  function pushToken(token, normalizedToken, tokenType, tokenLine, tokenColumn) {
    tokens.push({
      // ++tokenSeqにより、増加後の値を格納するため最初のTokenは1になる。
      token_seq: ++tokenSeq,
      line_no: tokenLine,
      column_no: tokenColumn,
      token,
      normalized_token: normalizedToken,
      token_type: tokenType,
      paren_depth: parenDepth
    });
  }

  /**
   * 空白文字か判定する。
   * スペースだけでなく、タブや改行も対象にするため\sを使う。
   */
  function isSpace(character) {
    return /\s/.test(character);
  }

  /**
   * 通常識別子の先頭文字として利用できるか判定する。
   *
   * 数字を含めない理由:
   * 数字で始まる文字列は、まず数値リテラルとして扱うため。
   * 数字始まりの識別子はバッククォート識別子の分岐で処理する。
   */
  function isIdentifierStart(character) {
    return /[A-Za-z_]/.test(character);
  }

  /**
   * 識別子の2文字目以降として利用できるか判定する。
   *
   * customer1のように途中以降の数字は許可するため、
   * isIdentifierStart()とは条件を分けている。
   */
  function isIdentifierPart(character) {
    return /[A-Za-z0-9_$]/.test(character);
  }

  /**
   * 数値リテラルを開始できる文字か判定する。
   *
   * 先頭文字は0から9に限定する。
   * 小数点は数値読み取り中のwhile条件でのみ許可する。
   */
  function isDigit(character) {
    return /[0-9]/.test(character);
  }

  /**
   * 現在の1文字を消費し、文字indexと行・列位置を更新する。
   *
   * 文字位置の更新を各分岐へ直接書くと、改行時の処理やindex更新が重複する。
   * このメソッドへ集約することで、すべての文字消費で同じ規則を適用できる。
   *
   * @param {string} character 今回消費した文字
   */
  function advanceCharacter(character) {
    if (character === "\n") {
      line++;
      column = 1;
    } else {
      column++;
    }

    index++;
  }

  // SQL文字列を左から右へ1文字ずつ処理する。
  // 各分岐は「現在位置から何のTokenが始まっているか」を判定する。
  while (index < sqlText.length) {
    const character = sqlText[index];

    // 空白はTokenとして保存しない。
    // ただし行番号と列番号は正しく維持する必要があるため、文字は必ず消費する。
    if (isSpace(character)) {
      advanceCharacter(character);
      continue;
    }

    // Tokenを読み始める前に開始位置を保存する。
    // 読み取り中にlineとcolumnが進んでも、Tokenの開始位置は変わらない。
    const startLine = line;
    const startColumn = column;

    // 1行コメントを読み取る。
    // 改行はコメントTokenへ含めず、次のループで空白として処理する。
    if (character === "-" && sqlText[index + 1] === "-") {
      let value = "";

      while (index < sqlText.length && sqlText[index] !== "\n") {
        const current = sqlText[index];

        value += current;
        advanceCharacter(current);
      }

      pushToken(value, value, "COMMENT", startLine, startColumn);
      continue;
    }

    // 複数行コメントを読み取る。
    // 終端の*/もCOMMENT Tokenに含める。
    if (character === "/" && sqlText[index + 1] === "*") {
      let value = "";

      while (index < sqlText.length) {
        const current = sqlText[index];

        value += current;

        // 現在文字が*で次の文字が/なら、コメント終端を見つけたことになる。
        if (current === "*" && sqlText[index + 1] === "/") {
          // *を消費するとindexが/へ進む。
          advanceCharacter(current);

          // 終端の/もvalueへ追加して消費する。
          const closingSlash = sqlText[index];
          value += closingSlash;
          advanceCharacter(closingSlash);
          break;
        }

        advanceCharacter(current);
      }

      pushToken(value, value, "COMMENT", startLine, startColumn);
      continue;
    }

    // バッククォート識別子を読み取る。
    // project.dataset.tableや数字始まりの識別子など、通常識別子とは別ルートで扱う。
    if (character === "`") {
      let value = character;

      // 開始バッククォートはすでにvalueへ入れたため、次の文字へ進む。
      advanceCharacter(character);

      while (index < sqlText.length) {
        // indexを進めた後も今回読んだ文字を判定できるよう、currentへ保持する。
        const current = sqlText[index];

        value += current;
        advanceCharacter(current);

        // 今回読み終えた文字が閉じバッククォートなら、識別子の読み取りを終了する。
        if (current === "`") {
          break;
        }
      }

      // 比較やResolverで利用しやすいよう、normalized_tokenから外側の`を除く。
      const normalizedValue = value.length >= 2
        ? value.substring(1, value.length - 1)
        : value;

      pushToken(
        value,
        normalizedValue,
        "BACKTICK_IDENTIFIER",
        startLine,
        startColumn
      );

      continue;
    }

    // 文字列リテラルを読み取る。
    // シングルクォートとダブルクォートの両方を同じロジックで扱う。
    if (character === "'" || character === '"') {
      const quoteCharacter = character;
      let value = character;

      // 開始引用符はvalueへ格納済みなので、文字列本体へ進む。
      advanceCharacter(character);

      while (index < sqlText.length) {
        const current = sqlText[index];

        value += current;
        advanceCharacter(current);

        // ''や""のように引用符が連続している場合は、エスケープされた引用符として扱う。
        if (current === quoteCharacter && sqlText[index] === quoteCharacter) {
          const escapedQuote = sqlText[index];

          value += escapedQuote;
          advanceCharacter(escapedQuote);
          continue;
        }

        // 連続引用符ではない終了引用符を読み終えたら、文字列の読み取りを終了する。
        if (current === quoteCharacter) {
          break;
        }
      }

      // normalized_tokenは外側の引用符を除いた文字列本体とする。
      const normalizedValue = value.length >= 2
        ? value.substring(1, value.length - 1)
        : value;

      pushToken(value, normalizedValue, "STRING", startLine, startColumn);
      continue;
    }

    // KEYWORDまたは通常識別子を読み取る。
    if (isIdentifierStart(character)) {
      let value = "";

      // 先頭条件を満たした後は、数字や$を含む識別子継続文字をまとめて読む。
      while (index < sqlText.length && isIdentifierPart(sqlText[index])) {
        const current = sqlText[index];

        value += current;
        advanceCharacter(current);
      }

      // SQLキーワードの比較を大文字小文字に依存させないため大文字化する。
      const normalizedValue = value.toUpperCase();

      // KEYWORDSに含まれるかだけをLexerで判定し、構文上の役割はParserに任せる。
      const tokenType = KEYWORDS.has(normalizedValue) ? "KEYWORD" : "IDENTIFIER";

      pushToken(value, normalizedValue, tokenType, startLine, startColumn);
      continue;
    }

    // 数値リテラルを読み取る。
    // 最初の文字はisDigit()により0から9であることが保証されている。
    if (isDigit(character)) {
      let value = "";

      // 2文字目以降は数字または小数点を許可する。
      // 現版では複数小数点の妥当性確認は行わず、Token化に責務を限定する。
      while (index < sqlText.length && /[0-9.]/.test(sqlText[index])) {
        const current = sqlText[index];

        value += current;
        advanceCharacter(current);
      }

      pushToken(value, value, "NUMBER", startLine, startColumn);
      continue;
    }

    // 現在位置から2文字を取得し、複数文字演算子か確認する。
    // SINGLE_OPERATORSより先に評価しないと、>=が>と=に分割される。
    const twoCharacters = sqlText.substring(index, index + 2);

    if (DOUBLE_OPERATORS.has(twoCharacters)) {
      pushToken(twoCharacters, twoCharacters, "OPERATOR", startLine, startColumn);

      // 2文字演算子なので、現在文字と次の文字をそれぞれ消費する。
      advanceCharacter(sqlText[index]);
      advanceCharacter(sqlText[index]);
      continue;
    }

    // 括弧・カンマ・ドットなどの構造記号を処理する。
    if (SYMBOLS.has(character)) {
      // 閉じ記号は括弧内部を終了させる。
      // 閉じ記号自身を外側depthへ所属させるため、Token保存前にdepthを戻す。
      if (character === ")" || character === "]") {
        parenDepth--;

        // depthが負になる場合、対応する開き記号なしに閉じ記号が現れている。
        // 黙って0へ補正すると不正SQLを正常として扱うため、明示的に例外にする。
        if (parenDepth < 0) {
          throw new SyntaxError(
            `tokenize: unexpected closing symbol "${character}" ` +
            `at line ${startLine}, column ${startColumn}.`
          );
        }
      }

      // 開き記号・閉じ記号とも、括弧外側のdepthで保存される。
      pushToken(character, character, "SYMBOL", startLine, startColumn);

      // 開き記号の次から括弧内部へ入るため、Token保存後にdepthを増やす。
      if (character === "(" || character === "[") {
        parenDepth++;
      }

      // SYMBOLは必ず1文字なので、共通して最後に1文字だけ消費する。
      advanceCharacter(character);
      continue;
    }

    // 1文字演算子を処理する。
    // 2文字演算子の判定を通過した後なので、ここでは単独演算子として確定できる。
    if (SINGLE_OPERATORS.has(character)) {
      pushToken(character, character, "OPERATOR", startLine, startColumn);
      advanceCharacter(character);
      continue;
    }

    // どの既知分類にも該当しない文字をUNKNOWNとして残す。
    // 無視せずToken化することで、未対応構文や文字を後から検出できる。
    pushToken(character, character, "UNKNOWN", startLine, startColumn);
    advanceCharacter(character);
  }

  // SQL末尾まで読んだ時点でdepthが0でなければ、開き括弧が閉じられていない。
  // 不完全なToken列を後続Parserへ渡さないため、Lexer段階で例外にする。
  if (parenDepth !== 0) {
    throw new SyntaxError(
      `tokenize: unclosed parenthesis or bracket. Remaining depth: ${parenDepth}.`
    );
  }

  return tokens;
}

// Node.jsの他ファイルから分割代入で読み込めるよう、オブジェクト形式で公開する。
// const { tokenize } = require("./lexer");
module.exports = {
  tokenize
};
