"use strict";

const { TokenReader } = require("./token_reader");

/**
 * Lexerが生成したToken配列から、SELECT文のトップレベルClauseを抽出する。
 *
 * この基本版で抽出するClause:
 *
 * - SELECT
 * - FROM
 * - WHERE
 * - GROUP BY
 * - HAVING
 * - QUALIFY
 * - ORDER BY
 * - LIMIT
 *
 * Clause Parserの責務:
 *
 * 1. Clauseの開始位置を見つける
 * 2. GROUP BYなど複数Tokenで構成されるClause名を判定する
 * 3. Clause名の範囲とClause本文の範囲をtoken_seqで返す
 *
 * この段階ではSELECT項目やFROM内のテーブル名までは解析しない。
 * Clause単位でToken範囲を切り出し、後続のSelect ParserやFrom Parserへ渡すことが目的。
 *
 * 位置情報をJavaScript配列indexではなくtoken_seqで返す理由:
 *
 * - Parser、Resolver、BigQuery中間テーブルの共通座標として使える
 * - コメント除去やToken配列再構築でindexが変化しても論理位置を保持できる
 * - TokenReaderの内部実装をParser外へ漏らさずに済む
 */
class ClauseParser {
  /**
   * @param {Array<object>} tokens Lexerが生成したToken配列
   */
  constructor(tokens) {
    // Clause Parserは配列を前提として順番に走査する。
    // 不正な入力を暗黙に空配列へ変換せず、呼び出し側の不具合を例外にする。
    if (!Array.isArray(tokens)) {
      throw new TypeError("ClauseParser: tokens must be an array.");
    }

    // Clause本文の終端計算など、Readerの現在位置とは無関係に
    // Token配列全体を参照する処理で利用する。
    this.tokens = tokens;

    // 現在位置の取得・前方確認・移動をTokenReaderへ任せる。
    // ClauseParserが配列index操作を直接各所へ書かないために必要となる。
    this.reader = new TokenReader(tokens);
  }

  /**
   * Token配列を先頭から走査し、Clause一覧を返す公開メソッド。
   *
   * 返却するClauseの例:
   *
   * {
   *   clause_seq: 1,
   *   clause_type: "SELECT",
   *   clause_start_seq: 1,
   *   clause_end_seq: 1,
   *   body_start_seq: 2,
   *   body_end_seq: 10,
   *   paren_depth: 0
   * }
   *
   * clause_start_seq / clause_end_seq:
   * Clause名そのもののToken範囲。
   * GROUP BYならGROUPからBYまでを表す。
   *
   * body_start_seq / body_end_seq:
   * Clause名を除いた本文のToken範囲。
   *
   * @returns {Array<object>} 抽出したClause情報
   */
  parse() {
    const clauses = [];

    // 同じClauseParserインスタンスでparse()を再実行しても、
    // 必ずToken先頭から解析を開始するためReaderをリセットする。
    this.reader.reset();

    // EOFへ到達するまで、現在TokenがClause開始か順番に確認する。
    while (!this.reader.isEnd()) {
      const currentToken = this.reader.current();

      // コメント自体はClauseの開始語にならない。
      // Tokenとしては保持したまま、Clause判定だけを読み飛ばす。
      if (currentToken.token_type === "COMMENT") {
        this.reader.advance();
        continue;
      }

      // この基本版はSQL全体のトップレベルClauseだけを抽出する。
      // 関数、OVER句、括弧内サブクエリに出現するSELECTやORDER BYを
      // 外側QueryのClauseと誤認しないため、depth 0だけを判定対象にする。
      if (currentToken.paren_depth !== 0) {
        this.reader.advance();
        continue;
      }

      // 現在位置が対応対象のClause開始かを判定する。
      // 判定ロジックを#matchClause()へ集約することで、
      // parse()は走査と結果作成の流れだけを担当できる。
      const clauseMatch = this.#matchClause();

      // Clause開始でなければ、現在Tokenを1つ消費して次を調べる。
      if (!clauseMatch) {
        this.reader.advance();
        continue;
      }

      // Clause名を検出した時点では次のClause位置がまだ不明なため、
      // body_end_seqはnullで登録し、全Clause検出後にまとめて設定する。
      clauses.push({
        clause_seq: clauses.length + 1,
        clause_type: clauseMatch.clause_type,
        clause_start_seq: currentToken.token_seq,
        clause_end_seq: clauseMatch.clause_end_seq,
        body_start_seq: clauseMatch.body_start_seq,
        body_end_seq: null,
        paren_depth: currentToken.paren_depth
      });

      // SELECTなどは1 Token、GROUP BYなどはコメントを含めて複数Token進める。
      // Clause名を構成するTokenを再度Clause開始候補として判定しないために必要。
      this.reader.advance(clauseMatch.token_count);
    }

    // すべてのClause開始位置が判明した後、次Clauseとの境界から本文終端を設定する。
    this.#setBodyEndSeq(clauses);

    return clauses;
  }

  /**
   * 現在TokenがClause開始か判定し、Clause名に関する情報を返す。
   *
   * このメソッドが必要な理由:
   *
   * - parse()へ多数のClause条件を直接並べず、走査処理と判定処理を分離する
   * - SELECTなど1 Token ClauseとGROUP BYなど2 Token Clauseを共通形式で返す
   * - Clause種類を追加する場合の変更箇所を明確にする
   *
   * @returns {object|null} 一致したClause情報。Clause開始でなければnull
   */
  #matchClause() {
    if (this.reader.matches("SELECT")) {
      return this.#createSingleTokenClause("SELECT");
    }

    if (this.reader.matches("FROM")) {
      return this.#createSingleTokenClause("FROM");
    }

    if (this.reader.matches("WHERE")) {
      return this.#createSingleTokenClause("WHERE");
    }

    if (this.reader.matches("HAVING")) {
      return this.#createSingleTokenClause("HAVING");
    }

    if (this.reader.matches("QUALIFY")) {
      return this.#createSingleTokenClause("QUALIFY");
    }

    if (this.reader.matches("LIMIT")) {
      return this.#createSingleTokenClause("LIMIT");
    }

    // GROUP単独ではClauseとして確定できない。
    // 後続の非COMMENT TokenがBYであることを#createTwoTokenClause()で確認する。
    if (this.reader.matches("GROUP")) {
      return this.#createTwoTokenClause("GROUP_BY", "BY");
    }

    // ORDERもGROUPと同様に、後続のBYと組み合わせてClause名となる。
    if (this.reader.matches("ORDER")) {
      return this.#createTwoTokenClause("ORDER_BY", "BY");
    }

    return null;
  }

  /**
   * SELECT、FROM、WHEREなど、1 Tokenで構成されるClause情報を作る。
   *
   * このメソッドが必要な理由:
   *
   * - 1 Token Clauseで共通となるclause_end_seqとbody_start_seqの計算を集約する
   * - Clauseごとに同じオブジェクト生成処理を重複させない
   *
   * body_start_seqは、Clause名の直後にある最初の非COMMENT Tokenとする。
   * Clause名直後にコメントがあっても、後続Parserへ本文開始位置を正しく渡せる。
   *
   * @param {string} clauseType 返却用のClause種類
   * @returns {object} Clause名と本文開始位置に関する情報
   */
  #createSingleTokenClause(clauseType) {
    const currentToken = this.reader.current();
    const nextToken = this.reader.peekNonComment(1);

    return {
      clause_type: clauseType,
      clause_end_seq: currentToken.token_seq,
      body_start_seq: nextToken ? nextToken.token_seq : null,
      token_count: 1
    };
  }

  /**
   * GROUP BY、ORDER BYなど、2つのキーワードで構成されるClause情報を作る。
   *
   * GROUPとBYの間にCOMMENT Tokenが存在しても、同じClauseとして判定する。
   *
   * 例:
   *
   * GROUP
   * -- comment
   * BY customer_id
   *
   * このメソッドが必要な理由:
   *
   * - 先頭キーワードだけでClauseと誤判定することを防ぐ
   * - コメントを挟む複合Clauseでも本文開始位置を正確に求める
   * - Readerを何Token進めるべきかtoken_countとして返す
   *
   * @param {string} clauseType 返却用のClause種類
   * @param {string} secondKeyword 2つ目に必要なキーワード
   * @returns {object|null} 条件を満たせばClause情報、満たさなければnull
   */
  #createTwoTokenClause(clauseType, secondKeyword) {
    // 現在Tokenの次にある最初の非COMMENT Tokenを確認する。
    const secondToken = this.reader.peekNonComment(1);

    // 後続Tokenが存在しない、または必要な第2キーワードでない場合、
    // 現在位置はこの複合Clauseの開始ではない。
    if (!secondToken || secondToken.normalized_token !== secondKeyword) {
      return null;
    }

    // peekNonComment()はTokenを返すが、Readerを何件進めるかにはoffsetが必要となる。
    // コメント数を含む実際の距離をtoken_seqから算出する。
    const secondTokenOffset = this.#findOffsetByTokenSeq(secondToken.token_seq);

    // BYの次にある最初の非COMMENT TokenがClause本文の開始となる。
    const bodyStartToken = this.reader.peekNonComment(secondTokenOffset + 1);

    return {
      clause_type: clauseType,
      clause_end_seq: secondToken.token_seq,
      body_start_seq: bodyStartToken ? bodyStartToken.token_seq : null,
      token_count: secondTokenOffset + 1
    };
  }

  /**
   * 検出済みClauseへbody_end_seqを設定する。
   *
   * Clause本文の終端は、基本的に次Clause開始Tokenの直前にある
   * 最後の非COMMENT Tokenとする。
   *
   * この処理をClause検出中ではなく最後に行う理由:
   * 現在Clauseを検出した時点では、次Clauseがどこから始まるかまだ分からないため。
   *
   * @param {Array<object>} clauses parse()で検出したClause配列
   */
  #setBodyEndSeq(clauses) {
    for (let clauseIndex = 0; clauseIndex < clauses.length; clauseIndex++) {
      const currentClause = clauses[clauseIndex];
      const nextClause = clauses[clauseIndex + 1];

      // Clause名の後に本文Tokenが存在しない場合、開始も終了もnullとする。
      if (currentClause.body_start_seq === null) {
        currentClause.body_end_seq = null;
        continue;
      }

      if (nextClause) {
        // 次Clauseが存在する場合、その開始位置より前の最後の有効Tokenを本文終端とする。
        // Clause間のコメントを本文終端へ含めないため、非COMMENT Tokenを検索する。
        currentClause.body_end_seq = this.#findPreviousNonCommentTokenSeq(
          nextClause.clause_start_seq
        );
        continue;
      }

      // 最後のClauseには次Clauseがないため、SQL末尾の非COMMENT Tokenまでを本文とする。
      currentClause.body_end_seq = this.#findLastNonCommentTokenSeq();
    }
  }

  /**
   * 現在Reader位置から、指定token_seqのTokenまでの相対offsetを求める。
   *
   * TokenReaderの公開インターフェースはtoken_seqを基準とする一方、
   * peek()とadvance()は「何Token先か」という内部的な移動量を必要とする。
   * その橋渡しをClauseParser内部だけで行うための補助メソッド。
   *
   * @param {number} tokenSeq 探すTokenのtoken_seq
   * @returns {number} 現在位置を0とした相対offset
   */
  #findOffsetByTokenSeq(tokenSeq) {
    let offset = 0;

    while (true) {
      const targetToken = this.reader.peek(offset);

      // 現在位置以降に指定Tokenが存在しない場合、ロジック上の不整合となる。
      // 無限ループや誤った移動を防ぐため例外にする。
      if (!targetToken) {
        throw new RangeError(
          `ClauseParser: token_seq ${tokenSeq} was not found after the current position.`
        );
      }

      if (targetToken.token_seq === tokenSeq) {
        return offset;
      }

      offset++;
    }
  }

  /**
   * 指定token_seqより前にある、最後の非COMMENT Tokenのtoken_seqを返す。
   *
   * Clause本文終端からコメントを除外するために利用する。
   * コメントをToken列から削除せず、範囲計算時だけ対象外にすることで、
   * 元SQLとの位置関係やデバッグ情報を保持できる。
   *
   * @param {number} tokenSeq 境界となる次Clauseの開始token_seq
   * @returns {number|null} 直前の非COMMENT Token。存在しなければnull
   */
  #findPreviousNonCommentTokenSeq(tokenSeq) {
    let previousTokenSeq = null;

    // tokensはtoken_seq順に並んでいる前提なので、境界へ到達した時点で終了できる。
    for (const token of this.tokens) {
      if (token.token_seq >= tokenSeq) {
        break;
      }

      if (token.token_type !== "COMMENT") {
        previousTokenSeq = token.token_seq;
      }
    }

    return previousTokenSeq;
  }

  /**
   * SQL末尾から逆向きに検索し、最後の非COMMENT Tokenのtoken_seqを返す。
   *
   * 最後のClauseのbody_end_seqを求めるために必要となる。
   * 末尾にコメントが続いていても、Clause本文の終端は最後の実Tokenとする。
   *
   * @returns {number|null} 最後の非COMMENT Token。Tokenがなければnull
   */
  #findLastNonCommentTokenSeq() {
    for (let tokenIndex = this.tokens.length - 1; tokenIndex >= 0; tokenIndex--) {
      const currentToken = this.tokens[tokenIndex];

      if (currentToken.token_type !== "COMMENT") {
        return currentToken.token_seq;
      }
    }

    return null;
  }
}

// Node.jsから分割代入で読み込める形式で公開する。
// const { ClauseParser } = require("./clause_parser");
module.exports = {
  ClauseParser
};
