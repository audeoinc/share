"use strict";

const { TokenReader } = require("./token_reader");

/**
 * 1つのSELECT文について、トップレベルのClauseを抽出する。
 *
 * 対象:
 * - SELECT
 * - FROM
 * - WHERE
 * - GROUP BY
 * - HAVING
 * - QUALIFY
 * - ORDER BY
 * - LIMIT
 *
 * 位置情報はすべてtoken_seqで返す。
 */
class ClauseParser {
  constructor(tokens) {
    if (!Array.isArray(tokens)) {
      throw new TypeError("ClauseParser: tokens must be an array.");
    }

    this.tokens = tokens;
    this.reader = new TokenReader(tokens);
  }

  parse() {
    const clauses = [];

    this.reader.reset();

    while (!this.reader.isEnd()) {
      const currentToken = this.reader.current();

      if (currentToken.token_type === "COMMENT") {
        this.reader.advance();
        continue;
      }

      // 基本版では、関数やサブクエリ内部のClauseは対象外とする。
      if (currentToken.paren_depth !== 0) {
        this.reader.advance();
        continue;
      }

      const clauseMatch = this.#matchClause();

      if (!clauseMatch) {
        this.reader.advance();
        continue;
      }

      clauses.push({
        clause_seq: clauses.length + 1,
        clause_type: clauseMatch.clause_type,
        clause_start_seq: currentToken.token_seq,
        clause_end_seq: clauseMatch.clause_end_seq,
        body_start_seq: clauseMatch.body_start_seq,
        body_end_seq: null,
        paren_depth: currentToken.paren_depth
      });

      this.reader.advance(clauseMatch.token_count);
    }

    this.#setBodyEndSeq(clauses);

    return clauses;
  }

  #matchClause() {
    if (this.reader.matches("SELECT")) {
      return this.#createSingleTokenClause("SELECT");
    }

    if (this.reader.matches("FROM")) {
      return this.#createSingleTokenClause("FROM");
    }

    if (this.reader.matches("WHERE")) {
      return this.#createSingleTokenClause("WHERE");
    }

    if (this.reader.matches("HAVING")) {
      return this.#createSingleTokenClause("HAVING");
    }

    if (this.reader.matches("QUALIFY")) {
      return this.#createSingleTokenClause("QUALIFY");
    }

    if (this.reader.matches("LIMIT")) {
      return this.#createSingleTokenClause("LIMIT");
    }

    if (this.reader.matches("GROUP")) {
      return this.#createTwoTokenClause("GROUP_BY", "BY");
    }

    if (this.reader.matches("ORDER")) {
      return this.#createTwoTokenClause("ORDER_BY", "BY");
    }

    return null;
  }

  #createSingleTokenClause(clauseType) {
    const currentToken = this.reader.current();
    const nextToken = this.reader.peekNonComment(1);

    return {
      clause_type: clauseType,
      clause_end_seq: currentToken.token_seq,
      body_start_seq: nextToken ? nextToken.token_seq : null,
      token_count: 1
    };
  }

  #createTwoTokenClause(clauseType, secondKeyword) {
    const secondToken = this.reader.peekNonComment(1);

    if (!secondToken || secondToken.normalized_token !== secondKeyword) {
      return null;
    }

    const secondTokenOffset = this.#findOffsetByTokenSeq(secondToken.token_seq);
    const bodyStartToken = this.reader.peekNonComment(secondTokenOffset + 1);

    return {
      clause_type: clauseType,
      clause_end_seq: secondToken.token_seq,
      body_start_seq: bodyStartToken ? bodyStartToken.token_seq : null,
      token_count: secondTokenOffset + 1
    };
  }

  #setBodyEndSeq(clauses) {
    for (let clauseIndex = 0; clauseIndex < clauses.length; clauseIndex++) {
      const currentClause = clauses[clauseIndex];
      const nextClause = clauses[clauseIndex + 1];

      if (currentClause.body_start_seq === null) {
        currentClause.body_end_seq = null;
        continue;
      }

      if (nextClause) {
        currentClause.body_end_seq = this.#findPreviousNonCommentTokenSeq(
          nextClause.clause_start_seq
        );
        continue;
      }

      currentClause.body_end_seq = this.#findLastNonCommentTokenSeq();
    }
  }

  #findOffsetByTokenSeq(tokenSeq) {
    let offset = 0;

    while (true) {
      const targetToken = this.reader.peek(offset);

      if (!targetToken) {
        throw new RangeError(
          `ClauseParser: token_seq ${tokenSeq} was not found after the current position.`
        );
      }

      if (targetToken.token_seq === tokenSeq) {
        return offset;
      }

      offset++;
    }
  }

  #findPreviousNonCommentTokenSeq(tokenSeq) {
    let previousTokenSeq = null;

    for (const token of this.tokens) {
      if (token.token_seq >= tokenSeq) {
        break;
      }

      if (token.token_type !== "COMMENT") {
        previousTokenSeq = token.token_seq;
      }
    }

    return previousTokenSeq;
  }

  #findLastNonCommentTokenSeq() {
    for (let tokenIndex = this.tokens.length - 1; tokenIndex >= 0; tokenIndex--) {
      const currentToken = this.tokens[tokenIndex];

      if (currentToken.token_type !== "COMMENT") {
        return currentToken.token_seq;
      }
    }

    return null;
  }
}

module.exports = {
  ClauseParser
};
