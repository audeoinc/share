# Clause Parser v1

トップレベルの次のClauseを抽出します。

- SELECT
- FROM
- WHERE
- GROUP BY
- HAVING
- QUALIFY
- ORDER BY
- LIMIT

位置情報はすべて`token_seq`です。

## 実行

```bash
node test_clause_parser.js
```
