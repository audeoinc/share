# BigQuery View Lineage Pipeline v1

This package adds the operational SQL layer around the tested JavaScript
LineageEngine bundle.

## Files

1. `bigquery/create_lineage_tables.sql`
   Creates the normalized lineage result tables.

2. `bigquery/create_pipeline_tables.sql`
   Creates:
   - `lineage_analysis_staging`
   - `lineage_physical_columns_catalog`

3. `bigquery/load_physical_columns.sql`
   Loads `INFORMATION_SCHEMA.COLUMNS` for one source dataset into the shared
   catalog. Run it for every source dataset referenced by target Views.

4. `bigquery/create_persistent_lineage_udf.sql`
   Creates the permanent `analyze_lineage_json` JavaScript UDF.

5. `bigquery/run_single_view_analysis.sql`
   Reads one View definition and stores the exported result JSON in staging.

6. `bigquery/publish_staged_analysis.sql`
   Idempotently expands one staged JSON result into all normalized tables.

7. `bigquery/run_dataset_views_analysis.sql`
   Runs analysis for all Views in a dataset and stores each result in staging.

## Recommended execution order

```text
create_lineage_tables.sql
create_pipeline_tables.sql
load_physical_columns.sql          (repeat for source datasets)
create_persistent_lineage_udf.sql
run_single_view_analysis.sql
publish_staged_analysis.sql
```

After the single-View flow is confirmed, run:

```text
run_dataset_views_analysis.sql
```

The dataset script stages results only. This keeps parsing separate from table
publication and allows failed publications to be retried without rerunning the
JavaScript UDF.

## Placeholder replacement

Replace these placeholders before execution:

```text
YOUR_PROJECT
YOUR_DATASET
TARGET_PROJECT
TARGET_DATASET
TARGET_VIEW
SOURCE_PROJECT
SOURCE_DATASET
ANALYSIS_ID
```

## Important v1 boundary

The UDF receives the full `lineage_physical_columns_catalog` as JSON. This is
simple and reliable for initial validation. For a very large metadata estate,
the next optimization is a two-pass process:

1. Parse the SQL and identify source tables.
2. Load only metadata for those source tables and run physical resolution.

The current staging design allows that optimization without changing the
normalized result tables.
