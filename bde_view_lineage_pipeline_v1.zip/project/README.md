# BDE BigQuery Exporter v1

This package adds the first BigQuery integration layer to the JavaScript Lineage Engine.

## New files

- `src/bigquery_exporter.js`
- `test/test_bigquery_exporter.js`
- `bigquery/create_lineage_tables.sql`
- `bigquery/sample_export_to_ndjson.js`
- `bigquery/README.md`

## Design

`LineageEngine` remains responsible for analysis. `BigQueryExporter` adds analysis metadata and converts variable AST structures into JSON strings while preserving commonly queried fields as regular columns.

## Run tests

```bash
node test/test_bigquery_exporter.js
```

Run all existing tests with:

```bash
for file in test/test_*.js; do node "$file"; done
```

## Generate sample NDJSON

```bash
node bigquery/sample_export_to_ndjson.js
```

## Create BigQuery tables

Replace `YOUR_PROJECT.YOUR_DATASET` in:

```text
bigquery/create_lineage_tables.sql
```

and execute it in BigQuery.
