"use strict";

const fs = require("fs");
const path = require("path");
const { LineageEngine } = require("../src/lineage_engine");
const { BigQueryExporter } = require("../src/bigquery_exporter");

const physicalColumns = [
  {
    project_id: "project",
    dataset_id: "dataset",
    table_name: "sales",
    column_name: "customer_id",
    ordinal_position: 1,
    data_type: "INT64"
  },
  {
    project_id: "project",
    dataset_id: "dataset",
    table_name: "sales",
    column_name: "amount",
    ordinal_position: 2,
    data_type: "NUMERIC"
  }
];

const sqlText = `
WITH summary AS (
  SELECT customer_id, SUM(amount) AS total_amount
  FROM project.dataset.sales
  GROUP BY customer_id
)
SELECT customer_id, total_amount
FROM summary
`;

const engineResult = new LineageEngine({
  physicalColumns,
  strictMode: false
}).analyze(sqlText);

const exportedTables = new BigQueryExporter({
  analysis_id: "sample-analysis-001",
  view_project: "project",
  view_dataset: "dataset",
  view_name: "sample_view"
}).export(engineResult);

const outputDirectory = path.join(__dirname, "..", "output_ndjson");
fs.mkdirSync(outputDirectory, { recursive: true });

for (const [tableName, rows] of Object.entries(exportedTables)) {
  const outputPath = path.join(outputDirectory, `${tableName}.ndjson`);
  const contents = rows.map((row) => JSON.stringify(row)).join("\n");

  fs.writeFileSync(outputPath, contents ? `${contents}\n` : "", "utf8");
}

console.log(`NDJSON files were written to ${outputDirectory}`);
