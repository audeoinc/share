# BigQuery integration: phase 1

## Included files

- `create_lineage_tables.sql`: persistent table DDL
- `sample_export_to_ndjson.js`: converts a Node.js analysis result into one NDJSON file per table

## Current boundary

This phase intentionally does not embed the complete parser into a BigQuery JavaScript UDF yet.
It first stabilizes the persisted schemas and the export contract.

The next phase will add:

1. A single BigQuery-compatible JavaScript bundle.
2. A UDF that returns arrays of STRUCT values.
3. SQL that reads `INFORMATION_SCHEMA.VIEWS`, invokes the UDF and inserts each result array.
