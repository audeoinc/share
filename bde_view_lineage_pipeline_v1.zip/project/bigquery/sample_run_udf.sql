-- build/create_temp_lineage_udf.sqlを先に実行するか、
-- このファイルの前へ内容を貼り付けて実行する。

WITH input AS (
  SELECT
    '''
    SELECT
      s.customer_id,
      SUM(s.amount) AS total_amount
    FROM project.dataset.sales AS s
    GROUP BY s.customer_id
    ''' AS sql_text,
    TO_JSON_STRING([
      STRUCT(
        'PROJECT.DATASET.SALES' AS table_name,
        'CUSTOMER_ID' AS column_name,
        'CUSTOMER_ID' AS field_path
      ),
      STRUCT(
        'PROJECT.DATASET.SALES' AS table_name,
        'AMOUNT' AS column_name,
        'AMOUNT' AS field_path
      )
    ]) AS physical_columns_json
)
SELECT
  analyze_lineage_json(
    sql_text,
    physical_columns_json,
    TO_JSON_STRING(STRUCT(TRUE AS strict_mode)),
    TO_JSON_STRING(STRUCT(
      GENERATE_UUID() AS analysis_id,
      'PROJECT' AS view_project,
      'DATASET' AS view_dataset,
      'SALES_VIEW' AS view_name,
      FORMAT_TIMESTAMP('%FT%H:%M:%E*S%Ez', CURRENT_TIMESTAMP()) AS analyzed_at
    ))
  ) AS analysis_json
FROM input;
