"use strict";

const assert = require("assert");
const { LineageEngine } = require("../src/lineage_engine");

const physicalColumns = [
  {
    project_id: "project",
    dataset_id: "dataset",
    table_name: "sales",
    column_name: "customer_id",
    ordinal_position: 1,
    data_type: "INT64"
  },
  {
    project_id: "project",
    dataset_id: "dataset",
    table_name: "sales",
    column_name: "amount",
    ordinal_position: 2,
    data_type: "NUMERIC"
  },
  {
    project_id: "project",
    dataset_id: "dataset",
    table_name: "sales",
    column_name: "tax_rate",
    ordinal_position: 3,
    data_type: "NUMERIC"
  }
];

/*
 * テスト内容
 * ----------
 * 1回のanalyze()呼び出しで、Token化からLineage生成まで完了することを確認する。
 *
 * totalはamountとtax_rateに依存するため、物理依存は2件になる。
 */
{
  const engine = new LineageEngine({ physicalColumns });
  const result = engine.analyze(`
    SELECT amount * tax_rate AS total
    FROM project.dataset.sales
  `);
  const dependencyNames = result.lineage.physical_dependencies
    .map((item) => item.physical_column_name)
    .sort();

  assert.equal(result.analysis_status, "COMPLETED");
  assert.deepEqual(dependencyNames, ["AMOUNT", "TAX_RATE"]);
  assert.equal(result.resolutions.sources.node_type, "SOURCE_RESOLUTION");
  assert.equal(result.resolutions.columns.node_type, "COLUMN_RESOLUTION");
}

/*
 * CTEを含むQueryでも、Engineが各Resolverを正しい順番で呼び、
 * 最終的な物理カラムまで到達できることを確認する。
 */
{
  const engine = new LineageEngine({ physicalColumns });
  const result = engine.analyze(`
    WITH summary AS (
      SELECT SUM(amount) AS total_amount
      FROM project.dataset.sales
    )
    SELECT total_amount * 1.1 AS total_with_tax
    FROM summary
  `);

  assert.equal(
    result.lineage.root_output_lineages[0].dependencies[0].physical_column_name,
    "AMOUNT"
  );
  assert.ok(result.tables.query_scopes.length >= 2);
  assert.ok(result.tables.lineage_paths.length >= 1);
}

/*
 * impactTargetを渡した場合、Lineage生成後にImpactResolverも実行される。
 */
{
  const engine = new LineageEngine({ physicalColumns });
  const result = engine.analyze(
    `
      SELECT amount, amount * tax_rate AS total
      FROM project.dataset.sales
    `,
    {
      impactTarget: {
        physical_table_name: "project.dataset.sales",
        physical_column_name: "amount"
      }
    }
  );

  assert.equal(result.impact.impact_status, "IMPACT_FOUND");
  assert.equal(result.impact.root_affected_output_count, 2);
  assert.equal(result.tables.impact_paths.length, 2);
}

/*
 * non-strictモードでは、構文エラーがあっても例外を外へ投げず、
 * 解析できた途中結果と診断情報を返す。
 */
{
  const engine = new LineageEngine({
    physicalColumns,
    strictMode: false
  });
  const result = engine.analyze("SELECT amount + FROM project.dataset.sales");

  assert.equal(result.analysis_status, "PARTIAL_FAILURE");
  assert.ok(result.failed_stage);
  assert.equal(result.diagnostics[0].severity, "ERROR");
}

/*
 * strictモードでは、同じ構文エラーをLineageEngineStageErrorとして通知する。
 */
{
  const engine = new LineageEngine({ physicalColumns });
  let caughtError = null;

  try {
    engine.analyze("SELECT amount + FROM project.dataset.sales");
  } catch (error) {
    caughtError = error;
  }

  assert.ok(caughtError);
  assert.equal(caughtError.name, "LineageEngineStageError");
  assert.ok(caughtError.stage);
}

/*
 * BigQuery保存用tablesは、途中結果が存在しない場合も必ず配列を返す。
 * 呼び出し側がnull判定を繰り返さず、そのままINSERT処理へ渡せるためである。
 */
{
  const engine = new LineageEngine({ physicalColumns });
  const result = engine.analyze("SELECT 1 AS constant_value");

  assert.ok(Array.isArray(result.tables.tokens));
  assert.ok(Array.isArray(result.tables.sources));
  assert.ok(Array.isArray(result.tables.lineage_paths));
  assert.equal(
    result.lineage.root_output_lineages[0].lineage_status,
    "NO_COLUMN_DEPENDENCY"
  );
}

console.log("LineageEngine tests passed.");
