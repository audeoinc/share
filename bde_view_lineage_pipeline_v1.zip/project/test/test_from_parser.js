"use strict";

const assert = require("assert");
const { tokenize } = require("../src/lexer");
const { ClauseParser } = require("../src/clause_parser");
const { FromParser } = require("../src/from_parser");

/**
 * SQL全体からFROM Clauseを取得し、FromParserの解析結果を返す。
 *
 * ClauseParserはトップレベルClauseだけを返すため、find()で最初の
 * FROM Clauseを1件取得すれば、このテスト対象SQLのFROM本文を特定できる。
 */
function parseFrom(sqlText) {
  const tokens = tokenize(sqlText);
  const clauses = new ClauseParser(tokens).parse();
  const fromClause = clauses.find((clause) => clause.clause_type === "FROM");

  assert.ok(fromClause, "FROM Clauseが見つかりません。");

  return new FromParser(tokens).parse(fromClause);
}

/*
 * 明示AS aliasを持つ通常テーブルを解析する。
 */
const simpleFrom = parseFrom(`
  SELECT s.customer_id
  FROM project.dataset.sales AS s
`);

assert.equal(simpleFrom.source.source_type, "TABLE");
assert.equal(simpleFrom.source.name, "PROJECT.DATASET.SALES");
assert.equal(simpleFrom.source.alias, "S");
assert.equal(simpleFrom.source.alias_type, "EXPLICIT_AS");

/*
 * LEFT JOINとON条件を解析する。
 * ON条件の式構造はFromParser自身ではなくExpressionParserが作る。
 */
const joinFrom = parseFrom(`
  SELECT s.customer_id
  FROM project.dataset.sales s
  LEFT JOIN project.dataset.customer c
    ON s.customer_id = c.customer_id
   AND c.deleted_at IS NULL
`);

assert.equal(joinFrom.source.alias, "S");
assert.equal(joinFrom.source.alias_type, "IMPLICIT");
assert.equal(joinFrom.joins.length, 1);
assert.equal(joinFrom.joins[0].join_type, "LEFT");
assert.equal(joinFrom.joins[0].source.alias, "C");
assert.equal(joinFrom.joins[0].condition_type, "ON");
assert.equal(joinFrom.joins[0].condition.node_type, "LOGICAL_EXPRESSION");
assert.equal(joinFrom.joins[0].condition.operator, "AND");

/*
 * USINGの複数列を配列として取得する。
 */
const usingFrom = parseFrom(`
  SELECT *
  FROM sales s
  INNER JOIN customer c USING (customer_id, region_id)
`);

assert.equal(usingFrom.joins[0].join_type, "INNER");
assert.equal(usingFrom.joins[0].condition_type, "USING");
assert.deepEqual(usingFrom.joins[0].using_columns, ["CUSTOMER_ID", "REGION_ID"]);

/*
 * UNNESTの括弧内部をExpressionParserで解析し、aliasを保持する。
 */
const unnestFrom = parseFrom(`
  SELECT item.product_id
  FROM sales s
  CROSS JOIN UNNEST(s.items) AS item
`);

assert.equal(unnestFrom.joins[0].join_type, "CROSS");
assert.equal(unnestFrom.joins[0].source.source_type, "UNNEST");
assert.equal(unnestFrom.joins[0].source.expression.name, "s.items");
assert.equal(unnestFrom.joins[0].source.alias, "ITEM");

/*
 * FROMサブクエリについて、Token範囲だけでなくClauseとSELECT項目概要も保持する。
 */
const subqueryFrom = parseFrom(`
  SELECT q.customer_id
  FROM (
    SELECT customer_id, SUM(amount) AS total
    FROM sales
    GROUP BY customer_id
  ) AS q
`);

assert.equal(subqueryFrom.source.source_type, "SUBQUERY");
assert.equal(subqueryFrom.source.alias, "Q");
assert.ok(subqueryFrom.source.query_ast.clauses.length >= 3);
assert.equal(subqueryFrom.source.query_ast.select_items.length, 2);

/*
 * カンマ区切りの旧式FROMをCROSS JOIN相当として表現する。
 */
const commaFrom = parseFrom(`
  SELECT *
  FROM sales s, customer c
`);

assert.equal(commaFrom.joins.length, 1);
assert.equal(commaFrom.joins[0].join_type, "CROSS");
assert.equal(commaFrom.joins[0].join_syntax, "COMMA");
assert.equal(commaFrom.joins[0].source.alias, "C");

console.log("FromParser tests passed.");
