"use strict";

const assert = require("assert");
const { tokenize } = require("../src/lexer");
const { QueryParser } = require("../src/query_parser");
const { SourceResolver } = require("../src/source_resolver");
const { ColumnResolver } = require("../src/column_resolver");
const { OutputColumnResolver } = require("../src/output_column_resolver");
const { PhysicalColumnResolver } = require("../src/physical_column_resolver");
const { ResolutionContext } = require("../src/resolution_context");

const physicalColumns = [
  {
    project_id: "project",
    dataset_id: "dataset",
    table_name: "sales",
    column_name: "sale_id",
    ordinal_position: 1,
    data_type: "INT64"
  },
  {
    project_id: "project",
    dataset_id: "dataset",
    table_name: "sales",
    column_name: "customer_id",
    ordinal_position: 2,
    data_type: "INT64"
  },
  {
    project_id: "project",
    dataset_id: "dataset",
    table_name: "sales",
    column_name: "amount",
    ordinal_position: 3,
    data_type: "NUMERIC"
  },
  {
    project_id: "project",
    dataset_id: "dataset",
    table_name: "sales",
    column_name: "payload",
    field_path: "payload",
    ordinal_position: 4,
    data_type: "STRUCT"
  },
  {
    project_id: "project",
    dataset_id: "dataset",
    table_name: "sales",
    column_name: "payload",
    field_path: "payload.code",
    ordinal_position: 4,
    data_type: "STRING"
  },
  {
    project_id: "project",
    dataset_id: "dataset",
    table_name: "customer",
    column_name: "customer_id",
    ordinal_position: 1,
    data_type: "INT64"
  },
  {
    project_id: "project",
    dataset_id: "dataset",
    table_name: "customer",
    column_name: "customer_name",
    ordinal_position: 2,
    data_type: "STRING"
  }
];

/**
 * ParserからPhysicalColumnResolverまでを実運用順に呼び出す。
 *
 * 各Resolverを単独テストするだけでなく、token_seqとscope_idが全工程で
 * 正しく引き継がれることを確認するため、常に一連の処理を通す。
 */
function resolvePhysicalColumns(sqlText) {
  const tokens = tokenize(sqlText);
  const queryAst = new QueryParser(tokens).parse();
  const sourceResolution = new SourceResolver().resolve(queryAst);
  const columnResolution = new ColumnResolver(tokens).resolve(
    queryAst,
    sourceResolution
  );
  const context = new ResolutionContext(tokens, queryAst);

  context.setSourceResolution(sourceResolution);
  context.setColumnResolution(columnResolution);

  const outputResolution = new OutputColumnResolver(tokens).resolve(context);
  const physicalResolution = new PhysicalColumnResolver(
    physicalColumns
  ).resolve(context);

  return {
    context,
    outputResolution,
    physicalResolution
  };
}

/*
 * 修飾参照`s.amount`を、salesテーブルのamount物理カラムへ解決する。
 */
{
  const { physicalResolution } = resolvePhysicalColumns(`
    SELECT s.amount
    FROM project.dataset.sales AS s
  `);
  const reference = physicalResolution.column_references[0];

  assert.equal(reference.physical_resolution_status, "PHYSICAL_RESOLVED");
  assert.equal(
    reference.physical_columns[0].physical_table_name,
    "PROJECT.DATASET.SALES"
  );
  assert.equal(reference.physical_columns[0].physical_column_name, "AMOUNT");
}

/*
 * ColumnResolverではSourceが2つあるためAMBIGUOUSだった非修飾amountを、
 * 実カラムを持つsalesだけへ絞り込めることを確認する。
 */
{
  const { physicalResolution } = resolvePhysicalColumns(`
    SELECT amount
    FROM project.dataset.sales AS s
    JOIN project.dataset.customer AS c
      ON s.customer_id = c.customer_id
  `);
  const reference = physicalResolution.column_references.find((item) => {
    return item.clause_type === "SELECT";
  });

  assert.equal(reference.original_resolution_status, "AMBIGUOUS");
  assert.equal(reference.physical_resolution_status, "PHYSICAL_RESOLVED");
  assert.equal(reference.source_name, "PROJECT.DATASET.SALES");
}

/*
 * customer_idは両方の物理テーブルに存在するため、スキーマを見ても
 * 非修飾参照を1件へ決められない。PHYSICAL_AMBIGUOUSを維持する。
 */
{
  const { context, physicalResolution } = resolvePhysicalColumns(`
    SELECT customer_id
    FROM project.dataset.sales AS s
    JOIN project.dataset.customer AS c
      ON s.customer_id = c.customer_id
  `);
  const reference = physicalResolution.column_references.find((item) => {
    return item.clause_type === "SELECT";
  });
  const diagnostic = context.diagnostics.find((item) => {
    return item.code === "PHYSICAL_COLUMN_AMBIGUOUS";
  });

  assert.equal(reference.physical_resolution_status, "PHYSICAL_AMBIGUOUS");
  assert.ok(diagnostic);
}

/*
 * `s.*`はsalesのトップレベル列だけへ展開する。
 * COLUMN_FIELD_PATHS由来のpayload.codeは、Wildcard出力列として重複追加しない。
 */
{
  const { physicalResolution } = resolvePhysicalColumns(`
    SELECT s.*
    FROM project.dataset.sales AS s
  `);
  const names = physicalResolution.wildcard_expansions.map((item) => {
    return item.output_column_name;
  });

  assert.deepEqual(names, ["SALE_ID", "CUSTOMER_ID", "AMOUNT", "PAYLOAD"]);
}

/*
 * CTE参照はこの段階で物理テーブルへ直接置き換えない。
 * CTE出力列までは解決済みとして保持し、次のLineageResolverが
 * CTE内部Expressionを辿る責務を持つ。
 */
{
  const { physicalResolution } = resolvePhysicalColumns(`
    WITH summary AS (
      SELECT customer_id, SUM(amount) AS total
      FROM project.dataset.sales
      GROUP BY customer_id
    )
    SELECT s.total
    FROM summary AS s
  `);
  const rootReference = physicalResolution.column_references.find((item) => {
    return item.source_type === "CTE" && item.column_name === "TOTAL";
  });

  assert.equal(
    rootReference.physical_resolution_status,
    "DERIVED_SOURCE_RESOLVED"
  );
}

/*
 * メタデータに存在しない実カラムは明示的にエラー診断へ追加する。
 */
{
  const { context, physicalResolution } = resolvePhysicalColumns(`
    SELECT s.missing_column
    FROM project.dataset.sales AS s
  `);
  const reference = physicalResolution.column_references[0];
  const diagnostic = context.diagnostics.find((item) => {
    return item.code === "PHYSICAL_COLUMN_NOT_FOUND";
  });

  assert.equal(
    reference.physical_resolution_status,
    "PHYSICAL_COLUMN_NOT_FOUND"
  );
  assert.ok(diagnostic);
}

/*
 * ResolutionContextのJSON向け出力にも物理解決結果が含まれることを確認する。
 */
{
  const { context } = resolvePhysicalColumns(`
    SELECT amount
    FROM project.dataset.sales
  `);
  const contextObject = context.toObject();

  assert.equal(
    contextObject.physical_column_resolution.node_type,
    "PHYSICAL_COLUMN_RESOLUTION"
  );
}

console.log("PhysicalColumnResolver tests passed.");
