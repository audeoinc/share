"use strict";

const assert = require("assert");
const { tokenize } = require("../src/lexer");
const { ClauseParser } = require("../src/clause_parser");
const { LimitParser } = require("../src/limit_parser");

/**
 * SQL全体からLIMIT Clauseを探し、LimitParserの結果を返す。
 *
 * JavaScriptメモ
 * ----------------
 * find()は条件に一致する最初の要素そのものを返す。
 * ClauseParserはトップレベルClauseだけを返すため、LIMITは1件として扱う。
 */
function parseLimit(sqlText) {
  const tokens = tokenize(sqlText);
  const clauses = new ClauseParser(tokens).parse();
  const limitClause = clauses.find((clause) => clause.clause_type === "LIMIT");

  assert.ok(limitClause, "LIMIT Clauseが見つかりません。");

  return new LimitParser(tokens).parse(limitClause);
}

/*
 * テスト内容
 * ----------
 * LIMIT件数だけを指定した場合、count_expressionだけが生成され、
 * offset_expressionはnullになることを確認する。
 */
const simpleLimit = parseLimit(`
  SELECT customer_id
  FROM sales
  LIMIT 100
`);

assert.equal(simpleLimit.count_expression.node_type, "LITERAL_EXPRESSION");
assert.equal(simpleLimit.count_expression.value, "100");
assert.equal(simpleLimit.offset_expression, null);

/*
 * テスト内容
 * ----------
 * LIMIT count OFFSET skip_rowsを、それぞれ独立したExpressionとして保持する。
 */
const limitWithOffset = parseLimit(`
  SELECT customer_id
  FROM sales
  ORDER BY customer_id
  LIMIT 100 OFFSET 20
`);

assert.equal(limitWithOffset.count_expression.value, "100");
assert.equal(limitWithOffset.offset_expression.value, "20");

/*
 * テスト内容
 * ----------
 * BigQueryではcountとOFFSETが定数式で指定できるため、単純な数値だけでなく、
 * 括弧を含む算術式もExpressionParserへ委譲できることを確認する。
 */
const expressionLimit = parseLimit(`
  SELECT customer_id
  FROM sales
  LIMIT (10 + 5) OFFSET 2 * 3
`);

assert.equal(
  expressionLimit.count_expression.node_type,
  "PARENTHESIZED_EXPRESSION"
);
assert.equal(expressionLimit.count_expression.expression.operator, "+");
assert.equal(expressionLimit.offset_expression.operator, "*");

/*
 * テスト内容
 * ----------
 * COMMENTを除外しても、LIMITとOFFSETの境界を正しく解析できることを確認する。
 */
const commentLimit = parseLimit(`
  SELECT customer_id
  FROM sales
  LIMIT
    50 -- 最大取得件数
  OFFSET
    5
`);

assert.equal(commentLimit.count_expression.value, "50");
assert.equal(commentLimit.offset_expression.value, "5");

/*
 * テスト内容
 * ----------
 * SQL終端のセミコロンをLIMIT式へ含めないことを確認する。
 */
const semicolonLimit = parseLimit("SELECT 1 LIMIT 1;");

assert.equal(semicolonLimit.count_expression.value, "1");

/*
 * テスト内容
 * ----------
 * LIMIT count, skip_rowsはBigQuery構文ではないため、曖昧に解析せず
 * SyntaxErrorを返すことを確認する。
 */
assert.throws(
  () => parseLimit("SELECT 1 LIMIT 10, 20"),
  SyntaxError
);

/*
 * テスト内容
 * ----------
 * OFFSETの右側が空なら、構文エラーとして検出する。
 */
assert.throws(
  () => parseLimit("SELECT 1 LIMIT 10 OFFSET"),
  SyntaxError
);

/*
 * LIMIT以外のClauseを渡した場合、入口検証でTypeErrorになることを確認する。
 */
const invalidTokens = tokenize("SELECT 1 WHERE 1 = 1");
const whereClause = new ClauseParser(invalidTokens)
  .parse()
  .find((clause) => clause.clause_type === "WHERE");

assert.throws(
  () => new LimitParser(invalidTokens).parse(whereClause),
  TypeError
);

console.log("LimitParser tests passed.");
