"use strict";

const assert = require("assert");
const { tokenize } = require("../src/lexer");
const { QueryParser } = require("../src/query_parser");
const { SourceResolver } = require("../src/source_resolver");

/**
 * SQLをQuery ASTへ変換した後、SourceResolverでsource scopeを作る。
 *
 * テスト側でLexer・QueryParser・SourceResolverを順番に呼ぶことで、
 * 実運用と同じ処理経路を確認する。
 */
function resolveSql(sqlText) {
  const tokens = tokenize(sqlText);
  const queryAst = new QueryParser(tokens).parse();
  const resolver = new SourceResolver();
  const resolution = resolver.resolve(queryAst);

  return { resolver, queryAst, resolution };
}

/*
 * 物理テーブルの完全名とaliasを解決できることを確認する。
 */
{
  const { resolver, resolution } = resolveSql(`
    SELECT s.amount
    FROM project.dataset.sales AS s
  `);
  const rootScope = resolution.scopes[0];
  const source = resolver.findSource(resolution, rootScope.scope_id, "s");

  assert.equal(source.source_type, "PHYSICAL_TABLE");
  assert.equal(source.source_name, "PROJECT.DATASET.SALES");
  assert.equal(source.source_alias, "S");
}

/*
 * CTE名を物理テーブルと誤認せず、CTE本文の子scopeへ関連付ける。
 */
{
  const { resolver, resolution } = resolveSql(`
    WITH customer_summary AS (
      SELECT customer_id, SUM(amount) AS total
      FROM project.dataset.sales
      GROUP BY customer_id
    )
    SELECT c.customer_id, c.total
    FROM customer_summary AS c
  `);
  const rootScope = resolution.scopes.find((scope) => scope.scope_type === "ROOT_QUERY");
  const source = resolver.findSource(resolution, rootScope.scope_id, "c");

  assert.equal(source.source_type, "CTE");
  assert.equal(source.source_name, "CUSTOMER_SUMMARY");
  assert.ok(source.cte_query_scope_id);
  assert.ok(
    resolution.scopes.some((scope) => scope.scope_id === source.cte_query_scope_id)
  );
}

/*
 * JOIN先も主FROMソースと同じscopeへ登録する。
 */
{
  const { resolver, resolution } = resolveSql(`
    SELECT s.amount, c.customer_name
    FROM project.dataset.sales AS s
    LEFT JOIN project.dataset.customer AS c
      ON s.customer_id = c.customer_id
  `);
  const rootScope = resolution.scopes[0];

  assert.equal(rootScope.sources.length, 2);
  assert.equal(resolver.findSource(resolution, rootScope.scope_id, "S").source_role, "FROM");
  assert.equal(resolver.findSource(resolution, rootScope.scope_id, "C").source_role, "JOIN");
}

/*
 * aliasがない物理テーブルは末尾テーブル名をデフォルト参照名にする。
 */
{
  const { resolver, resolution } = resolveSql(`
    SELECT sales.amount
    FROM project.dataset.sales
  `);
  const rootScope = resolution.scopes[0];
  const source = resolver.findSource(resolution, rootScope.scope_id, "sales");

  assert.equal(source.source_alias, "SALES");
}

/*
 * UNNESTは物理テーブルとは別source_typeとして保持する。
 */
{
  const { resolver, resolution } = resolveSql(`
    SELECT item
    FROM project.dataset.orders AS o
    CROSS JOIN UNNEST(o.items) AS item
  `);
  const rootScope = resolution.scopes[0];
  const source = resolver.findSource(resolution, rootScope.scope_id, "item");

  assert.equal(source.source_type, "UNNEST");
  assert.ok(source.expression);
}

/*
 * 同じscope内でaliasが重複すると、ColumnResolverが参照先を一意に決められない。
 * そのためSourceResolverの段階でエラーにする。
 */
{
  assert.throws(
    () => resolveSql(`
      SELECT x.id
      FROM project.dataset.table_a AS x
      JOIN project.dataset.table_b AS x
        ON x.id = x.id
    `),
    /duplicate source reference/i
  );
}

/*
 * findSourceは現在scopeで見つからない参照を親scopeへ検索する。
 * QueryParser/FromParserが完全な相関サブクエリASTを返す拡張後も、
 * この検索規則をそのまま利用できることを直接確認する。
 */
{
  const resolver = new SourceResolver();
  const resolution = {
    scopes: [
      {
        scope_id: 1,
        parent_scope_id: null,
        reference_map: { OUTER_ALIAS: 1 },
        sources: [{ source_id: 1, source_alias: "OUTER_ALIAS" }]
      },
      {
        scope_id: 2,
        parent_scope_id: 1,
        reference_map: {},
        sources: []
      }
    ]
  };

  const source = resolver.findSource(resolution, 2, "outer_alias");

  assert.equal(source.source_alias, "OUTER_ALIAS");
}

console.log("SourceResolver tests passed.");
