"use strict";

const assert = require("assert");
const { tokenize } = require("../src/lexer");
const { QueryParser } = require("../src/query_parser");
const { SourceResolver } = require("../src/source_resolver");
const { ColumnResolver } = require("../src/column_resolver");
const { OutputColumnResolver } = require("../src/output_column_resolver");
const { PhysicalColumnResolver } = require("../src/physical_column_resolver");
const { LineageResolver } = require("../src/lineage_resolver");
const { ImpactResolver } = require("../src/impact_resolver");
const { ResolutionContext } = require("../src/resolution_context");

const physicalColumns = [
  {
    project_id: "project",
    dataset_id: "dataset",
    table_name: "sales",
    column_name: "customer_id",
    ordinal_position: 1,
    data_type: "INT64"
  },
  {
    project_id: "project",
    dataset_id: "dataset",
    table_name: "sales",
    column_name: "amount",
    ordinal_position: 2,
    data_type: "NUMERIC"
  },
  {
    project_id: "project",
    dataset_id: "dataset",
    table_name: "sales",
    column_name: "tax_rate",
    ordinal_position: 3,
    data_type: "NUMERIC"
  }
];

/**
 * ParserからLineageまでの結果をResolutionContextへ登録する。
 *
 * ImpactResolverはSQLを再解析せず、完成済みLineageを逆引きするため、
 * テストでも先にLineageResolverまで実行する。
 */
function createContext(sqlText) {
  const tokens = tokenize(sqlText);
  const queryAst = new QueryParser(tokens).parse();
  const sourceResolution = new SourceResolver().resolve(queryAst);
  const columnResolution = new ColumnResolver(tokens).resolve(
    queryAst,
    sourceResolution
  );
  const context = new ResolutionContext(tokens, queryAst);

  context.setSourceResolution(sourceResolution);
  context.setColumnResolution(columnResolution);

  new OutputColumnResolver(tokens).resolve(context);
  new PhysicalColumnResolver(physicalColumns).resolve(context);
  new LineageResolver().resolve(context);

  return context;
}

/*
 * amountを変更した場合、amountを利用する2つの最終出力列だけが
 * 影響対象になることを確認する。
 */
{
  const context = createContext(`
    SELECT
      amount,
      amount * tax_rate AS total,
      customer_id
    FROM project.dataset.sales
  `);
  const result = new ImpactResolver().resolve(context, {
    physical_table_name: "project.dataset.sales",
    physical_column_name: "amount"
  });
  const names = result.root_affected_outputs
    .map((output) => output.output_column_name)
    .sort();

  assert.equal(result.impact_status, "IMPACT_FOUND");
  assert.deepEqual(names, ["AMOUNT", "TOTAL"]);
  assert.equal(result.root_affected_output_count, 2);
}

/*
 * 複数段CTEを経由しても、元物理カラムamountから最終出力列まで
 * 逆向きに到達できることを確認する。
 */
{
  const context = createContext(`
    WITH summary AS (
      SELECT SUM(amount) AS total_amount
      FROM project.dataset.sales
    ), taxed AS (
      SELECT total_amount * 1.1 AS total_with_tax
      FROM summary
    )
    SELECT total_with_tax
    FROM taxed
  `);
  const result = new ImpactResolver().resolve(context, {
    physical_table_name: "PROJECT.DATASET.SALES",
    physical_column_name: "AMOUNT"
  });
  const rootOutput = result.root_affected_outputs[0];

  assert.equal(rootOutput.output_column_name, "TOTAL_WITH_TAX");
  assert.ok(
    rootOutput.impact_paths[0].some((item) => item === "SCOPE_2.TOTAL_AMOUNT")
  );
}

/*
 * columnを省略した場合、指定テーブルのいずれかの列に依存する
 * すべての出力列を対象にする。
 */
{
  const context = createContext(`
    SELECT customer_id, amount * tax_rate AS total
    FROM project.dataset.sales
  `);
  const result = new ImpactResolver().resolve(context, {
    physical_table_name: "project.dataset.sales"
  });

  assert.equal(result.root_affected_output_count, 2);
  assert.equal(result.impact_paths.length, 3);
}

/*
 * 利用されていない物理カラムではNO_IMPACTになる。
 */
{
  const context = createContext(`
    SELECT customer_id
    FROM project.dataset.sales
  `);
  const result = new ImpactResolver().resolve(context, {
    physical_table_name: "project.dataset.sales",
    physical_column_name: "amount"
  });

  assert.equal(result.impact_status, "NO_IMPACT");
  assert.equal(result.affected_output_count, 0);
}

/*
 * ResolutionContextのJSON向け出力にImpact結果が含まれることを確認する。
 */
{
  const context = createContext(`
    SELECT amount
    FROM project.dataset.sales
  `);

  new ImpactResolver().resolve(context, {
    physical_table_name: "project.dataset.sales",
    physical_column_name: "amount"
  });

  assert.equal(
    context.toObject().impact_resolution.node_type,
    "IMPACT_RESOLUTION"
  );
}

console.log("ImpactResolver tests passed.");
