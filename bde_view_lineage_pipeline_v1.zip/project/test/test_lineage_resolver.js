"use strict";

const assert = require("assert");
const { tokenize } = require("../src/lexer");
const { QueryParser } = require("../src/query_parser");
const { SourceResolver } = require("../src/source_resolver");
const { ColumnResolver } = require("../src/column_resolver");
const { OutputColumnResolver } = require("../src/output_column_resolver");
const { PhysicalColumnResolver } = require("../src/physical_column_resolver");
const { LineageResolver } = require("../src/lineage_resolver");
const { ResolutionContext } = require("../src/resolution_context");

const physicalColumns = [
  {
    project_id: "project",
    dataset_id: "dataset",
    table_name: "sales",
    column_name: "customer_id",
    ordinal_position: 1,
    data_type: "INT64"
  },
  {
    project_id: "project",
    dataset_id: "dataset",
    table_name: "sales",
    column_name: "amount",
    ordinal_position: 2,
    data_type: "NUMERIC"
  },
  {
    project_id: "project",
    dataset_id: "dataset",
    table_name: "sales",
    column_name: "tax_rate",
    ordinal_position: 3,
    data_type: "NUMERIC"
  }
];

/**
 * SQL文字列をParserからLineageResolverまで順番に通す。
 *
 * JavaScriptメモ:
 * 各Resolverの戻り値を個別変数へ保持するのは、途中結果をテストから
 * 確認しやすくするためである。ResolutionContextには同じ結果を登録し、
 * 後続Resolverが共通の解析単位として参照できるようにする。
 */
function resolveLineage(sqlText) {
  const tokens = tokenize(sqlText);
  const queryAst = new QueryParser(tokens).parse();
  const sourceResolution = new SourceResolver().resolve(queryAst);
  const columnResolution = new ColumnResolver(tokens).resolve(
    queryAst,
    sourceResolution
  );
  const context = new ResolutionContext(tokens, queryAst);

  context.setSourceResolution(sourceResolution);
  context.setColumnResolution(columnResolution);

  new OutputColumnResolver(tokens).resolve(context);
  new PhysicalColumnResolver(physicalColumns).resolve(context);

  const lineageResolution = new LineageResolver().resolve(context);

  return { context, lineageResolution };
}

/*
 * 単純な物理カラム参照が、そのまま物理テーブル列へ到達することを確認する。
 */
{
  const { lineageResolution } = resolveLineage(`
    SELECT s.amount
    FROM project.dataset.sales AS s
  `);
  const lineage = lineageResolution.root_output_lineages[0];

  assert.equal(lineage.lineage_status, "RESOLVED");
  assert.equal(lineage.dependencies[0].physical_table_name, "PROJECT.DATASET.SALES");
  assert.equal(lineage.dependencies[0].physical_column_name, "AMOUNT");
}

/*
 * 算術式に複数の物理カラムが含まれる場合、両方を依存先として保持する。
 */
{
  const { lineageResolution } = resolveLineage(`
    SELECT amount * tax_rate AS total
    FROM project.dataset.sales
  `);
  const names = lineageResolution.root_output_lineages[0].dependencies
    .map((dependency) => dependency.physical_column_name)
    .sort();

  assert.deepEqual(names, ["AMOUNT", "TAX_RATE"]);
}

/*
 * 2段のCTEを経由しても、最終的な物理カラムamountへ到達することを確認する。
 *
 * total_with_tax
 *   -> taxed.total_with_tax
 *   -> summary.total_amount
 *   -> sales.amount
 */
{
  const { lineageResolution } = resolveLineage(`
    WITH summary AS (
      SELECT customer_id, SUM(amount) AS total_amount
      FROM project.dataset.sales
      GROUP BY customer_id
    ), taxed AS (
      SELECT customer_id, total_amount * 1.1 AS total_with_tax
      FROM summary
    )
    SELECT total_with_tax
    FROM taxed
  `);
  const lineage = lineageResolution.root_output_lineages[0];

  assert.equal(lineage.lineage_status, "RESOLVED");
  assert.equal(lineage.dependencies.length, 1);
  assert.equal(lineage.dependencies[0].physical_column_name, "AMOUNT");
  assert.ok(
    lineage.dependencies[0].lineage_path.some((item) => {
      return item === "SCOPE_2.TOTAL_AMOUNT";
    })
  );
}

/*
 * CTEの単純列も、CTE出力列を経由して元物理列へ解決する。
 */
{
  const { lineageResolution } = resolveLineage(`
    WITH summary AS (
      SELECT customer_id
      FROM project.dataset.sales
    )
    SELECT s.customer_id
    FROM summary AS s
  `);
  const dependency = lineageResolution.root_output_lineages[0].dependencies[0];

  assert.equal(dependency.physical_column_name, "CUSTOMER_ID");
}

/*
 * 列を持たない定数式は正常であり、未解決ではなくNO_COLUMN_DEPENDENCYになる。
 */
{
  const { lineageResolution } = resolveLineage(`SELECT 1 AS constant_value`);
  const lineage = lineageResolution.root_output_lineages[0];

  assert.equal(lineage.lineage_status, "NO_COLUMN_DEPENDENCY");
  assert.equal(lineage.dependencies.length, 0);
}

/*
 * ResolutionContextのJSON向け出力にもLineage結果が含まれることを確認する。
 */
{
  const { context } = resolveLineage(`
    SELECT amount
    FROM project.dataset.sales
  `);

  assert.equal(
    context.toObject().lineage_resolution.node_type,
    "LINEAGE_RESOLUTION"
  );
}

console.log("LineageResolver tests passed.");
