"use strict";

const assert = require("assert");
const { tokenize } = require("../src/lexer");
const { QueryParser } = require("../src/query_parser");
const { SourceResolver } = require("../src/source_resolver");
const { ColumnResolver } = require("../src/column_resolver");
const { ResolutionContext } = require("../src/resolution_context");
const { OutputColumnResolver } = require("../src/output_column_resolver");

/**
 * ParserとResolverを実運用と同じ順序で実行する。
 *
 * ResolutionContextへ各段階の結果を登録し、
 * OutputColumnResolverが共通Contextから必要情報を取得できることも確認する。
 */
function resolveOutputColumns(sqlText) {
  const tokens = tokenize(sqlText);
  const queryAst = new QueryParser(tokens).parse();
  const sourceResolution = new SourceResolver().resolve(queryAst);
  const columnResolution = new ColumnResolver(tokens).resolve(
    queryAst,
    sourceResolution
  );
  const context = new ResolutionContext(tokens, queryAst);

  context.setSourceResolution(sourceResolution);
  context.setColumnResolution(columnResolution);

  const outputResolution = new OutputColumnResolver(tokens).resolve(context);

  return {
    tokens,
    queryAst,
    context,
    outputResolution
  };
}

/*
 * 単純カラムはSelectParserが導出した列名をそのまま出力名として利用する。
 * Expression ASTもIDENTIFIER_EXPRESSIONとして保持される。
 */
{
  const { outputResolution } = resolveOutputColumns(`
    SELECT customer_id
    FROM project.dataset.sales
  `);
  const outputColumn = outputResolution.output_columns[0];

  assert.equal(outputColumn.output_column_name, "CUSTOMER_ID");
  assert.equal(outputColumn.output_status, "RESOLVED");
  assert.equal(outputColumn.expression.node_type, "IDENTIFIER_EXPRESSION");
}

/*
 * 明示aliasはQueryの公開列名になる。
 * 元ExpressionはSUM(amount)のFUNCTION_CALL_EXPRESSIONとして保持する。
 */
{
  const { outputResolution } = resolveOutputColumns(`
    SELECT SUM(amount) AS total_amount
    FROM project.dataset.sales
  `);
  const outputColumn = outputResolution.output_columns[0];

  assert.equal(outputColumn.output_column_name, "TOTAL_AMOUNT");
  assert.equal(outputColumn.alias_type, "EXPLICIT_AS");
  assert.equal(outputColumn.expression.node_type, "FUNCTION_CALL_EXPRESSION");
}

/*
 * aliasを持たない計算式は、安全な出力名を導出できない。
 * Resolverは処理を中断せずUNNAMEDとして保持し、Contextへ警告を追加する。
 */
{
  const { context, outputResolution } = resolveOutputColumns(`
    SELECT amount * tax_rate
    FROM project.dataset.sales
  `);
  const outputColumn = outputResolution.output_columns[0];
  const diagnostic = context.diagnostics.find(
    (item) => item.code === "OUTPUT_COLUMN_NAME_UNRESOLVED"
  );

  assert.equal(outputColumn.output_column_name, null);
  assert.equal(outputColumn.output_status, "UNNAMED");
  assert.ok(diagnostic);
}

/*
 * CTE列名一覧は、CTE本文SELECTのaliasより優先して位置順に適用する。
 *
 * WITH summary(id, total) AS (
 *   SELECT customer_id, SUM(amount) AS source_total ...
 * )
 */
{
  const { outputResolution } = resolveOutputColumns(`
    WITH summary(id, total) AS (
      SELECT customer_id, SUM(amount) AS source_total
      FROM project.dataset.sales
      GROUP BY customer_id
    )
    SELECT id, total
    FROM summary
  `);
  const cteScope = outputResolution.scopes.find(
    (scope) => scope.scope_type === "CTE_QUERY"
  );

  assert.deepEqual(
    cteScope.output_columns.map((item) => item.output_column_name),
    ["ID", "TOTAL"]
  );
  assert.equal(cteScope.output_columns[1].original_output_alias, "SOURCE_TOTAL");
  assert.equal(cteScope.output_columns[1].name_source, "CTE_COLUMN_LIST");
}

/*
 * CTE列名一覧とSELECT項目数が一致しない場合、
 * 後工程で見落とさないようContextへERROR診断を残す。
 */
{
  const { context } = resolveOutputColumns(`
    WITH summary(id) AS (
      SELECT customer_id, amount
      FROM project.dataset.sales
    )
    SELECT id
    FROM summary
  `);
  const diagnostic = context.diagnostics.find(
    (item) => item.code === "CTE_COLUMN_COUNT_MISMATCH"
  );

  assert.ok(diagnostic);
  assert.equal(diagnostic.severity, "ERROR");
}

/*
 * Wildcardは物理スキーマが無い段階では展開せず、
 * WILDCARD_PENDINGとして修飾子とExpression ASTを保持する。
 */
{
  const { outputResolution } = resolveOutputColumns(`
    SELECT s.*
    FROM project.dataset.sales AS s
  `);
  const outputColumn = outputResolution.output_columns[0];

  assert.equal(outputColumn.output_status, "WILDCARD_PENDING");
  assert.equal(outputColumn.wildcard_type, "QUALIFIED");
  assert.equal(outputColumn.wildcard_qualifier, "S");
  assert.equal(outputColumn.expression.node_type, "WILDCARD_EXPRESSION");
}

/*
 * 同じ公開列名が複数ある場合も解析結果は返すが、
 * 曖昧性を診断情報として明示する。
 */
{
  const { context } = resolveOutputColumns(`
    SELECT customer_id, account_id AS customer_id
    FROM project.dataset.sales
  `);
  const diagnostic = context.diagnostics.find(
    (item) => item.code === "DUPLICATE_OUTPUT_COLUMN_NAME"
  );

  assert.ok(diagnostic);
  assert.equal(diagnostic.output_column_name, "CUSTOMER_ID");
}

/*
 * ResolutionContext.toObject()はクラスメソッドを含まない
 * JSON保存向けのプレーンオブジェクトを返す。
 */
{
  const { context } = resolveOutputColumns(`
    SELECT customer_id
    FROM project.dataset.sales
  `);
  const contextObject = context.toObject();

  assert.equal(contextObject.node_type, "RESOLUTION_CONTEXT");
  assert.equal(
    contextObject.output_column_resolution.node_type,
    "OUTPUT_COLUMN_RESOLUTION"
  );
  assert.ok(Array.isArray(contextObject.diagnostics));
}

console.log("OutputColumnResolver tests passed.");
