"use strict";

const fs = require("fs");
const path = require("path");

const projectRoot = path.resolve(__dirname, "..");
const requiredFiles = [
  "bigquery/create_pipeline_tables.sql",
  "bigquery/load_physical_columns.sql",
  "bigquery/create_persistent_lineage_udf.sql",
  "bigquery/run_single_view_analysis.sql",
  "bigquery/publish_staged_analysis.sql",
  "bigquery/run_dataset_views_analysis.sql"
];

for (const relativePath of requiredFiles) {
  const fullPath = path.join(projectRoot, relativePath);

  if (!fs.existsSync(fullPath)) {
    throw new Error(`Required pipeline file is missing: ${relativePath}`);
  }

  const content = fs.readFileSync(fullPath, "utf8");

  if (content.trim().length === 0) {
    throw new Error(`Pipeline file is empty: ${relativePath}`);
  }
}

const persistentUdf = fs.readFileSync(
  path.join(projectRoot, "bigquery/create_persistent_lineage_udf.sql"),
  "utf8"
);

if (!persistentUdf.includes("CREATE OR REPLACE FUNCTION")) {
  throw new Error("Persistent UDF SQL was not generated.");
}

if (persistentUdf.includes("CREATE TEMP FUNCTION analyze_lineage_json")) {
  throw new Error("Persistent UDF SQL still contains the TEMP declaration.");
}

const publishSql = fs.readFileSync(
  path.join(projectRoot, "bigquery/publish_staged_analysis.sql"),
  "utf8"
);

const expectedArrays = [
  "analyses",
  "tokens",
  "query_scopes",
  "sources",
  "cte_definitions",
  "column_references",
  "output_columns",
  "physical_column_references",
  "wildcard_expansions",
  "output_lineages",
  "lineage_paths",
  "impact_paths",
  "diagnostics"
];

for (const arrayName of expectedArrays) {
  if (!publishSql.includes(`$.${arrayName}`)) {
    throw new Error(`Publishing SQL does not expand: ${arrayName}`);
  }
}

console.log("BigQuery View Pipeline static test passed.");
