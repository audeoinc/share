"use strict";

const assert = require("assert");
const { tokenize } = require("../src/lexer");
const { ClauseParser } = require("../src/clause_parser");
const { QualifyParser } = require("../src/qualify_parser");

/**
 * SQL全体からQUALIFY Clauseを取得し、QualifyParserで解析する。
 *
 * JavaScriptメモ
 * ----------------
 * find()は条件に一致する最初の要素そのものを返す。
 * ClauseParserはトップレベルだけを返すため、対象SQLのQUALIFYは1件であり、
 * 配列を返すfilter()よりfind()が目的に合う。
 */
function parseQualify(sqlText) {
  const tokens = tokenize(sqlText);
  const clauses = new ClauseParser(tokens).parse();
  const qualifyClause = clauses.find(
    (clause) => clause.clause_type === "QUALIFY"
  );

  assert.ok(qualifyClause, "QUALIFY Clauseが見つかりません。");

  return new QualifyParser(tokens).parse(qualifyClause);
}

/*
 * テスト内容
 * ----------
 * ROW_NUMBER() OVER(...)がWINDOW_EXPRESSIONとなり、比較式の左辺へ入ることを
 * 確認する。
 */
const rowNumberQualify = parseQualify(`
  SELECT customer_id, created_at
  FROM sales
  QUALIFY ROW_NUMBER() OVER (
    PARTITION BY customer_id
    ORDER BY created_at DESC
  ) = 1
`);

assert.equal(rowNumberQualify.expression.node_type, "COMPARISON_EXPRESSION");
assert.equal(rowNumberQualify.expression.operator, "=");
assert.equal(rowNumberQualify.expression.left.node_type, "WINDOW_EXPRESSION");
assert.equal(
  rowNumberQualify.expression.left.function.function_name,
  "ROW_NUMBER"
);
assert.equal(
  rowNumberQualify.expression.left.window.partition_by[0].name,
  "customer_id"
);
assert.equal(
  rowNumberQualify.expression.left.window.order_by[0].direction,
  "DESC"
);

/*
 * テスト内容
 * ----------
 * ウィンドウ条件と通常条件をANDで結んだ場合、ANDを最上位とするASTになる
 * ことを確認する。
 */
const rankAndStatus = parseQualify(`
  SELECT category, amount, status
  FROM sales
  QUALIFY RANK() OVER (
    PARTITION BY category
    ORDER BY amount DESC
  ) <= 3
  AND status = 'ACTIVE'
`);

assert.equal(rankAndStatus.expression.node_type, "LOGICAL_EXPRESSION");
assert.equal(rankAndStatus.expression.operator, "AND");
assert.equal(
  rankAndStatus.expression.left.left.node_type,
  "WINDOW_EXPRESSION"
);
assert.equal(rankAndStatus.expression.right.operator, "=");

/*
 * テスト内容
 * ----------
 * PARTITION BYを複数指定し、ウィンドウ内ORDER BYにNULLS LASTがある場合も
 * 属性として保持できることを確認する。
 */
const multiplePartition = parseQualify(`
  SELECT customer_id, category, created_at
  FROM sales
  QUALIFY ROW_NUMBER() OVER (
    PARTITION BY customer_id, category
    ORDER BY created_at DESC NULLS LAST
  ) = 1
`);

const windowNode = multiplePartition.expression.left.window;
assert.equal(windowNode.partition_by.length, 2);
assert.equal(windowNode.order_by[0].direction, "DESC");
assert.equal(windowNode.order_by[0].nulls_order, "LAST");

/*
 * テスト内容
 * ----------
 * QUALIFY内のコメントを除外しても、ウィンドウ式を正しく解析できることを
 * 確認する。
 */
const commentQualify = parseQualify(`
  SELECT customer_id
  FROM sales
  QUALIFY
    -- 顧客単位で最新行だけを残す
    ROW_NUMBER() OVER (PARTITION BY customer_id ORDER BY created_at DESC) = 1
`);

assert.equal(commentQualify.expression.left.node_type, "WINDOW_EXPRESSION");

/*
 * テスト内容
 * ----------
 * SQL全体のORDER BYはQUALIFY本文に混入しないことを確認する。
 * Window括弧内部のORDER BYはparen_depthが深いためClauseParserの対象外だが、
 * トップレベルORDER BYは次ClauseとしてQUALIFYの終了境界になる。
 */
const orderBoundary = parseQualify(`
  SELECT customer_id, created_at
  FROM sales
  QUALIFY ROW_NUMBER() OVER (
    PARTITION BY customer_id
    ORDER BY created_at DESC
  ) = 1
  ORDER BY created_at DESC
`);

assert.equal(orderBoundary.expression.operator, "=");

/*
 * テスト内容
 * ----------
 * 後続LIMITがQUALIFY本文に混入しないことを確認する。
 */
const limitBoundary = parseQualify(`
  SELECT customer_id
  FROM sales
  QUALIFY ROW_NUMBER() OVER (ORDER BY created_at DESC) = 1
  LIMIT 100
`);

assert.equal(limitBoundary.expression.operator, "=");

/*
 * QUALIFY以外のClauseを渡した場合、入口検証でTypeErrorになることを確認する。
 */
const invalidTokens = tokenize("SELECT 1 WHERE 1 = 1");
const whereClause = new ClauseParser(invalidTokens)
  .parse()
  .find((clause) => clause.clause_type === "WHERE");

assert.throws(
  () => new QualifyParser(invalidTokens).parse(whereClause),
  TypeError
);

console.log("QualifyParser tests passed.");
