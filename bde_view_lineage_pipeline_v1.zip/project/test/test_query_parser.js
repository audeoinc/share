"use strict";

const assert = require("assert");
const { tokenize } = require("../src/lexer");
const { QueryParser } = require("../src/query_parser");

/**
 * SQL文字列をToken化し、Query全体を解析する共通補助関数。
 *
 * 各テストでLexerとQueryParserの初期化を繰り返さず、
 * 検証したいQuery構造へ集中するために用意する。
 */
function parseQuery(sqlText) {
  const tokens = tokenize(sqlText);
  const parser = new QueryParser(tokens);

  return parser.parse();
}

/*
 * テスト1
 * -------
 * これまで作成したClause別Parserが、QueryParserから正しく呼ばれ、
 * 1つのQuery ASTへ統合されることを確認する。
 */
const fullQueryAst = parseQuery(`
SELECT
  customer_id,
  SUM(amount) AS total_amount
FROM project.dataset.sales AS s
WHERE status = 'ACTIVE'
GROUP BY customer_id
HAVING SUM(amount) > 100
QUALIFY ROW_NUMBER() OVER (
  PARTITION BY customer_id
  ORDER BY created_at DESC
) = 1
ORDER BY total_amount DESC
LIMIT 10 OFFSET 5;
`);

assert.equal(fullQueryAst.node_type, "QUERY");
assert.equal(fullQueryAst.select.length, 2);
assert.equal(fullQueryAst.from.source.alias, "S");
assert.equal(fullQueryAst.where.expression.operator, "=");
assert.equal(fullQueryAst.group_by.items.length, 1);
assert.equal(fullQueryAst.having.expression.operator, ">");
assert.equal(fullQueryAst.qualify.expression.operator, "=");
assert.equal(fullQueryAst.order_by.items[0].direction, "DESC");
assert.equal(fullQueryAst.limit.offset_expression.value, "5");

/*
 * テスト2
 * -------
 * 複数CTE、CTE列名一覧、WITH RECURSIVEを解析できることを確認する。
 *
 * CTE内部のQueryはQueryParser自身を再帰的に呼んで解析するため、
 * 各CTEのqueryにもSELECT/FROM等のASTが入ることを期待する。
 */
const cteQueryAst = parseQuery(`
WITH RECURSIVE
  base(id, amount) AS (
    SELECT id, amount
    FROM project.dataset.sales
    WHERE amount > 0
  ),
  summary AS (
    SELECT id, SUM(amount) AS total_amount
    FROM base
    GROUP BY id
  )
SELECT id, total_amount
FROM summary
WHERE total_amount >= 100;
`);

assert.equal(cteQueryAst.recursive, true);
assert.equal(cteQueryAst.common_table_expressions.length, 2);
assert.deepEqual(
  cteQueryAst.common_table_expressions[0].column_names,
  ["ID", "AMOUNT"]
);
assert.equal(
  cteQueryAst.common_table_expressions[0].query.where.expression.operator,
  ">"
);
assert.equal(
  cteQueryAst.common_table_expressions[1].query.group_by.items.length,
  1
);
assert.equal(cteQueryAst.from.source.name, "SUMMARY");

/*
 * テスト3
 * -------
 * SELECTだけでFROMを持たないQueryも解析できることを確認する。
 * BigQueryではSELECT 1のようなQueryが有効であるため、FROMは必須ではない。
 */
const selectOnlyAst = parseQuery("SELECT 1 AS value");

assert.equal(selectOnlyAst.select.length, 1);
assert.equal(selectOnlyAst.from, null);
assert.equal(selectOnlyAst.where, null);

/*
 * テスト4
 * -------
 * 不正なCTE定義では、途中まで成功扱いにせずSyntaxErrorを返す。
 */
assert.throws(
  () => parseQuery("WITH broken AS SELECT 1 SELECT 2"),
  SyntaxError
);

console.log("QueryParser tests passed.");
