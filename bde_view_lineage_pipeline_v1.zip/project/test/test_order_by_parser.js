"use strict";

const assert = require("assert");
const { tokenize } = require("../src/lexer");
const { ClauseParser } = require("../src/clause_parser");
const { OrderByParser } = require("../src/order_by_parser");

/**
 * SQL全体からORDER_BY Clauseを取得し、OrderByParserで解析する。
 *
 * JavaScriptメモ
 * ----------------
 * find()は条件に一致する最初の要素そのものを返す。
 * ClauseParserはトップレベルClauseだけを返すため、対象SQLのORDER_BYは1件であり、
 * 一致要素を配列で返すfilter()よりfind()が目的に合う。
 */
function parseOrderBy(sqlText) {
  const tokens = tokenize(sqlText);
  const clauses = new ClauseParser(tokens).parse();
  const orderByClause = clauses.find(
    (clause) => clause.clause_type === "ORDER_BY"
  );

  assert.ok(orderByClause, "ORDER_BY Clauseが見つかりません。");

  return new OrderByParser(tokens).parse(orderByClause);
}

/*
 * テスト内容
 * ----------
 * 複数の並び替え項目とASC / DESCを解析できることを確認する。
 */
const multipleItems = parseOrderBy(`
  SELECT customer_id, amount, created_at
  FROM sales
  ORDER BY customer_id ASC, amount DESC, created_at
`);

assert.equal(multipleItems.items.length, 3);
assert.equal(multipleItems.items[0].expression.name, "customer_id");
assert.equal(multipleItems.items[0].direction, "ASC");
assert.equal(multipleItems.items[1].direction, "DESC");
assert.equal(multipleItems.items[2].direction, null);

/*
 * テスト内容
 * ----------
 * NULLS FIRST / NULLS LASTを方向指定とは別の属性として保持できることを確認する。
 */
const nullsOrder = parseOrderBy(`
  SELECT customer_id, score
  FROM sales
  ORDER BY score DESC NULLS LAST, customer_id ASC NULLS FIRST
`);

assert.equal(nullsOrder.items[0].direction, "DESC");
assert.equal(nullsOrder.items[0].nulls_order, "LAST");
assert.equal(nullsOrder.items[1].direction, "ASC");
assert.equal(nullsOrder.items[1].nulls_order, "FIRST");

/*
 * テスト内容
 * ----------
 * 関数内部のカンマがORDER BY項目の区切りとして扱われないことを確認する。
 */
const functionExpression = parseOrderBy(`
  SELECT customer_id, flag, created_at, updated_at
  FROM sales
  ORDER BY IF(flag, created_at, updated_at) DESC, customer_id
`);

assert.equal(functionExpression.items.length, 2);
assert.equal(
  functionExpression.items[0].expression.node_type,
  "FUNCTION_CALL_EXPRESSION"
);
assert.equal(functionExpression.items[0].expression.arguments.length, 3);
assert.equal(functionExpression.items[0].direction, "DESC");

/*
 * テスト内容
 * ----------
 * ORDER BY 1, 2の位置番号がLiteral Expressionとして保持されることを確認する。
 */
const ordinalOrder = parseOrderBy(`
  SELECT customer_id, amount
  FROM sales
  ORDER BY 1 ASC, 2 DESC
`);

assert.equal(ordinalOrder.items[0].expression.node_type, "LITERAL_EXPRESSION");
assert.equal(ordinalOrder.items[0].expression.value, "1");
assert.equal(ordinalOrder.items[1].expression.value, "2");

/*
 * テスト内容
 * ----------
 * コメントを除外しても、前後の並び替え項目と修飾子を正しく解析できることを
 * 確認する。
 */
const commentOrder = parseOrderBy(`
  SELECT customer_id, amount
  FROM sales
  ORDER BY
    customer_id, -- 顧客順
    amount DESC
`);

assert.equal(commentOrder.items.length, 2);
assert.equal(commentOrder.items[1].direction, "DESC");

/*
 * テスト内容
 * ----------
 * 後続LIMITをORDER BY本文へ含めないことを確認する。
 */
const limitBoundary = parseOrderBy(`
  SELECT customer_id, amount
  FROM sales
  ORDER BY amount DESC
  LIMIT 100
`);

assert.equal(limitBoundary.items.length, 1);
assert.equal(limitBoundary.items[0].expression.name, "amount");
assert.equal(limitBoundary.items[0].direction, "DESC");

/*
 * ORDER_BY以外のClauseを渡した場合、入口検証でTypeErrorになることを確認する。
 */
const invalidTokens = tokenize("SELECT 1 WHERE 1 = 1");
const whereClause = new ClauseParser(invalidTokens)
  .parse()
  .find((clause) => clause.clause_type === "WHERE");

assert.throws(
  () => new OrderByParser(invalidTokens).parse(whereClause),
  TypeError
);

console.log("OrderByParser tests passed.");
