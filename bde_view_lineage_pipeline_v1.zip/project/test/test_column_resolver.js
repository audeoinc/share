"use strict";

const assert = require("assert");
const { tokenize } = require("../src/lexer");
const { QueryParser } = require("../src/query_parser");
const { SourceResolver } = require("../src/source_resolver");
const { ColumnResolver } = require("../src/column_resolver");

/**
 * SQL文字列をQuery AST、Source Resolution、Column Resolutionへ順番に変換する。
 *
 * ColumnResolverだけを単独で呼ばず、実運用と同じ処理経路を通すことで、
 * Parser間のtoken_seq連携も含めて検証する。
 */
function resolveColumns(sqlText) {
  const tokens = tokenize(sqlText);
  const queryAst = new QueryParser(tokens).parse();
  const sourceResolution = new SourceResolver().resolve(queryAst);
  const columnResolution = new ColumnResolver(tokens).resolve(
    queryAst,
    sourceResolution
  );

  return { tokens, queryAst, sourceResolution, columnResolution };
}

/*
 * 修飾列`s.amount`では、sを物理テーブルSourceへ解決する。
 * 物理テーブルの実カラム一覧はまだ無いため、ステータスは
 * SOURCE_RESOLVEDとなり、カラム存在確認は後続Resolverへ残す。
 */
{
  const { columnResolution } = resolveColumns(`
    SELECT s.amount
    FROM project.dataset.sales AS s
  `);
  const reference = columnResolution.column_references[0];

  assert.equal(reference.qualifier, "S");
  assert.equal(reference.column_name, "AMOUNT");
  assert.equal(reference.source_name, "PROJECT.DATASET.SALES");
  assert.equal(reference.resolution_status, "SOURCE_RESOLVED");
}

/*
 * Sourceが1つだけなら、非修飾列amountもそのSourceへ結び付けられる。
 */
{
  const { columnResolution } = resolveColumns(`
    SELECT amount
    FROM project.dataset.sales
  `);
  const reference = columnResolution.column_references[0];

  assert.equal(reference.source_alias, "SALES");
  assert.equal(reference.resolution_status, "SOURCE_RESOLVED");
}

/*
 * Sourceが複数あり、非修飾列の所属をスキーマ無しで判断できない場合は、
 * 誤って1件へ決めずAMBIGUOUSとして候補Sourceを保持する。
 */
{
  const { columnResolution } = resolveColumns(`
    SELECT customer_id
    FROM project.dataset.sales AS s
    JOIN project.dataset.customer AS c
      ON s.customer_id = c.customer_id
  `);
  const selectReference = columnResolution.column_references.find(
    (item) => item.clause_type === "SELECT"
  );

  assert.equal(selectReference.resolution_status, "AMBIGUOUS");
  assert.equal(selectReference.candidate_source_ids.length, 2);
}

/*
 * CTEのSELECT出力列は既知なので、c.totalをCTE列として完全に解決する。
 */
{
  const { columnResolution } = resolveColumns(`
    WITH summary AS (
      SELECT customer_id, SUM(amount) AS total
      FROM project.dataset.sales
      GROUP BY customer_id
    )
    SELECT c.total
    FROM summary AS c
  `);
  const rootSelectReference = columnResolution.column_references.find((item) => {
    return item.clause_type === "SELECT" && item.qualifier === "C";
  });

  assert.equal(rootSelectReference.source_type, "CTE");
  assert.equal(rootSelectReference.resolution_status, "RESOLVED");
}

/*
 * CTEに存在しない列を修飾して参照した場合、Sourceは解決できても
 * 列名はUNRESOLVED_COLUMNになる。
 */
{
  const { columnResolution } = resolveColumns(`
    WITH summary AS (
      SELECT customer_id
      FROM project.dataset.sales
    )
    SELECT s.missing_column
    FROM summary AS s
  `);
  const reference = columnResolution.column_references.find(
    (item) => item.qualifier === "S"
  );

  assert.equal(reference.source_type, "CTE");
  assert.equal(reference.resolution_status, "UNRESOLVED_COLUMN");
}

/*
 * SELECTだけでなく、JOIN ONとWHERE内の識別子も収集する。
 */
{
  const { columnResolution } = resolveColumns(`
    SELECT s.amount, c.customer_name
    FROM project.dataset.sales AS s
    JOIN project.dataset.customer AS c
      ON s.customer_id = c.customer_id
    WHERE s.amount > 100
  `);
  const clauseTypes = new Set(
    columnResolution.column_references.map((item) => item.clause_type)
  );

  assert.ok(clauseTypes.has("SELECT"));
  assert.ok(clauseTypes.has("JOIN_ON"));
  assert.ok(clauseTypes.has("WHERE"));
}

/*
 * qualified wildcardは修飾子Sourceへ解決する。
 */
{
  const { columnResolution } = resolveColumns(`
    SELECT s.*
    FROM project.dataset.sales AS s
  `);
  const reference = columnResolution.column_references[0];

  assert.equal(reference.reference_type, "WILDCARD");
  assert.equal(reference.source_alias, "S");
  assert.equal(reference.resolution_status, "RESOLVED");
}

console.log("ColumnResolver tests passed.");
