"use strict";

const assert = require("assert");
const { tokenize } = require("../src/lexer");
const { ClauseParser } = require("../src/clause_parser");
const { WhereParser } = require("../src/where_parser");

/**
 * SQL全体からWHERE Clauseを1件取得し、WhereParserで解析する。
 *
 * JavaScriptメモ
 * ----------------
 * find()は条件に一致する最初の要素そのものを返す。
 * ClauseParserはトップレベルClauseだけを返すため、このテスト対象SQLでは
 * WHERE Clauseは1件だけであり、filter()ではなくfind()が適している。
 */
function parseWhere(sqlText) {
  const tokens = tokenize(sqlText);
  const clauses = new ClauseParser(tokens).parse();
  const whereClause = clauses.find((clause) => clause.clause_type === "WHERE");

  assert.ok(whereClause, "WHERE Clauseが見つかりません。");

  return new WhereParser(tokens).parse(whereClause);
}

/*
 * テスト内容
 * ----------
 * 単純な比較条件がCOMPARISON_EXPRESSIONへ変換されることを確認する。
 */
const simpleWhere = parseWhere(`
  SELECT customer_id
  FROM sales
  WHERE amount >= 100
`);

assert.equal(simpleWhere.clause_type, "WHERE");
assert.equal(simpleWhere.expression.node_type, "COMPARISON_EXPRESSION");
assert.equal(simpleWhere.expression.operator, ">=");
assert.equal(simpleWhere.expression.left.name, "amount");
assert.equal(simpleWhere.expression.right.value, "100");

/*
 * テスト内容
 * ----------
 * ANDがORより高い優先順位で解析されることを確認する。
 *
 * status = 'A' OR amount > 100 AND deleted_at IS NULL
 *
 * 期待する最上位構造:
 *
 * OR
 * ├── status = 'A'
 * └── AND
 *     ├── amount > 100
 *     └── deleted_at IS NULL
 */
const logicalWhere = parseWhere(`
  SELECT *
  FROM sales
  WHERE status = 'A'
     OR amount > 100
    AND deleted_at IS NULL
`);

assert.equal(logicalWhere.expression.node_type, "LOGICAL_EXPRESSION");
assert.equal(logicalWhere.expression.operator, "OR");
assert.equal(logicalWhere.expression.right.operator, "AND");

/*
 * テスト内容
 * ----------
 * BETWEEN構文内のANDと、その後ろの論理ANDを区別できることを確認する。
 */
const betweenWhere = parseWhere(`
  SELECT *
  FROM sales
  WHERE amount BETWEEN 10 AND 20
    AND status NOT IN ('CANCELLED', 'DELETED')
`);

assert.equal(betweenWhere.expression.operator, "AND");
assert.equal(betweenWhere.expression.left.node_type, "BETWEEN_EXPRESSION");
assert.equal(betweenWhere.expression.right.node_type, "IN_EXPRESSION");
assert.equal(betweenWhere.expression.right.negated, true);

/*
 * テスト内容
 * ----------
 * WHERE本文中のCOMMENT TokenをExpressionParserが無視できることを確認する。
 * WhereParserはコメント除去を重複実装せず、ExpressionParserへ委譲する。
 */
const commentWhere = parseWhere(`
  SELECT *
  FROM sales
  WHERE
    -- NULLセーフ比較を行う
    old_value IS DISTINCT FROM new_value
`);

assert.equal(
  commentWhere.expression.node_type,
  "DISTINCT_FROM_EXPRESSION"
);
assert.equal(commentWhere.expression.negated, false);

/*
 * テスト内容
 * ----------
 * Clause境界が正しく使われ、WHEREの後ろにあるGROUP BYを
 * ExpressionParserへ渡していないことを確認する。
 */
const boundaryWhere = parseWhere(`
  SELECT customer_id, SUM(amount)
  FROM sales
  WHERE amount > 0
  GROUP BY customer_id
`);

assert.equal(boundaryWhere.expression.operator, ">");
assert.ok(boundaryWhere.body_end_seq < boundaryWhere.end_token_seq + 1);

/*
 * 不正なClause種別を渡した場合、早い段階でTypeErrorになることを確認する。
 */
const invalidTokens = tokenize("SELECT 1");
const selectClause = new ClauseParser(invalidTokens)
  .parse()
  .find((clause) => clause.clause_type === "SELECT");

assert.throws(
  () => new WhereParser(invalidTokens).parse(selectClause),
  TypeError
);

console.log("WhereParser tests passed.");
