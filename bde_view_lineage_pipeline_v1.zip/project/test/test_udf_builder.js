"use strict";

const assert = require("assert");
const fs = require("fs");
const path = require("path");
const { UdfBuilder } = require("../build_udf");

/*
 * UDF Builderのテスト。
 *
 * 確認すること:
 * 1. bundleとSQLが生成される。
 * 2. bundle内にrequire/module.exportsの未処理記述が残らない。
 * 3. 生成bundleをNode.jsで読み込み、Lineage解析を実行できる。
 * 4. Exporterを有効にした結果もJSONとして返せる。
 */
const projectDir = path.join(__dirname, "..");
const buildDir = path.join(projectDir, "build");
const manifest = new UdfBuilder().build();

const bundlePath = path.join(buildDir, "lineage_udf_bundle.js");
const sqlPath = path.join(buildDir, "create_temp_lineage_udf.sql");

assert.ok(fs.existsSync(bundlePath));
assert.ok(fs.existsSync(sqlPath));
assert.ok(manifest.source_file_count > 10);

const bundleText = fs.readFileSync(bundlePath, "utf8");
assert.ok(!bundleText.includes('require("./'));
assert.ok(bundleText.includes("function analyzeLineageForBigQuery"));

const { analyzeLineageForBigQuery } = require(bundlePath);

const sqlText = `
SELECT
  s.customer_id,
  SUM(s.amount) AS total_amount
FROM project.dataset.sales AS s
GROUP BY s.customer_id
`;

const physicalColumns = [
  {
    table_name: "PROJECT.DATASET.SALES",
    column_name: "CUSTOMER_ID",
    field_path: "CUSTOMER_ID"
  },
  {
    table_name: "PROJECT.DATASET.SALES",
    column_name: "AMOUNT",
    field_path: "AMOUNT"
  }
];

const resultJson = analyzeLineageForBigQuery(
  sqlText,
  JSON.stringify(physicalColumns),
  JSON.stringify({ strict_mode: true }),
  null
);

const result = JSON.parse(resultJson);
assert.equal(result.analysis_status, "COMPLETED");
assert.ok(result.tables.lineage_paths.length >= 2);

const exportedJson = analyzeLineageForBigQuery(
  sqlText,
  JSON.stringify(physicalColumns),
  JSON.stringify({ strict_mode: true }),
  JSON.stringify({
    analysis_id: "udf-builder-test",
    view_project: "PROJECT",
    view_dataset: "DATASET",
    view_name: "SALES_VIEW",
    analyzed_at: "2026-07-17T00:00:00.000Z"
  })
);

const exported = JSON.parse(exportedJson);
assert.equal(exported.analysis_status, "COMPLETED");
assert.equal(exported.exported_tables.analyses.length, 1);
assert.equal(
  exported.exported_tables.analyses[0].analysis_id,
  "udf-builder-test"
);

console.log("test_udf_builder: passed");
