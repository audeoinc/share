"use strict";

const assert = require("assert");
const { tokenize } = require("../src/lexer");
const { ClauseParser } = require("../src/clause_parser");
const { GroupByParser } = require("../src/group_by_parser");

/**
 * SQL全体からGROUP_BY Clauseを取得し、GroupByParserで解析する。
 *
 * JavaScriptメモ
 * ----------------
 * find()は条件に一致する最初の要素そのものを返す。
 * ClauseParserはトップレベルClauseだけを返すため、このテスト対象SQLでは
 * GROUP_BY Clauseは1件だけであり、find()が目的に合っている。
 */
function parseGroupBy(sqlText) {
  const tokens = tokenize(sqlText);
  const clauses = new ClauseParser(tokens).parse();
  const groupByClause = clauses.find((clause) => clause.clause_type === "GROUP_BY");

  assert.ok(groupByClause, "GROUP_BY Clauseが見つかりません。");

  return new GroupByParser(tokens).parse(groupByClause);
}

/*
 * テスト内容
 * ----------
 * 複数の通常式を、トップレベルのカンマで分割できることを確認する。
 * 関数内部のカンマはGROUP BY項目の区切りとして扱ってはいけない。
 */
const normalGroupBy = parseGroupBy(`
  SELECT customer_id, DATE(created_at), IF(flag, category_a, category_b)
  FROM sales
  GROUP BY customer_id, DATE(created_at), IF(flag, category_a, category_b)
`);

assert.equal(normalGroupBy.items.length, 3);
assert.equal(normalGroupBy.items[0].grouping_type, "EXPRESSION");
assert.equal(normalGroupBy.items[0].expression.name, "customer_id");
assert.equal(normalGroupBy.items[1].expression.node_type, "FUNCTION_CALL_EXPRESSION");
assert.equal(normalGroupBy.items[2].expression.arguments.length, 3);

/*
 * テスト内容
 * ----------
 * GROUP BY 1のような位置番号がLiteral Expressionとして保持されることを確認する。
 */
const ordinalGroupBy = parseGroupBy(`
  SELECT customer_id, category
  FROM sales
  GROUP BY 1, 2
`);

assert.equal(ordinalGroupBy.items[0].expression.node_type, "LITERAL_EXPRESSION");
assert.equal(ordinalGroupBy.items[0].expression.value, "1");
assert.equal(ordinalGroupBy.items[1].expression.value, "2");

/*
 * テスト内容
 * ----------
 * ROLLUPとCUBEを通常の関数呼び出しではなく、GROUP BY固有の構文として
 * 識別できることを確認する。
 */
const rollupCubeGroupBy = parseGroupBy(`
  SELECT region, category, SUM(amount)
  FROM sales
  GROUP BY ROLLUP(region, category), CUBE(channel, device)
`);

assert.equal(rollupCubeGroupBy.items[0].grouping_type, "ROLLUP");
assert.equal(rollupCubeGroupBy.items[0].expressions.length, 2);
assert.equal(rollupCubeGroupBy.items[1].grouping_type, "CUBE");
assert.equal(rollupCubeGroupBy.items[1].expressions[1].name, "device");

/*
 * テスト内容
 * ----------
 * GROUPING SETSの各括弧を独立した集合として解析できることを確認する。
 * 空集合()は全体集計を表すため、expressionsが空配列になることを期待する。
 */
const groupingSets = parseGroupBy(`
  SELECT region, category, SUM(amount)
  FROM sales
  GROUP BY GROUPING SETS ((region, category), (region), ())
`);

assert.equal(groupingSets.items.length, 1);
assert.equal(groupingSets.items[0].grouping_type, "GROUPING_SETS");
assert.equal(groupingSets.items[0].sets.length, 3);
assert.equal(groupingSets.items[0].sets[0].expressions.length, 2);
assert.equal(groupingSets.items[0].sets[1].expressions.length, 1);
assert.equal(groupingSets.items[0].sets[2].expressions.length, 0);

/*
 * テスト内容
 * ----------
 * GROUP BY後ろのHAVINGを本文範囲へ含めないことを確認する。
 */
const boundaryGroupBy = parseGroupBy(`
  SELECT customer_id, SUM(amount)
  FROM sales
  GROUP BY customer_id
  HAVING SUM(amount) > 100
`);

assert.equal(boundaryGroupBy.items.length, 1);
assert.equal(boundaryGroupBy.items[0].expression.name, "customer_id");

/*
 * 不正なClause種別を渡した場合、入口でTypeErrorになることを確認する。
 */
const invalidTokens = tokenize("SELECT 1");
const selectClause = new ClauseParser(invalidTokens)
  .parse()
  .find((clause) => clause.clause_type === "SELECT");

assert.throws(
  () => new GroupByParser(invalidTokens).parse(selectClause),
  TypeError
);

console.log("GroupByParser tests passed.");
