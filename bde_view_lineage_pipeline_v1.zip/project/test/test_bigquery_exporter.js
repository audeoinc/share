"use strict";

const assert = require("assert");
const { LineageEngine } = require("../src/lineage_engine");
const { BigQueryExporter } = require("../src/bigquery_exporter");

const physicalColumns = [
  {
    project_id: "project",
    dataset_id: "dataset",
    table_name: "sales",
    column_name: "amount",
    ordinal_position: 1,
    data_type: "NUMERIC"
  },
  {
    project_id: "project",
    dataset_id: "dataset",
    table_name: "sales",
    column_name: "tax_rate",
    ordinal_position: 2,
    data_type: "NUMERIC"
  }
];

/*
 * テスト内容
 * ----------
 * LineageEngineの各中間結果へ、同じanalysis_idとView識別情報が
 * 付与されることを確認する。
 */
{
  const result = new LineageEngine({ physicalColumns }).analyze(`
    SELECT amount * tax_rate AS total
    FROM project.dataset.sales
  `);
  const exported = new BigQueryExporter({
    analysis_id: "analysis-001",
    view_project: "project",
    view_dataset: "dataset",
    view_name: "sales_view",
    analyzed_at: "2026-07-17T00:00:00.000Z"
  }).export(result);

  assert.equal(exported.analyses.length, 1);
  assert.equal(exported.analyses[0].analysis_id, "analysis-001");
  assert.equal(exported.tokens[0].view_name, "sales_view");
  assert.equal(exported.lineage_paths.length, 2);
  assert.equal(exported.lineage_paths[0].analysis_id, "analysis-001");
  assert.ok(Array.isArray(exported.lineage_paths[0].lineage_path));
}

/*
 * ASTなどの入れ子構造はJSON文字列へ変換される。
 * BigQueryのJSON列へSAFE.PARSE_JSONで投入できる形式を確認する。
 */
{
  const result = new LineageEngine({ physicalColumns }).analyze(`
    SELECT amount + tax_rate AS total
    FROM project.dataset.sales
  `);
  const exported = new BigQueryExporter({
    analysis_id: "analysis-002"
  }).export(result);

  assert.equal(typeof exported.output_columns[0].expression_json, "string");
  assert.doesNotThrow(() => JSON.parse(exported.output_columns[0].expression_json));
}

/*
 * analysis_idは全テーブルを結合する主キーの一部になるため必須とする。
 */
{
  assert.throws(
    () => new BigQueryExporter({}),
    /analysis_id is required/
  );
}

console.log("BigQueryExporter tests passed.");
