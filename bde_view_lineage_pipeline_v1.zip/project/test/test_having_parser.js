"use strict";

const assert = require("assert");
const { tokenize } = require("../src/lexer");
const { ClauseParser } = require("../src/clause_parser");
const { HavingParser } = require("../src/having_parser");

/**
 * SQL全体からHAVING Clauseを1件取得し、HavingParserで解析する。
 *
 * JavaScriptメモ
 * ----------------
 * find()は条件に一致する最初の要素そのものを返す。
 * ClauseParserはトップレベルClauseだけを返すため、このテスト対象SQLでは
 * HAVING Clauseは1件だけであり、filter()ではなくfind()が適している。
 */
function parseHaving(sqlText) {
  const tokens = tokenize(sqlText);
  const clauses = new ClauseParser(tokens).parse();
  const havingClause = clauses.find(
    (clause) => clause.clause_type === "HAVING"
  );

  assert.ok(havingClause, "HAVING Clauseが見つかりません。");

  return new HavingParser(tokens).parse(havingClause);
}

/*
 * テスト内容
 * ----------
 * 集約関数を含む単純なHAVING条件が比較式へ変換されることを確認する。
 */
const simpleHaving = parseHaving(`
  SELECT customer_id, SUM(amount) AS total_amount
  FROM sales
  GROUP BY customer_id
  HAVING SUM(amount) > 100
`);

assert.equal(simpleHaving.clause_type, "HAVING");
assert.equal(simpleHaving.expression.node_type, "COMPARISON_EXPRESSION");
assert.equal(simpleHaving.expression.operator, ">");
assert.equal(
  simpleHaving.expression.left.node_type,
  "FUNCTION_CALL_EXPRESSION"
);
assert.equal(simpleHaving.expression.left.function_name, "SUM");
assert.equal(simpleHaving.expression.right.value, "100");

/*
 * テスト内容
 * ----------
 * 複数の集約条件をANDで結び、COUNT(*)のワイルドカードも解析できることを
 * 確認する。
 */
const aggregateHaving = parseHaving(`
  SELECT customer_id, SUM(amount)
  FROM sales
  GROUP BY customer_id
  HAVING SUM(amount) >= 100
     AND COUNT(*) >= 2
`);

assert.equal(aggregateHaving.expression.node_type, "LOGICAL_EXPRESSION");
assert.equal(aggregateHaving.expression.operator, "AND");
assert.equal(
  aggregateHaving.expression.right.left.node_type,
  "FUNCTION_CALL_EXPRESSION"
);
assert.equal(aggregateHaving.expression.right.left.function_name, "COUNT");
assert.equal(
  aggregateHaving.expression.right.left.arguments[0].node_type,
  "WILDCARD_EXPRESSION"
);

/*
 * テスト内容
 * ----------
 * 関数呼び出しの内部に算術式がある場合も、ExpressionParserが優先順位を
 * 保持したASTを作成できることを確認する。
 */
const arithmeticHaving = parseHaving(`
  SELECT customer_id, SUM(amount), SUM(tax)
  FROM sales
  GROUP BY customer_id
  HAVING SUM(amount) + SUM(tax) > 1000
`);

assert.equal(arithmeticHaving.expression.operator, ">");
assert.equal(
  arithmeticHaving.expression.left.node_type,
  "ARITHMETIC_EXPRESSION"
);
assert.equal(arithmeticHaving.expression.left.operator, "+");

/*
 * テスト内容
 * ----------
 * HAVING本文中のCOMMENT TokenをExpressionParserが無視できることを確認する。
 */
const commentHaving = parseHaving(`
  SELECT customer_id, SUM(amount)
  FROM sales
  GROUP BY customer_id
  HAVING
    -- 一定額を超える顧客だけを残す
    SUM(amount) BETWEEN 100 AND 500
`);

assert.equal(commentHaving.expression.node_type, "BETWEEN_EXPRESSION");
assert.equal(commentHaving.expression.lower_bound.value, "100");
assert.equal(commentHaving.expression.upper_bound.value, "500");

/*
 * テスト内容
 * ----------
 * 後続QUALIFYがHAVING本文に混入しないことを確認する。
 * ClauseParserが返すbody_end_seqを利用することで、HavingParserは
 * HAVING条件だけをExpressionParserへ渡す。
 */
const qualifyBoundaryHaving = parseHaving(`
  SELECT customer_id, SUM(amount) AS total_amount
  FROM sales
  GROUP BY customer_id
  HAVING SUM(amount) > 100
  QUALIFY ROW_NUMBER() OVER (PARTITION BY customer_id) = 1
`);

assert.equal(qualifyBoundaryHaving.expression.operator, ">");
assert.equal(
  qualifyBoundaryHaving.expression.left.function_name,
  "SUM"
);

/*
 * テスト内容
 * ----------
 * 後続ORDER BYがHAVING本文に混入しないことを確認する。
 */
const orderBoundaryHaving = parseHaving(`
  SELECT customer_id, SUM(amount) AS total_amount
  FROM sales
  GROUP BY customer_id
  HAVING SUM(amount) > 100
  ORDER BY total_amount DESC
`);

assert.equal(orderBoundaryHaving.expression.operator, ">");

/*
 * 不正なClause種別を渡した場合、入口の検証でTypeErrorになることを確認する。
 */
const invalidTokens = tokenize("SELECT 1 WHERE 1 = 1");
const whereClause = new ClauseParser(invalidTokens)
  .parse()
  .find((clause) => clause.clause_type === "WHERE");

assert.throws(
  () => new HavingParser(invalidTokens).parse(whereClause),
  TypeError
);

console.log("HavingParser tests passed.");
