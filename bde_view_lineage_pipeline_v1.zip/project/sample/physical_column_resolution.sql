WITH summary AS (
  SELECT
    customer_id,
    SUM(amount) AS total_amount
  FROM project.dataset.sales
  GROUP BY customer_id
)
SELECT
  s.customer_id,
  s.total_amount
FROM summary AS s;
