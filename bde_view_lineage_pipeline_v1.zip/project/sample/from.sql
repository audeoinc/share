SELECT
  s.customer_id,
  item.product_id,
  c.customer_name
FROM project.dataset.sales AS s
LEFT JOIN project.dataset.customer AS c
  ON s.customer_id = c.customer_id
 AND c.deleted_at IS NULL
CROSS JOIN UNNEST(s.items) AS item;
