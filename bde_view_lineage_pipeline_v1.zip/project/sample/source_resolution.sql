WITH customer_summary AS (
  SELECT
    customer_id,
    SUM(amount) AS total_amount
  FROM project.dataset.sales
  GROUP BY customer_id
)
SELECT
  c.customer_id,
  c.total_amount,
  item.product_id
FROM customer_summary AS c
LEFT JOIN project.dataset.orders AS o
  ON c.customer_id = o.customer_id
CROSS JOIN UNNEST(o.items) AS item;
