SELECT
  customer_id,
  amount
FROM sales
ORDER BY amount DESC
LIMIT (50 + 50)
OFFSET 20;
