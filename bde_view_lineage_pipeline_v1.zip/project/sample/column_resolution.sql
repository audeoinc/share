WITH customer_summary AS (
  SELECT
    customer_id,
    SUM(amount) AS total_amount
  FROM project.dataset.sales
  GROUP BY customer_id
)
SELECT
  c.customer_id,
  c.total_amount,
  s.amount
FROM customer_summary AS c
JOIN project.dataset.sales AS s
  ON c.customer_id = s.customer_id
WHERE s.amount > 100;
