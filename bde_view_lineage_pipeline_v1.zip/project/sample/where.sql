SELECT
  customer_id,
  amount
FROM project.dataset.sales
WHERE
  amount BETWEEN 100 AND 500
  AND status NOT IN ('CANCELLED', 'DELETED')
  AND old_value IS DISTINCT FROM new_value;
