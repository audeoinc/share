SELECT
  region,
  category,
  SUM(amount) AS total_amount
FROM sales
GROUP BY GROUPING SETS (
  (region, category),
  (region),
  ()
)
HAVING SUM(amount) > 100;
