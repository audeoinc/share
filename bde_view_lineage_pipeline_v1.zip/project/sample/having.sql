SELECT
  customer_id,
  SUM(amount) AS total_amount,
  COUNT(*) AS order_count
FROM sales
GROUP BY customer_id
HAVING
  SUM(amount) BETWEEN 100 AND 500
  AND COUNT(*) >= 2
QUALIFY ROW_NUMBER() OVER (
  PARTITION BY customer_id
  ORDER BY total_amount DESC
) = 1;
