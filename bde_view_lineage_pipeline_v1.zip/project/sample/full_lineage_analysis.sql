WITH summary AS (
  SELECT
    customer_id,
    SUM(amount) AS total_amount
  FROM project.dataset.sales
  GROUP BY customer_id
), taxed AS (
  SELECT
    customer_id,
    total_amount * 1.1 AS total_with_tax
  FROM summary
)
SELECT
  customer_id,
  total_with_tax
FROM taxed;
