SELECT
  customer_id,
  amount,
  created_at,
  updated_at
FROM sales
ORDER BY
  IF(amount > 0, created_at, updated_at) DESC NULLS LAST,
  customer_id ASC
LIMIT 100;
