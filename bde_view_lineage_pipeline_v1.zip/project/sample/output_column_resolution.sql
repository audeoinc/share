WITH customer_summary(customer_id, total_amount) AS (
  SELECT
    s.customer_id,
    SUM(s.amount) AS source_total
  FROM project.dataset.sales AS s
  GROUP BY s.customer_id
)
SELECT
  c.customer_id,
  c.total_amount,
  c.total_amount * 1.1 AS total_with_tax
FROM customer_summary AS c;
