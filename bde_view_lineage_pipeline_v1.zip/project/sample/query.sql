WITH
  active_sales AS (
    SELECT customer_id, amount, created_at
    FROM project.dataset.sales
    WHERE status = 'ACTIVE'
  ),
  customer_totals AS (
    SELECT customer_id, SUM(amount) AS total_amount
    FROM active_sales
    GROUP BY customer_id
  )
SELECT
  customer_id,
  total_amount
FROM customer_totals
WHERE total_amount >= 100
ORDER BY total_amount DESC
LIMIT 100;
