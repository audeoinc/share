SELECT
  customer_id,
  category,
  amount,
  created_at
FROM sales
QUALIFY
  ROW_NUMBER() OVER (
    PARTITION BY customer_id, category
    ORDER BY created_at DESC NULLS LAST
  ) = 1;
