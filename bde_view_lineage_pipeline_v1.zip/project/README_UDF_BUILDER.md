# BigQuery UDF Builder v1

Node.jsでテスト済みの`src/*.js`を、BigQuery JavaScript UDF用の単一bundleへ変換します。

## 生成

```bash
node build_udf.js
```

生成物:

```text
build/lineage_udf_bundle.js
build/create_temp_lineage_udf.sql
build/bundle_manifest.json
```

## テスト

```bash
node test/test_udf_builder.js
```

## UDFの引数

- `sql_text`: 解析対象SQL
- `physical_columns_json`: 物理カラムメタデータのJSON配列
- `options_json`: `strict_mode`、`impact_target`など
- `export_metadata_json`: BigQueryExporter用メタデータ。NULLなら生のEngine結果を返す

戻り値はJSON文字列です。AST拡張時にBigQueryのRETURNS STRUCTを変更しなくて済むよう、最初のUDF版ではJSONを採用しています。
