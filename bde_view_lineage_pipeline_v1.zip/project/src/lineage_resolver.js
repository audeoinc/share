"use strict";

/**
 * Queryの出力列から、最終的な物理テーブル・物理カラムまで依存関係を辿る。
 *
 * LineageResolverの責務:
 *
 * - OutputColumnResolverが作成した出力列と、そのSELECT式内のColumn参照を結び付ける。
 * - 物理カラム参照はLineageの終点として登録する。
 * - CTE / FROMサブクエリの参照は、対象Query Scopeの出力列へ移動して再帰展開する。
 * - 複数段CTEでも、最終的な物理カラムへ到達するまで経路を保持する。
 * - 循環参照、未解決参照、曖昧参照を診断情報として残す。
 *
 * このResolverはSQLを再解析しない。
 * Parserと前段Resolverが作成した情報を結び付けることだけに集中する。
 */
class LineageResolver {
  constructor() {
    this.scopeById = new Map();
    this.sourceById = new Map();
    this.outputColumnsByScopeId = new Map();
    this.physicalReferenceByColumnReferenceId = new Map();
    this.referencesByOutputKey = new Map();
    this.nextLineageId = 1;
    this.context = null;
  }

  /**
   * ResolutionContextへ登録済みの結果を利用して、出力列Lineageを作成する。
   */
  resolve(context) {
    this.#validateContext(context);

    this.context = context;
    this.nextLineageId = 1;
    this.#buildIndexes(context);

    const outputLineages = [];

    for (const outputColumn of context.output_column_resolution.output_columns) {
      outputLineages.push(this.#resolveOutputColumn(outputColumn, [], new Set()));
    }

    const rootOutputLineages = outputLineages.filter((lineage) => {
      return lineage.output_scope_id === context.source_resolution.root_scope_id;
    });

    const result = {
      node_type: "LINEAGE_RESOLUTION",
      root_scope_id: context.source_resolution.root_scope_id,
      output_lineages: outputLineages,
      root_output_lineages: rootOutputLineages,
      physical_dependencies: this.#flattenPhysicalDependencies(rootOutputLineages)
    };

    context.setLineageResolution(result);
    this.#addDiagnostics(result, context);

    return result;
  }

  #buildIndexes(context) {
    this.scopeById = new Map();
    this.sourceById = new Map();
    this.outputColumnsByScopeId = new Map();
    this.physicalReferenceByColumnReferenceId = new Map();
    this.referencesByOutputKey = new Map();

    for (const scope of context.source_resolution.scopes) {
      this.scopeById.set(scope.scope_id, scope);

      for (const source of scope.sources) {
        this.sourceById.set(source.source_id, source);
      }
    }

    for (const scope of context.output_column_resolution.scopes) {
      this.outputColumnsByScopeId.set(scope.scope_id, scope.output_columns);
    }

    for (const physicalReference of context.physical_column_resolution.column_references) {
      this.physicalReferenceByColumnReferenceId.set(
        physicalReference.column_reference_id,
        physicalReference
      );
    }

    /*
     * SELECT項目ごとにColumn参照をまとめる。
     * OutputColumnのoutput_column_seqとColumnResolverのselect_item_seqが対応する。
     */
    for (const reference of context.column_resolution.column_references) {
      if (reference.clause_type !== "SELECT" || reference.select_item_seq === null) {
        continue;
      }

      const key = this.#createOutputKey(reference.scope_id, reference.select_item_seq);

      if (!this.referencesByOutputKey.has(key)) {
        this.referencesByOutputKey.set(key, []);
      }

      this.referencesByOutputKey.get(key).push(reference);
    }
  }

  #resolveOutputColumn(outputColumn, parentPath, visitingOutputIds) {
    const pathEntry = this.#createOutputPathEntry(outputColumn);
    const lineagePath = [...parentPath, pathEntry];

    if (visitingOutputIds.has(outputColumn.output_column_id)) {
      return {
        lineage_id: this.nextLineageId++,
        output_column_id: outputColumn.output_column_id,
        output_scope_id: outputColumn.scope_id,
        output_column_name: outputColumn.output_column_name,
        lineage_status: "CYCLE_DETECTED",
        dependencies: [],
        lineage_path: lineagePath
      };
    }

    const nextVisiting = new Set(visitingOutputIds);
    nextVisiting.add(outputColumn.output_column_id);

    if (outputColumn.output_status === "WILDCARD_PENDING") {
      return this.#resolveWildcardOutput(outputColumn, lineagePath);
    }

    const key = this.#createOutputKey(
      outputColumn.scope_id,
      outputColumn.output_column_seq
    );
    const references = this.referencesByOutputKey.get(key) || [];
    const dependencies = [];

    for (const reference of references) {
      dependencies.push(
        ...this.#resolveReference(reference, lineagePath, nextVisiting)
      );
    }

    const uniqueDependencies = this.#deduplicateDependencies(dependencies);

    return {
      lineage_id: this.nextLineageId++,
      output_column_id: outputColumn.output_column_id,
      output_scope_id: outputColumn.scope_id,
      output_column_seq: outputColumn.output_column_seq,
      output_column_name: outputColumn.output_column_name,
      expression_text: outputColumn.expression_text,
      lineage_status: this.#determineLineageStatus(references, uniqueDependencies),
      dependencies: uniqueDependencies,
      lineage_path: lineagePath,
      start_token_seq: outputColumn.start_token_seq,
      end_token_seq: outputColumn.end_token_seq
    };
  }

  #resolveReference(reference, parentPath, visitingOutputIds) {
    const physicalReference = this.physicalReferenceByColumnReferenceId.get(
      reference.column_reference_id
    );

    if (!physicalReference) {
      return [this.#createUnresolvedDependency(reference, parentPath, "PHYSICAL_REFERENCE_MISSING")];
    }

    if (physicalReference.physical_resolution_status === "PHYSICAL_RESOLVED") {
      return physicalReference.physical_columns.map((column) => {
        return {
          dependency_type: "PHYSICAL_COLUMN",
          dependency_status: "RESOLVED",
          physical_table_name: column.physical_table_name,
          physical_column_name: column.physical_column_name,
          field_path: column.field_path,
          source_reference_name: reference.reference_name,
          lineage_path: [
            ...parentPath,
            `${column.physical_table_name}.${column.field_path || column.physical_column_name}`
          ]
        };
      });
    }

    const derivedScopeId = this.#findDerivedSourceScope(reference, physicalReference);

    if (derivedScopeId !== null) {
      const targetOutput = this.#findOutputColumn(
        derivedScopeId,
        reference.column_name
      );

      if (!targetOutput) {
        return [this.#createUnresolvedDependency(
          reference,
          parentPath,
          "DERIVED_OUTPUT_COLUMN_NOT_FOUND"
        )];
      }

      const nestedLineage = this.#resolveOutputColumn(
        targetOutput,
        parentPath,
        visitingOutputIds
      );

      if (nestedLineage.lineage_status === "CYCLE_DETECTED") {
        return [{
          dependency_type: "DERIVED_COLUMN",
          dependency_status: "CYCLE_DETECTED",
          source_reference_name: reference.reference_name,
          derived_scope_id: derivedScopeId,
          derived_output_column_name: targetOutput.output_column_name,
          lineage_path: nestedLineage.lineage_path
        }];
      }

      return nestedLineage.dependencies.map((dependency) => {
        return {
          ...dependency,
          dependency_type: dependency.dependency_type === "PHYSICAL_COLUMN"
            ? "PHYSICAL_COLUMN"
            : dependency.dependency_type,
          via_derived_scope_id: derivedScopeId,
          via_derived_output_column_name: targetOutput.output_column_name
        };
      });
    }

    return [this.#createUnresolvedDependency(
      reference,
      parentPath,
      physicalReference.physical_resolution_status
    )];
  }

  /**
   * CTE / サブクエリ参照が指すQuery Scopeを返す。
   *
   * 既存SourceResolverでは、CTE本文から先に定義された兄弟CTEを参照した場合、
   * 物理テーブル候補として保持されることがある。そのためsource_typeだけでなく、
   * 親ScopeのCTE定義も検索して補正する。
   */
  #findDerivedSourceScope(reference, physicalReference) {
    const source = this.sourceById.get(physicalReference.source_id || reference.source_id);

    if (!source) {
      return null;
    }

    if (source.source_type === "CTE" && source.cte_query_scope_id !== null) {
      return source.cte_query_scope_id;
    }

    if (source.source_type === "SUBQUERY" && source.subquery_scope_id !== null) {
      return source.subquery_scope_id;
    }

    const cteDefinition = this.#findVisibleCteDefinition(
      source.scope_id,
      source.source_name
    );

    return cteDefinition ? cteDefinition.query_scope_id : null;
  }

  #findVisibleCteDefinition(scopeId, sourceName) {
    const normalizedSourceName = this.#normalizeName(sourceName);
    let currentScope = this.scopeById.get(scopeId);

    while (currentScope) {
      const definition = currentScope.cte_definitions.find((cte) => {
        return cte.cte_name === normalizedSourceName;
      });

      if (definition) {
        return definition;
      }

      currentScope = currentScope.parent_scope_id === null
        ? null
        : this.scopeById.get(currentScope.parent_scope_id);
    }

    return null;
  }

  #findOutputColumn(scopeId, columnName) {
    const outputColumns = this.outputColumnsByScopeId.get(scopeId) || [];
    const normalizedColumnName = this.#normalizeName(columnName);

    return outputColumns.find((outputColumn) => {
      return this.#normalizeName(outputColumn.output_column_name) === normalizedColumnName;
    }) || null;
  }

  #resolveWildcardOutput(outputColumn, parentPath) {
    const expansions = this.context.physical_column_resolution.wildcard_expansions.filter(
      (item) => item.scope_id === outputColumn.scope_id &&
        item.output_column_seq === outputColumn.output_column_seq
    );

    const dependencies = expansions.map((item) => {
      return {
        dependency_type: "PHYSICAL_COLUMN",
        dependency_status: "RESOLVED",
        physical_table_name: item.physical_table_name,
        physical_column_name: item.physical_column_name,
        field_path: item.field_path,
        source_reference_name: outputColumn.wildcard_qualifier || "*",
        lineage_path: [
          ...parentPath,
          `${item.physical_table_name}.${item.field_path || item.physical_column_name}`
        ]
      };
    });

    return {
      lineage_id: this.nextLineageId++,
      output_column_id: outputColumn.output_column_id,
      output_scope_id: outputColumn.scope_id,
      output_column_seq: outputColumn.output_column_seq,
      output_column_name: outputColumn.output_column_name,
      expression_text: outputColumn.expression_text,
      lineage_status: dependencies.length > 0 ? "RESOLVED" : "UNRESOLVED",
      dependencies,
      lineage_path: parentPath,
      start_token_seq: outputColumn.start_token_seq,
      end_token_seq: outputColumn.end_token_seq
    };
  }

  #createUnresolvedDependency(reference, parentPath, status) {
    return {
      dependency_type: "UNRESOLVED_COLUMN",
      dependency_status: status,
      source_reference_name: reference.reference_name,
      scope_id: reference.scope_id,
      column_name: reference.column_name,
      lineage_path: [...parentPath, `UNRESOLVED:${reference.reference_name}`]
    };
  }

  #determineLineageStatus(references, dependencies) {
    if (references.length === 0) {
      return "NO_COLUMN_DEPENDENCY";
    }

    if (dependencies.length === 0) {
      return "UNRESOLVED";
    }

    if (dependencies.some((dependency) => dependency.dependency_status !== "RESOLVED")) {
      return "PARTIALLY_RESOLVED";
    }

    return "RESOLVED";
  }

  #deduplicateDependencies(dependencies) {
    const result = [];
    const seen = new Set();

    for (const dependency of dependencies) {
      const key = dependency.dependency_type === "PHYSICAL_COLUMN"
        ? `${dependency.physical_table_name}|${dependency.field_path || dependency.physical_column_name}`
        : `${dependency.dependency_type}|${dependency.dependency_status}|${dependency.source_reference_name}`;

      if (seen.has(key)) {
        continue;
      }

      seen.add(key);
      result.push(dependency);
    }

    return result;
  }

  #flattenPhysicalDependencies(rootOutputLineages) {
    const rows = [];

    for (const lineage of rootOutputLineages) {
      for (const dependency of lineage.dependencies) {
        if (dependency.dependency_type !== "PHYSICAL_COLUMN") {
          continue;
        }

        rows.push({
          output_column_id: lineage.output_column_id,
          output_column_name: lineage.output_column_name,
          output_scope_id: lineage.output_scope_id,
          physical_table_name: dependency.physical_table_name,
          physical_column_name: dependency.physical_column_name,
          field_path: dependency.field_path,
          lineage_path: dependency.lineage_path
        });
      }
    }

    return rows;
  }

  #addDiagnostics(result, context) {
    for (const lineage of result.output_lineages) {
      if (lineage.lineage_status === "RESOLVED" ||
          lineage.lineage_status === "NO_COLUMN_DEPENDENCY") {
        continue;
      }

      context.addDiagnostic(
        lineage.lineage_status === "CYCLE_DETECTED" ? "ERROR" : "WARNING",
        `LINEAGE_${lineage.lineage_status}`,
        `Lineage for output column ${lineage.output_column_name || "<unnamed>"} ` +
        `in scope ${lineage.output_scope_id} is ${lineage.lineage_status}.`,
        {
          output_column_id: lineage.output_column_id,
          scope_id: lineage.output_scope_id
        }
      );
    }
  }

  #createOutputPathEntry(outputColumn) {
    return `SCOPE_${outputColumn.scope_id}.${outputColumn.output_column_name || "<UNNAMED>"}`;
  }

  #createOutputKey(scopeId, outputColumnSeq) {
    return `${scopeId}:${outputColumnSeq}`;
  }

  #normalizeName(value) {
    return value === null || value === undefined
      ? null
      : String(value).toUpperCase();
  }

  #validateContext(context) {
    if (!context || context.query_ast?.node_type !== "QUERY") {
      throw new TypeError("LineageResolver.resolve: invalid ResolutionContext.");
    }

    const requiredResults = [
      ["source_resolution", "SOURCE_RESOLUTION"],
      ["column_resolution", "COLUMN_RESOLUTION"],
      ["output_column_resolution", "OUTPUT_COLUMN_RESOLUTION"],
      ["physical_column_resolution", "PHYSICAL_COLUMN_RESOLUTION"]
    ];

    for (const [propertyName, nodeType] of requiredResults) {
      if (context[propertyName]?.node_type !== nodeType) {
        throw new TypeError(
          `LineageResolver.resolve: ${propertyName} must be registered first.`
        );
      }
    }
  }
}

module.exports = {
  LineageResolver
};
