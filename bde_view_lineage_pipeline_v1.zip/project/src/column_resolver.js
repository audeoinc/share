"use strict";

const { ExpressionParser } = require("./expression_parser");

/**
 * Query AST内のIDENTIFIER_EXPRESSIONをSourceResolverのscopeへ結び付ける。
 *
 * ColumnResolverの責務:
 *
 * - SELECT、JOIN ON、WHERE、GROUP BY、HAVING、QUALIFY、ORDER BYなどから
 *   カラム参照を収集する。
 * - `s.amount`のような修飾参照では、修飾子`s`をSourceResolverで解決する。
 * - `amount`のような非修飾参照では、現在scope内の候補Sourceを列挙する。
 * - CTEとFROMサブクエリについては、SELECT出力名を利用して列名を検証する。
 * - 物理テーブルはスキーマ情報がまだ無いため、Sourceまでは解決するが、
 *   実カラムの存在確認は後続のPhysicalColumnResolverへ委譲する。
 *
 * このクラスはSQL文字列を再解析しない。
 * SelectParserがまだ式ASTを保持していない箇所だけ、token_seq範囲から
 * ExpressionParserを呼び、既存のParserロジックを再利用する。
 */
class ColumnResolver {
  constructor(tokens) {
    if (!Array.isArray(tokens)) {
      throw new TypeError("ColumnResolver: tokens must be an array.");
    }

    this.tokens = tokens;
    this.nextReferenceId = 1;
    this.queryByScopeId = new Map();
    this.scopeById = new Map();
  }

  /**
   * Query ASTとSourceResolver結果から、カラム参照一覧を作る公開入口。
   *
   * @param {object} queryAst QueryParserが生成したROOT Query AST
   * @param {object} sourceResolution SourceResolver.resolve()の戻り値
   * @returns {object}
   */
  resolve(queryAst, sourceResolution) {
    this.#validateInputs(queryAst, sourceResolution);

    this.nextReferenceId = 1;
    this.queryByScopeId = new Map();
    this.scopeById = new Map(
      sourceResolution.scopes.map((scope) => [scope.scope_id, scope])
    );

    this.#mapQueriesToScopes(queryAst, sourceResolution);

    const columnReferences = [];

    for (const scope of sourceResolution.scopes) {
      const scopedQuery = this.queryByScopeId.get(scope.scope_id);

      if (!scopedQuery) {
        continue;
      }

      this.#collectQueryReferences(
        scopedQuery,
        scope,
        sourceResolution,
        columnReferences
      );
    }

    return {
      node_type: "COLUMN_RESOLUTION",
      root_scope_id: sourceResolution.root_scope_id,
      column_references: columnReferences
    };
  }

  /**
   * Query ASTとSourceResolver scopeをtoken範囲で対応付ける。
   *
   * SourceResolverは各scopeにquery_start_token_seq / query_end_token_seqを
   * 保持しているため、Query ASTの同じ範囲と一意に対応できる。
   */
  #mapQueriesToScopes(rootQueryAst, sourceResolution) {
    const queries = [];

    this.#collectQueryAsts(rootQueryAst, queries);

    for (const scope of sourceResolution.scopes) {
      const queryAst = queries.find((query) => {
        return query.start_token_seq === scope.query_start_token_seq &&
          query.end_token_seq === scope.query_end_token_seq;
      });

      if (queryAst) {
        this.queryByScopeId.set(scope.scope_id, queryAst);
      }
    }
  }

  #collectQueryAsts(queryAst, result) {
    result.push(queryAst);

    const ctes = Array.isArray(queryAst.common_table_expressions)
      ? queryAst.common_table_expressions
      : [];

    for (const cte of ctes) {
      if (cte.query?.node_type === "QUERY") {
        this.#collectQueryAsts(cte.query, result);
      }
    }

    const fromSources = [];

    if (queryAst.from?.source) {
      fromSources.push(queryAst.from.source);
    }

    for (const join of queryAst.from?.joins || []) {
      fromSources.push(join.source);
    }

    for (const source of fromSources) {
      if (source.query_ast?.node_type === "QUERY") {
        this.#collectQueryAsts(source.query_ast, result);
      }
    }
  }

  /**
   * 1つのQuery scopeから、ClauseごとのExpressionを収集する。
   */
  #collectQueryReferences(queryAst, scope, sourceResolution, result) {
    for (const selectItem of queryAst.select || []) {
      if (selectItem.wildcard_type) {
        this.#collectWildcardReference(selectItem, scope, sourceResolution, result);
        continue;
      }

      const expressionAst = this.#parseExpressionRange(
        selectItem.expression_start_seq,
        selectItem.expression_end_seq
      );

      this.#collectFromAst(expressionAst, {
        clause_type: "SELECT",
        select_item_seq: selectItem.select_item_seq
      }, scope, sourceResolution, result);
    }

    for (const join of queryAst.from?.joins || []) {
      if (join.condition) {
        this.#collectFromAst(join.condition, {
          clause_type: "JOIN_ON",
          join_seq: join.join_seq
        }, scope, sourceResolution, result);
      }
    }

    if (queryAst.where?.expression) {
      this.#collectFromAst(queryAst.where.expression, {
        clause_type: "WHERE"
      }, scope, sourceResolution, result);
    }

    for (const item of queryAst.group_by?.items || []) {
      if (item.expression) {
        this.#collectFromAst(item.expression, {
          clause_type: "GROUP_BY",
          group_item_seq: item.group_item_seq
        }, scope, sourceResolution, result);
      }
    }

    if (queryAst.having?.expression) {
      this.#collectFromAst(queryAst.having.expression, {
        clause_type: "HAVING"
      }, scope, sourceResolution, result);
    }

    if (queryAst.qualify?.expression) {
      this.#collectFromAst(queryAst.qualify.expression, {
        clause_type: "QUALIFY"
      }, scope, sourceResolution, result);
    }

    for (const item of queryAst.order_by?.items || []) {
      if (item.expression) {
        this.#collectFromAst(item.expression, {
          clause_type: "ORDER_BY",
          order_item_seq: item.order_item_seq
        }, scope, sourceResolution, result);
      }
    }

    for (const source of scope.sources) {
      if (source.source_type === "UNNEST" && source.expression) {
        this.#collectFromAst(source.expression, {
          clause_type: source.source_role === "JOIN" ? "JOIN_UNNEST" : "FROM_UNNEST"
        }, scope, sourceResolution, result);
      }
    }
  }

  /**
   * ASTを再帰的に走査し、IDENTIFIER_EXPRESSIONだけを解決する。
   *
   * AST Nodeの形はNodeTypeごとに異なるため、特定プロパティ名を列挙せず、
   * object / arrayを汎用的に辿る。node_typeを持つIDENTIFIER Nodeを見つけたら、
   * そのNodeより下へは進まず、1参照として登録する。
   */
  #collectFromAst(node, context, scope, sourceResolution, result) {
    if (!node || typeof node !== "object") {
      return;
    }

    if (Array.isArray(node)) {
      for (const item of node) {
        this.#collectFromAst(item, context, scope, sourceResolution, result);
      }

      return;
    }

    if (node.node_type === "IDENTIFIER_EXPRESSION") {
      result.push(
        this.#resolveIdentifierNode(node, context, scope, sourceResolution)
      );
      return;
    }

    for (const value of Object.values(node)) {
      if (value && typeof value === "object") {
        this.#collectFromAst(value, context, scope, sourceResolution, result);
      }
    }
  }

  #resolveIdentifierNode(node, context, scope, sourceResolution) {
    const parts = Array.isArray(node.parts)
      ? node.parts.map((part) => this.#normalizeName(part))
      : String(node.name || "").split(".").map((part) => this.#normalizeName(part));

    const columnName = parts[parts.length - 1];
    const qualifierParts = parts.slice(0, -1);

    if (qualifierParts.length > 0) {
      return this.#resolveQualifiedReference(
        node,
        context,
        scope,
        sourceResolution,
        qualifierParts,
        columnName
      );
    }

    return this.#resolveUnqualifiedReference(
      node,
      context,
      scope,
      sourceResolution,
      columnName
    );
  }

  #resolveQualifiedReference(
    node,
    context,
    scope,
    sourceResolution,
    qualifierParts,
    columnName
  ) {
    const qualifier = qualifierParts.join(".");
    const source = this.#findSource(sourceResolution, scope.scope_id, qualifier);

    if (!source) {
      return this.#createReferenceResult(node, context, scope, {
        qualifier,
        columnName,
        status: "UNRESOLVED_SOURCE",
        source: null,
        candidateSourceIds: []
      });
    }

    const columnStatus = this.#getColumnStatus(source, columnName);

    return this.#createReferenceResult(node, context, scope, {
      qualifier,
      columnName,
      status: columnStatus,
      source,
      candidateSourceIds: [source.source_id]
    });
  }

  #resolveUnqualifiedReference(node, context, scope, sourceResolution, columnName) {
    const candidateSources = this.#findUnqualifiedCandidates(
      sourceResolution,
      scope.scope_id,
      columnName
    );

    if (candidateSources.length === 0) {
      return this.#createReferenceResult(node, context, scope, {
        qualifier: null,
        columnName,
        status: "UNRESOLVED_COLUMN",
        source: null,
        candidateSourceIds: []
      });
    }

    if (candidateSources.length > 1) {
      return this.#createReferenceResult(node, context, scope, {
        qualifier: null,
        columnName,
        status: "AMBIGUOUS",
        source: null,
        candidateSourceIds: candidateSources.map((source) => source.source_id)
      });
    }

    const source = candidateSources[0];
    const columnStatus = this.#getColumnStatus(source, columnName);

    return this.#createReferenceResult(node, context, scope, {
      qualifier: null,
      columnName,
      status: columnStatus,
      source,
      candidateSourceIds: [source.source_id]
    });
  }

  /**
   * 非修飾列の候補を現在scopeから探す。
   *
   * CTE / SUBQUERYは出力列名が既知なので、該当列を持つ場合だけ候補にする。
   * PHYSICAL_TABLE / UNNESTは現段階でスキーマ不明のため、候補から除外できない。
   * 現在scopeに候補が無い場合だけ親scopeへ進み、相関参照の土台とする。
   */
  #findUnqualifiedCandidates(sourceResolution, startScopeId, columnName) {
    let currentScope = this.scopeById.get(startScopeId);

    while (currentScope) {
      const candidates = currentScope.sources.filter((source) => {
        const knownColumns = this.#getKnownOutputColumns(source);

        if (knownColumns === null) {
          return true;
        }

        return knownColumns.includes(columnName);
      });

      if (candidates.length > 0) {
        return candidates;
      }

      currentScope = this.scopeById.get(currentScope.parent_scope_id);
    }

    return [];
  }

  #getColumnStatus(source, columnName) {
    const knownColumns = this.#getKnownOutputColumns(source);

    if (knownColumns === null) {
      return "SOURCE_RESOLVED";
    }

    return knownColumns.includes(columnName)
      ? "RESOLVED"
      : "UNRESOLVED_COLUMN";
  }

  /**
   * CTE / SUBQUERYのSELECT出力名を返す。
   * 物理テーブルとUNNESTはメタデータ未連携なのでnullを返す。
   */
  #getKnownOutputColumns(source) {
    const childScopeId = source.cte_query_scope_id || source.subquery_scope_id;

    if (!childScopeId) {
      return null;
    }

    const queryAst = this.queryByScopeId.get(childScopeId);

    if (!queryAst) {
      return [];
    }

    return (queryAst.select || [])
      .map((item) => this.#normalizeName(item.output_alias))
      .filter((name) => name !== null);
  }

  #findSource(sourceResolution, startScopeId, referenceName) {
    const normalizedName = this.#normalizeName(referenceName);
    let currentScope = this.scopeById.get(startScopeId);

    while (currentScope) {
      const sourceId = currentScope.reference_map[normalizedName];

      if (sourceId !== undefined) {
        return currentScope.sources.find((source) => source.source_id === sourceId) || null;
      }

      currentScope = this.scopeById.get(currentScope.parent_scope_id);
    }

    return null;
  }

  #collectWildcardReference(selectItem, scope, sourceResolution, result) {
    if (selectItem.wildcard_type === "ALL") {
      result.push({
        column_reference_id: this.nextReferenceId++,
        scope_id: scope.scope_id,
        clause_type: "SELECT",
        select_item_seq: selectItem.select_item_seq,
        reference_type: "WILDCARD",
        reference_name: "*",
        qualifier: null,
        column_name: "*",
        resolution_status: scope.sources.length === 1 ? "RESOLVED" : "AMBIGUOUS",
        source_id: scope.sources.length === 1 ? scope.sources[0].source_id : null,
        source_type: scope.sources.length === 1 ? scope.sources[0].source_type : null,
        source_name: scope.sources.length === 1 ? scope.sources[0].source_name : null,
        source_alias: scope.sources.length === 1 ? scope.sources[0].source_alias : null,
        candidate_source_ids: scope.sources.map((source) => source.source_id),
        start_token_seq: selectItem.expression_start_seq,
        end_token_seq: selectItem.expression_end_seq
      });
      return;
    }

    const qualifier = this.#normalizeName(selectItem.wildcard_qualifier);
    const source = this.#findSource(sourceResolution, scope.scope_id, qualifier);

    result.push({
      column_reference_id: this.nextReferenceId++,
      scope_id: scope.scope_id,
      clause_type: "SELECT",
      select_item_seq: selectItem.select_item_seq,
      reference_type: "WILDCARD",
      reference_name: `${qualifier}.*`,
      qualifier,
      column_name: "*",
      resolution_status: source ? "RESOLVED" : "UNRESOLVED_SOURCE",
      source_id: source?.source_id ?? null,
      source_type: source?.source_type ?? null,
      source_name: source?.source_name ?? null,
      source_alias: source?.source_alias ?? null,
      candidate_source_ids: source ? [source.source_id] : [],
      start_token_seq: selectItem.expression_start_seq,
      end_token_seq: selectItem.expression_end_seq
    });
  }

  #createReferenceResult(node, context, scope, details) {
    return {
      column_reference_id: this.nextReferenceId++,
      scope_id: scope.scope_id,
      clause_type: context.clause_type,
      select_item_seq: context.select_item_seq ?? null,
      join_seq: context.join_seq ?? null,
      group_item_seq: context.group_item_seq ?? null,
      order_item_seq: context.order_item_seq ?? null,
      reference_type: "COLUMN",
      reference_name: node.name,
      qualifier: details.qualifier,
      column_name: details.columnName,
      resolution_status: details.status,
      source_id: details.source?.source_id ?? null,
      source_type: details.source?.source_type ?? null,
      source_name: details.source?.source_name ?? null,
      source_alias: details.source?.source_alias ?? null,
      candidate_source_ids: details.candidateSourceIds,
      start_token_seq: node.start_token_seq,
      end_token_seq: node.end_token_seq
    };
  }

  #parseExpressionRange(startTokenSeq, endTokenSeq) {
    const expressionTokens = this.tokens.filter((token) => {
      return token.token_seq >= startTokenSeq &&
        token.token_seq <= endTokenSeq &&
        token.token_type !== "COMMENT";
    });

    if (expressionTokens.length === 0) {
      throw new SyntaxError(
        `ColumnResolver: expression token range ${startTokenSeq}-${endTokenSeq} is empty.`
      );
    }

    return new ExpressionParser(expressionTokens).parseExpression();
  }

  #normalizeName(value) {
    if (value === null || value === undefined) {
      return null;
    }

    return String(value).toUpperCase();
  }

  #validateInputs(queryAst, sourceResolution) {
    if (!queryAst || queryAst.node_type !== "QUERY") {
      throw new TypeError("ColumnResolver: queryAst must be a QUERY node.");
    }

    if (!sourceResolution || !Array.isArray(sourceResolution.scopes)) {
      throw new TypeError("ColumnResolver: sourceResolution is invalid.");
    }
  }
}

module.exports = {
  ColumnResolver
};
