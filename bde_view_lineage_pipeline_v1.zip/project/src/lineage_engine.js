"use strict";

const { tokenize } = require("./lexer");
const { QueryParser } = require("./query_parser");
const { SourceResolver } = require("./source_resolver");
const { ColumnResolver } = require("./column_resolver");
const { OutputColumnResolver } = require("./output_column_resolver");
const { PhysicalColumnResolver } = require("./physical_column_resolver");
const { LineageResolver } = require("./lineage_resolver");
const { ImpactResolver } = require("./impact_resolver");
const { ResolutionContext } = require("./resolution_context");

/**
 * SQL文字列から物理カラムLineageまでを一括実行する統合クラス。
 *
 * LineageEngineを用意する理由:
 *
 * - 利用側がParser / Resolverの正しい呼び出し順を意識しなくてよい。
 * - 各工程の結果をResolutionContextへ確実に登録できる。
 * - Node.js、BigQuery UDF、バッチ処理など、異なる実行環境から
 *   同じ公開APIを利用できる。
 * - strict / non-strictのエラー処理を一か所へ集約できる。
 * - BigQueryの中間テーブルへ保存しやすい平坦な行配列を生成できる。
 *
 * このクラス自身はSQL文法や名前解決を実装しない。
 * 各Parser / Resolverを決められた順序で呼ぶオーケストレーターである。
 */
class LineageEngine {
  /**
   * @param {object} options
   * @param {Array<object>} options.physicalColumns 物理カラムメタデータ
   * @param {boolean} options.strictMode trueならERROR診断または工程例外で停止する
   */
  constructor(options = {}) {
    const physicalColumns = options.physicalColumns ?? [];

    if (!Array.isArray(physicalColumns)) {
      throw new TypeError(
        "LineageEngine: options.physicalColumns must be an array."
      );
    }

    this.physicalColumns = physicalColumns;
    this.strictMode = options.strictMode !== false;
  }

  /**
   * SQLを解析し、Parser / Resolverの結果をまとめて返す公開入口。
   *
   * @param {string} sqlText
   * @param {object} options
   * @param {object|null} options.impactTarget ImpactResolverへ渡す物理対象
   * @returns {object}
   */
  analyze(sqlText, options = {}) {
    if (typeof sqlText !== "string") {
      throw new TypeError("LineageEngine.analyze: sqlText must be a string.");
    }

    const state = {
      tokens: [],
      queryAst: null,
      context: null,
      failedStage: null,
      caughtError: null
    };

    try {
      state.failedStage = "LEXER";
      state.tokens = tokenize(sqlText);

      state.failedStage = "QUERY_PARSER";
      state.queryAst = new QueryParser(state.tokens).parse();
      state.context = new ResolutionContext(state.tokens, state.queryAst);

      state.failedStage = "SOURCE_RESOLVER";
      const sourceResolution = new SourceResolver().resolve(state.queryAst);
      state.context.setSourceResolution(sourceResolution);

      state.failedStage = "COLUMN_RESOLVER";
      const columnResolution = new ColumnResolver(state.tokens).resolve(
        state.queryAst,
        sourceResolution
      );
      state.context.setColumnResolution(columnResolution);

      state.failedStage = "OUTPUT_COLUMN_RESOLVER";
      new OutputColumnResolver(state.tokens).resolve(state.context);

      state.failedStage = "PHYSICAL_COLUMN_RESOLVER";
      new PhysicalColumnResolver(this.physicalColumns).resolve(state.context);

      state.failedStage = "LINEAGE_RESOLVER";
      new LineageResolver().resolve(state.context);

      if (options.impactTarget) {
        state.failedStage = "IMPACT_RESOLVER";
        new ImpactResolver().resolve(state.context, options.impactTarget);
      }

      state.failedStage = null;
    } catch (error) {
      state.caughtError = error;

      if (this.strictMode) {
        throw this.#createStageError(state.failedStage, error);
      }

      this.#recordCaughtError(state);
    }

    if (this.strictMode && state.context) {
      this.#throwForErrorDiagnostics(state.context);
    }

    return this.#createResult(sqlText, state);
  }

  /**
   * strictMode=falseで工程例外が起きた場合、解析済みのContextがあれば
   * diagnosticsへ登録する。QueryParser以前の失敗ではContextを作れないため、
   * 後で返却結果のengine_diagnosticsへ格納する。
   */
  #recordCaughtError(state) {
    if (!state.context) {
      return;
    }

    state.context.addDiagnostic(
      "ERROR",
      "ENGINE_STAGE_FAILED",
      state.caughtError.message,
      {
        stage: state.failedStage,
        error_name: state.caughtError.name
      }
    );
  }

  /**
   * Resolverが結果を返しつつERROR診断を残した場合、strictModeでは例外化する。
   * SyntaxErrorだけでなく、CTE列数不一致などの意味的な不整合も
   * 呼び出し側が見落とさないようにする。
   */
  #throwForErrorDiagnostics(context) {
    const errors = context.diagnostics.filter((item) => item.severity === "ERROR");

    if (errors.length === 0) {
      return;
    }

    const error = new Error(
      `LineageEngine: ${errors.length} error diagnostic(s) were reported.`
    );

    error.name = "LineageEngineDiagnosticError";
    error.diagnostics = errors;
    throw error;
  }

  #createStageError(stage, originalError) {
    const error = new Error(
      `LineageEngine: stage ${stage ?? "UNKNOWN"} failed: ${originalError.message}`
    );

    error.name = "LineageEngineStageError";
    error.stage = stage;
    error.cause = originalError;
    return error;
  }

  #createResult(sqlText, state) {
    const contextObject = state.context ? state.context.toObject() : null;
    const engineDiagnostics = [];

    if (state.caughtError && !state.context) {
      engineDiagnostics.push({
        diagnostic_seq: 1,
        severity: "ERROR",
        code: "ENGINE_STAGE_FAILED",
        message: state.caughtError.message,
        stage: state.failedStage,
        error_name: state.caughtError.name
      });
    }

    const diagnostics = contextObject
      ? contextObject.diagnostics
      : engineDiagnostics;

    return {
      node_type: "LINEAGE_ENGINE_RESULT",
      analysis_status: this.#determineAnalysisStatus(state, diagnostics),
      strict_mode: this.strictMode,
      sql_text: sqlText,
      failed_stage: state.caughtError ? state.failedStage : null,
      tokens: state.tokens,
      query_ast: state.queryAst,
      resolutions: {
        sources: contextObject?.source_resolution ?? null,
        columns: contextObject?.column_resolution ?? null,
        output_columns: contextObject?.output_column_resolution ?? null,
        physical_columns: contextObject?.physical_column_resolution ?? null
      },
      lineage: contextObject?.lineage_resolution ?? null,
      impact: contextObject?.impact_resolution ?? null,
      diagnostics,
      tables: this.#createTableRows(state.context)
    };
  }

  #determineAnalysisStatus(state, diagnostics) {
    if (state.caughtError) {
      return "PARTIAL_FAILURE";
    }

    if (diagnostics.some((item) => item.severity === "ERROR")) {
      return "COMPLETED_WITH_ERRORS";
    }

    if (diagnostics.some((item) => item.severity === "WARNING")) {
      return "COMPLETED_WITH_WARNINGS";
    }

    return "COMPLETED";
  }

  /**
   * BigQueryの中間テーブルへ保存しやすい行配列を作る。
   *
   * JavaScriptメモ:
   * optional chaining（?.）とnull合体演算子（??）を使い、
   * non-strictモードで途中工程が未実行でも空配列を返せるようにしている。
   */
  #createTableRows(context) {
    if (!context) {
      return this.#createEmptyTables();
    }

    const sourceScopes = context.source_resolution?.scopes ?? [];
    const outputScopes = context.output_column_resolution?.scopes ?? [];

    return {
      tokens: context.tokens.map((token) => ({ ...token })),
      query_scopes: sourceScopes.map((scope) => ({
        scope_id: scope.scope_id,
        scope_type: scope.scope_type,
        parent_scope_id: scope.parent_scope_id,
        query_start_token_seq: scope.query_start_token_seq,
        query_end_token_seq: scope.query_end_token_seq
      })),
      sources: sourceScopes.flatMap((scope) => {
        return scope.sources.map((source) => ({ ...source }));
      }),
      cte_definitions: sourceScopes.flatMap((scope) => {
        return scope.cte_definitions.map((cte) => ({
          scope_id: scope.scope_id,
          ...cte
        }));
      }),
      column_references:
        context.column_resolution?.column_references.map((item) => ({ ...item })) ?? [],
      output_columns: outputScopes.flatMap((scope) => {
        return scope.output_columns.map((item) => ({ ...item }));
      }),
      physical_column_references:
        context.physical_column_resolution?.column_references.map((item) => ({ ...item })) ?? [],
      wildcard_expansions:
        context.physical_column_resolution?.wildcard_expansions.map((item) => ({ ...item })) ?? [],
      output_lineages:
        context.lineage_resolution?.output_lineages.map((item) => ({ ...item })) ?? [],
      lineage_paths:
        context.lineage_resolution?.physical_dependencies.map((item) => ({ ...item })) ?? [],
      impact_paths:
        context.impact_resolution?.impact_paths.map((item) => ({ ...item })) ?? [],
      diagnostics: context.diagnostics.map((item) => ({ ...item }))
    };
  }

  #createEmptyTables() {
    return {
      tokens: [],
      query_scopes: [],
      sources: [],
      cte_definitions: [],
      column_references: [],
      output_columns: [],
      physical_column_references: [],
      wildcard_expansions: [],
      output_lineages: [],
      lineage_paths: [],
      impact_paths: [],
      diagnostics: []
    };
  }
}

module.exports = {
  LineageEngine
};
