"use strict";

/**
 * QueryParserが生成したQuery ASTから、FROM/JOINソースとaliasの対応関係を作るResolver。
 *
 * SourceResolverの責務:
 *
 * - Queryごとに独立したscopeを作る。
 * - CTE名を、そのQuery scopeから参照できるソースとして登録する。
 * - FROMおよびJOINの物理テーブル、CTE、サブクエリ、UNNESTを分類する。
 * - aliasまたはソース名から、参照先Sourceを検索できる索引を作る。
 * - 相関サブクエリを想定し、見つからないaliasを親scopeへ検索できるようにする。
 *
 * SourceResolverはカラム名を解決しない。
 * 「s.amount」のsがどのSourceを指すかを判断する土台だけを作り、
 * amountの存在確認や物理カラムへの展開は後続のColumnResolverへ委譲する。
 */
class SourceResolver {
  constructor() {
    this.nextScopeId = 1;
    this.nextSourceId = 1;
    this.scopes = [];
  }

  /**
   * Query AST全体を解決する公開入口。
   *
   * 同じResolverインスタンスを再利用しても結果が混ざらないよう、
   * ID採番とscope一覧を毎回初期化する。
   */
  resolve(queryAst) {
    this.#validateQueryAst(queryAst);

    this.nextScopeId = 1;
    this.nextSourceId = 1;
    this.scopes = [];

    const rootScope = this.#resolveQueryScope(queryAst, null, "ROOT_QUERY");

    return {
      node_type: "SOURCE_RESOLUTION",
      root_scope_id: rootScope.scope_id,
      scopes: this.scopes
    };
  }

  /**
   * 指定scopeからaliasまたはソース名を検索する。
   *
   * current scopeで見つからない場合、parent_scope_idを順に辿る。
   * この動作により、将来の相関サブクエリで外側Queryのaliasを参照できる。
   */
  findSource(resolution, scopeId, referenceName) {
    if (!resolution || !Array.isArray(resolution.scopes)) {
      throw new TypeError("SourceResolver.findSource: resolution is invalid.");
    }

    const normalizedName = this.#normalizeName(referenceName);
    let currentScope = resolution.scopes.find((scope) => scope.scope_id === scopeId);

    while (currentScope) {
      const sourceId = currentScope.reference_map[normalizedName];

      if (sourceId !== undefined) {
        return currentScope.sources.find((source) => source.source_id === sourceId) || null;
      }

      currentScope = resolution.scopes.find(
        (scope) => scope.scope_id === currentScope.parent_scope_id
      );
    }

    return null;
  }

  /**
   * 1つのQueryを1つのscopeへ変換する。
   *
   * CTE本文も独立したQueryなので子scopeを持つ。
   * FROMサブクエリが完全なQuery ASTを持つ場合も同じ処理を再利用する。
   */
  #resolveQueryScope(queryAst, parentScopeId, scopeType) {
    const scope = {
      scope_id: this.nextScopeId++,
      scope_type: scopeType,
      parent_scope_id: parentScopeId,
      query_start_token_seq: queryAst.start_token_seq ?? null,
      query_end_token_seq: queryAst.end_token_seq ?? null,
      cte_definitions: [],
      sources: [],
      reference_map: Object.create(null)
    };

    this.scopes.push(scope);

    /*
     * CTE名はメインFROMを解析する前に登録する。
     * これにより、FROM customer_summaryのような名前を
     * 物理テーブルではなくCTEとして判定できる。
     */
    const ctes = Array.isArray(queryAst.common_table_expressions)
      ? queryAst.common_table_expressions
      : [];

    for (const cte of ctes) {
      const cteScope = this.#resolveQueryScope(cte.query, scope.scope_id, "CTE_QUERY");
      const cteDefinition = {
        cte_name: this.#normalizeName(cte.name),
        column_names: Array.isArray(cte.column_names) ? [...cte.column_names] : [],
        query_scope_id: cteScope.scope_id,
        start_token_seq: cte.start_token_seq,
        end_token_seq: cte.end_token_seq
      };

      if (scope.cte_definitions.some((item) => item.cte_name === cteDefinition.cte_name)) {
        throw new SyntaxError(
          `SourceResolver: duplicate CTE name "${cteDefinition.cte_name}" in scope ${scope.scope_id}.`
        );
      }

      scope.cte_definitions.push(cteDefinition);
    }

    if (queryAst.from?.source) {
      this.#registerSource(scope, queryAst.from.source, "FROM", null);
    }

    const joins = Array.isArray(queryAst.from?.joins) ? queryAst.from.joins : [];

    for (const join of joins) {
      this.#registerSource(scope, join.source, "JOIN", join.join_seq);
    }

    return scope;
  }

  /**
   * FromParserのsourceをResolver共通形式へ変換し、scopeへ登録する。
   */
  #registerSource(scope, parsedSource, sourceRole, joinSeq) {
    const sourceType = this.#resolveSourceType(scope, parsedSource);
    const sourceName = parsedSource.name
      ? this.#normalizeName(parsedSource.name)
      : null;
    const alias = parsedSource.alias
      ? this.#normalizeName(parsedSource.alias)
      : this.#deriveDefaultAlias(parsedSource, sourceType);

    const source = {
      source_id: this.nextSourceId++,
      source_seq: scope.sources.length + 1,
      scope_id: scope.scope_id,
      source_role: sourceRole,
      join_seq: joinSeq,
      source_type: sourceType,
      source_name: sourceName,
      source_alias: alias,
      resolved_source_name: sourceName,
      cte_query_scope_id: null,
      subquery_scope_id: null,
      expression: parsedSource.expression ?? null,
      start_token_seq: parsedSource.start_token_seq,
      end_token_seq: parsedSource.end_token_seq
    };

    if (sourceType === "CTE") {
      const definition = scope.cte_definitions.find(
        (cte) => cte.cte_name === sourceName
      );

      source.cte_query_scope_id = definition.query_scope_id;
    }

    if (sourceType === "SUBQUERY" && parsedSource.query_ast?.node_type === "QUERY") {
      const childScope = this.#resolveQueryScope(
        parsedSource.query_ast,
        scope.scope_id,
        "SUBQUERY"
      );

      source.subquery_scope_id = childScope.scope_id;
    }

    scope.sources.push(source);
    this.#registerReference(scope, source.source_alias, source);

    /*
     * aliasを明示していない場合は、完全名だけでなく末尾名でも参照可能にする。
     * project.dataset.salesなら、SALESをデフォルトaliasとして登録する。
     */
    if (!parsedSource.alias && sourceName) {
      this.#registerReference(scope, sourceName, source, true);
    }

    return source;
  }

  #resolveSourceType(scope, parsedSource) {
    if (parsedSource.source_type === "UNNEST") {
      return "UNNEST";
    }

    if (parsedSource.source_type === "SUBQUERY") {
      return "SUBQUERY";
    }

    const sourceName = this.#normalizeName(parsedSource.name);
    const isCte = scope.cte_definitions.some((cte) => cte.cte_name === sourceName);

    return isCte ? "CTE" : "PHYSICAL_TABLE";
  }

  #deriveDefaultAlias(parsedSource, sourceType) {
    if (sourceType === "PHYSICAL_TABLE" || sourceType === "CTE") {
      const parts = Array.isArray(parsedSource.name_parts)
        ? parsedSource.name_parts
        : String(parsedSource.name || "").split(".");

      return this.#normalizeName(parts[parts.length - 1]);
    }

    return null;
  }

  /**
   * reference_mapはalias検索用の索引。
   * 同一scope内で同じaliasが複数Sourceを指すとカラム解決不能になるため、
   * 曖昧な状態を許さず、この段階で明示的にエラーにする。
   */
  #registerReference(scope, referenceName, source, allowSameSource = false) {
    if (!referenceName) {
      return;
    }

    const normalizedName = this.#normalizeName(referenceName);
    const existingSourceId = scope.reference_map[normalizedName];

    if (existingSourceId !== undefined) {
      if (allowSameSource && existingSourceId === source.source_id) {
        return;
      }

      throw new SyntaxError(
        `SourceResolver: duplicate source reference "${normalizedName}" in scope ${scope.scope_id}.`
      );
    }

    scope.reference_map[normalizedName] = source.source_id;
  }

  #normalizeName(value) {
    if (value === null || value === undefined) {
      return null;
    }

    return String(value).toUpperCase();
  }

  #validateQueryAst(queryAst) {
    if (!queryAst || queryAst.node_type !== "QUERY") {
      throw new TypeError("SourceResolver: queryAst must be a QUERY node.");
    }
  }
}

module.exports = {
  SourceResolver
};
