"use strict";

const fs = require("fs");
const path = require("path");

const SOURCE_DIR = path.join(__dirname, "src");
const BUILD_DIR = path.join(__dirname, "build");
const BIGQUERY_DIR = path.join(__dirname, "bigquery");
const ENTRY_FILES = ["lineage_engine.js", "bigquery_exporter.js"];

/**
 * Node.jsのCommonJSモジュール群を、BigQuery JavaScript UDFで実行できる
 * 単一JavaScriptへ変換するBuilder。
 *
 * Builderをソース手書きではなく自動生成にする理由:
 * - Node.jsでテストしたソースとBigQueryへ配布するソースを一致させる。
 * - require/module.exportsの削除漏れを防ぐ。
 * - ファイル追加時にも依存関係から結合順を自動決定する。
 */
class UdfBuilder {
  constructor(options = {}) {
    this.sourceDir = options.sourceDir ?? SOURCE_DIR;
    this.buildDir = options.buildDir ?? BUILD_DIR;
    this.bigQueryDir = options.bigQueryDir ?? BIGQUERY_DIR;
    this.entryFiles = options.entryFiles ?? ENTRY_FILES;
  }

  build() {
    fs.mkdirSync(this.buildDir, { recursive: true });
    fs.mkdirSync(this.bigQueryDir, { recursive: true });

    const modules = this.#loadModules();
    const orderedModules = this.#sortModules(modules);
    const bundle = this.#createBundle(orderedModules);
    const sql = this.#createUdfSql(bundle);
    const manifest = this.#createManifest(orderedModules, bundle, sql);

    fs.writeFileSync(path.join(this.buildDir, "lineage_udf_bundle.js"), bundle);
    fs.writeFileSync(path.join(this.buildDir, "create_temp_lineage_udf.sql"), sql);
    fs.writeFileSync(
      path.join(this.buildDir, "bundle_manifest.json"),
      JSON.stringify(manifest, null, 2)
    );

    return manifest;
  }

  #loadModules() {
    const files = fs.readdirSync(this.sourceDir)
      .filter((fileName) => fileName.endsWith(".js"))
      .sort();

    const modules = new Map();

    for (const fileName of files) {
      const source = fs.readFileSync(path.join(this.sourceDir, fileName), "utf8");
      const dependencies = this.#extractDependencies(source, fileName);

      modules.set(fileName, {
        fileName,
        source,
        dependencies
      });
    }

    for (const entryFile of this.entryFiles) {
      if (!modules.has(entryFile)) {
        throw new Error(`UdfBuilder: entry file not found: ${entryFile}`);
      }
    }

    return modules;
  }

  #extractDependencies(source, fileName) {
    const dependencyNames = [];
    const requirePattern = /require\(["']\.\/(.+?)["']\)/g;
    let match;

    while ((match = requirePattern.exec(source)) !== null) {
      const dependencyFile = `${match[1]}.js`;

      if (dependencyFile === fileName) {
        throw new Error(`UdfBuilder: self dependency detected: ${fileName}`);
      }

      if (!dependencyNames.includes(dependencyFile)) {
        dependencyNames.push(dependencyFile);
      }
    }

    return dependencyNames;
  }

  #sortModules(modules) {
    const requiredFiles = new Set();

    const collect = (fileName) => {
      if (requiredFiles.has(fileName)) {
        return;
      }

      const moduleInfo = modules.get(fileName);

      if (!moduleInfo) {
        throw new Error(`UdfBuilder: dependency file not found: ${fileName}`);
      }

      requiredFiles.add(fileName);

      for (const dependency of moduleInfo.dependencies) {
        collect(dependency);
      }
    };

    for (const entryFile of this.entryFiles) {
      collect(entryFile);
    }

    const result = [];
    const temporary = new Set();
    const permanent = new Set();

    const visit = (fileName) => {
      if (permanent.has(fileName)) {
        return;
      }

      if (temporary.has(fileName)) {
        throw new Error(`UdfBuilder: circular dependency detected at ${fileName}`);
      }

      temporary.add(fileName);

      const moduleInfo = modules.get(fileName);

      for (const dependency of moduleInfo.dependencies) {
        if (requiredFiles.has(dependency)) {
          visit(dependency);
        }
      }

      temporary.delete(fileName);
      permanent.add(fileName);
      result.push(moduleInfo);
    };

    for (const fileName of Array.from(requiredFiles).sort()) {
      visit(fileName);
    }

    return result;
  }

  #transformSource(moduleInfo) {
    let source = moduleInfo.source;

    // 各ファイル先頭のstrict宣言は、bundle全体の先頭に1つだけ置く。
    source = source.replace(/^\s*["']use strict["'];\s*/m, "");

    // トップレベルとメソッド内部のCommonJS requireを除去する。
    source = source.replace(
      /^\s*const\s+\{[^\n]+\}\s*=\s*require\(["']\.\/.+?["']\);\s*$/gm,
      ""
    );

    // module.exports = { ... }; を除去する。
    source = source.replace(/\n?module\.exports\s*=\s*\{[\s\S]*?\};\s*$/m, "\n");

    if (/\brequire\s*\(/.test(source)) {
      throw new Error(
        `UdfBuilder: require() remained after transform: ${moduleInfo.fileName}`
      );
    }

    if (/module\.exports/.test(source)) {
      throw new Error(
        `UdfBuilder: module.exports remained after transform: ${moduleInfo.fileName}`
      );
    }

    return source.trim();
  }

  #createBundle(orderedModules) {
    const parts = [
      '"use strict";',
      "",
      "/**",
      " * AUTO-GENERATED FILE.",
      " * build_udf.jsから生成されるため、直接編集しない。",
      " */",
      ""
    ];

    for (const moduleInfo of orderedModules) {
      parts.push(
        `// ============================================================`,
        `// SOURCE: src/${moduleInfo.fileName}`,
        `// ============================================================`,
        this.#transformSource(moduleInfo),
        ""
      );
    }

    parts.push(`
/**
 * BigQuery UDFとNode.js bundle testが共有する公開入口。
 *
 * JSON文字列を引数・戻り値に使う理由:
 * - BigQueryの複雑なSTRUCT定義とASTの変化を切り離す。
 * - Parser拡張時にCREATE FUNCTIONのRETURNS型を毎回変更しなくてよい。
 * - SQL側でJSON_QUERY_ARRAY等を使って必要な行配列を展開できる。
 */
function analyzeLineageForBigQuery(
  sqlText,
  physicalColumnsJson,
  optionsJson,
  exportMetadataJson
) {
  const physicalColumns = physicalColumnsJson
    ? JSON.parse(physicalColumnsJson)
    : [];

  const options = optionsJson
    ? JSON.parse(optionsJson)
    : {};

  const exportMetadata = exportMetadataJson
    ? JSON.parse(exportMetadataJson)
    : null;

  const engine = new LineageEngine({
    physicalColumns,
    strictMode: options.strict_mode !== false
  });

  const engineResult = engine.analyze(sqlText, {
    impactTarget: options.impact_target ?? null
  });

  if (!exportMetadata) {
    return JSON.stringify(engineResult);
  }

  const exportedTables = new BigQueryExporter(exportMetadata).export(engineResult);

  return JSON.stringify({
    analysis_status: engineResult.analysis_status,
    failed_stage: engineResult.failed_stage,
    exported_tables: exportedTables,
    diagnostics: engineResult.diagnostics
  });
}

/* Node.jsでbundleを直接テストする場合だけ公開する。 */
if (typeof module !== "undefined" && module.exports) {
  module.exports = {
    analyzeLineageForBigQuery,
    LineageEngine,
    BigQueryExporter
  };
}
`);

    return `${parts.join("\n").trim()}\n`;
  }

  #createUdfSql(bundle) {
    if (bundle.includes('"""')) {
      throw new Error('UdfBuilder: bundle contains r""" delimiter.');
    }

    return `-- AUTO-GENERATED by build_udf.js\n` +
`-- JSON文字列を返すTEMP FUNCTION。\n` +
`-- export_metadata_jsonをNULLにするとLineageEngineの解析結果を返す。\n` +
`-- metadataを渡すとBigQueryExporter適用済みのテーブル別行配列を返す。\n\n` +
`CREATE TEMP FUNCTION analyze_lineage_json(\n` +
`  sql_text STRING,\n` +
`  physical_columns_json STRING,\n` +
`  options_json STRING,\n` +
`  export_metadata_json STRING\n` +
`)\n` +
`RETURNS STRING\n` +
`LANGUAGE js\n` +
`AS r"""\n` +
`${bundle}\n` +
`return analyzeLineageForBigQuery(\n` +
`  sql_text,\n` +
`  physical_columns_json,\n` +
`  options_json,\n` +
`  export_metadata_json\n` +
`);\n` +
`""";\n`;
  }

  #createManifest(orderedModules, bundle, sql) {
    return {
      generated_at: new Date().toISOString(),
      entry_files: this.entryFiles,
      source_files: orderedModules.map((item) => item.fileName),
      source_file_count: orderedModules.length,
      bundle_bytes: Buffer.byteLength(bundle, "utf8"),
      sql_bytes: Buffer.byteLength(sql, "utf8")
    };
  }
}

if (require.main === module) {
  const manifest = new UdfBuilder().build();
  console.log(JSON.stringify(manifest, null, 2));
}

module.exports = {
  UdfBuilder
};
