CREATE OR REPLACE VIEW `YOUR_PROJECT.YOUR_DATASET.latest_lineage_analyses` AS
SELECT *
FROM `YOUR_PROJECT.YOUR_DATASET.lineage_analyses`
QUALIFY ROW_NUMBER() OVER (PARTITION BY view_project,view_dataset,view_name ORDER BY analyzed_at DESC)=1;

CREATE OR REPLACE VIEW `YOUR_PROJECT.YOUR_DATASET.latest_lineage_paths` AS
SELECT p.*
FROM `YOUR_PROJECT.YOUR_DATASET.lineage_paths` p
JOIN `YOUR_PROJECT.YOUR_DATASET.latest_lineage_analyses` a
USING (analysis_id,view_project,view_dataset,view_name);
