DECLARE target_table STRING DEFAULT 'PROJECT.DATASET.SALES';
DECLARE target_column STRING DEFAULT 'AMOUNT';

SELECT view_project,view_dataset,view_name,output_column_name,
physical_table_name,physical_column_name,lineage_path
FROM `YOUR_PROJECT.YOUR_DATASET.latest_lineage_paths`
WHERE physical_table_name=UPPER(target_table)
AND physical_column_name=UPPER(target_column)
ORDER BY view_project,view_dataset,view_name,output_column_name;
