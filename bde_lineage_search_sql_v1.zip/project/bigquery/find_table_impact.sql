DECLARE target_table STRING DEFAULT 'PROJECT.DATASET.SALES';

SELECT physical_column_name,view_project,view_dataset,view_name,
output_column_name,lineage_path
FROM `YOUR_PROJECT.YOUR_DATASET.latest_lineage_paths`
WHERE physical_table_name=UPPER(target_table)
ORDER BY physical_column_name,view_project,view_dataset,view_name,output_column_name;
