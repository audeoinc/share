SELECT *
FROM `YOUR_PROJECT.YOUR_DATASET.latest_lineage_paths`
WHERE physical_table_name='PROJECT.DATASET.SALES'
AND physical_column_name='AMOUNT';
