SET @@location = 'asia-northeast1';

-- =============================================================================
-- Persistent JavaScript UDF creation
--
-- Before execution:
--   1. Upload ../udf_bundle/lineage_udf_bundle.js to GCS.
--   2. Replace the GCS URI below.
--   3. Change project/dataset names if necessary.
--
-- Default UDF location used by this repository:
--   audeodb.sample_ds.analyze_lineage_json
-- =============================================================================

CREATE OR REPLACE FUNCTION
  `audeodb.sample_ds.analyze_lineage_json`(
    sql_text STRING,
    physical_columns_json STRING,
    options_json STRING,
    export_metadata_json STRING
  )
RETURNS STRING
LANGUAGE js
OPTIONS (
  library = [
    'gs://YOUR_BUCKET/YOUR_PATH/lineage_udf_bundle.js'
  ]
)
AS r"""
  return analyzeLineageForBigQuery(
    sql_text,
    physical_columns_json,
    options_json,
    export_metadata_json
  );
""";
