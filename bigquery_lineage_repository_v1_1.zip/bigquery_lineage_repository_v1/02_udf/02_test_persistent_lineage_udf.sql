SET @@location = 'asia-northeast1';

-- =============================================================================
-- Persistent UDF smoke test
-- Successful execution should return a JSON string containing lineage_paths.
-- =============================================================================

DECLARE physical_columns_json STRING DEFAULT TO_JSON_STRING([
  STRUCT(
    'AUDEODB.SAMPLE_DS.CUSTOMER_PURCHASE_HISTORY' AS table_name,
    'UNIT_PRICE' AS column_name,
    'UNIT_PRICE' AS field_path,
    5 AS ordinal_position,
    'NUMERIC' AS data_type,
    'YES' AS is_nullable
  )
]);

SELECT `audeodb.sample_ds.analyze_lineage_json`(
  'SELECT unit_price AS sales_price FROM `audeodb.sample_ds.customer_purchase_history`',
  physical_columns_json,
  TO_JSON_STRING(STRUCT(FALSE AS strict_mode)),
  TO_JSON_STRING(STRUCT(
    GENERATE_UUID() AS analysis_id,
    'audeodb' AS target_project,
    'sample_ds' AS target_dataset,
    'v_udf_smoke_test' AS target_object,
    'VIEW' AS target_object_type
  ))
) AS analysis_json;
