SET @@location = 'asia-northeast1';

-- =============================================================================
-- Looker Studio candidate source
-- Returns unique origin TABLE/VIEW/column combinations available for impact search.
-- The optional parameters can be replaced with Looker Studio parameters later.
-- Empty strings mean no filtering.
-- =============================================================================

DECLARE input_project_text STRING DEFAULT '';
DECLARE input_dataset_text STRING DEFAULT '';
DECLARE input_object_text STRING DEFAULT '';
DECLARE input_column_text STRING DEFAULT '';

WITH candidates AS (
  SELECT DISTINCT
    LOWER(origin_project) AS object_project,
    LOWER(origin_dataset) AS object_dataset,
    LOWER(origin_object) AS object_name,
    origin_object_type AS object_type,
    LOWER(origin_column) AS column_name
  FROM `audeodb.lineage_repository.lineage_impact`
  WHERE origin_column IS NOT NULL
)
SELECT
  object_project,
  object_dataset,
  object_name,
  object_type,
  column_name,
  CONCAT(object_project, '.', object_dataset, '.', object_name, '.', column_name) AS candidate_label
FROM candidates
WHERE (TRIM(input_project_text) = '' OR object_project LIKE CONCAT('%', LOWER(TRIM(input_project_text)), '%'))
  AND (TRIM(input_dataset_text) = '' OR object_dataset LIKE CONCAT('%', LOWER(TRIM(input_dataset_text)), '%'))
  AND (TRIM(input_object_text) = '' OR object_name LIKE CONCAT('%', LOWER(TRIM(input_object_text)), '%'))
  AND (TRIM(input_column_text) = '' OR column_name LIKE CONCAT('%', LOWER(TRIM(input_column_text)), '%'))
ORDER BY object_project, object_dataset, object_name, column_name;
