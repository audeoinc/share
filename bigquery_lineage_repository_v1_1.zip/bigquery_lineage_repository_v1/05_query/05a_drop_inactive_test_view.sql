-- INACTIVE VIEW CLEANUP TEST - PHASE A
SET @@location = 'asia-northeast1';

-- Confirm that the initial pipeline has produced dependency rows.
SELECT COUNT(*) AS before_drop_dependency_count
FROM `audeodb.lineage_repository.lineage_direct_dependency`
WHERE target_project = 'audeodb'
  AND target_dataset = 'sample_ds'
  AND target_object = 'v_test_delete_cleanup';

-- Drop the View.
DROP VIEW IF EXISTS `audeodb.sample_ds.v_test_delete_cleanup`;

-- Next run, in this order:
--   04_pipeline/01_sync_view_registry.sql
--   04_pipeline/03_analyze_changed_objects.sql
--   04_pipeline/04_rebuild_impact_table.sql
