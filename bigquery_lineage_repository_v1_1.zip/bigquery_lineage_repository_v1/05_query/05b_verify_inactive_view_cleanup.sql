-- INACTIVE VIEW CLEANUP TEST - PHASE B
-- Run after the three pipeline scripts listed in Phase A.
SET @@location = 'asia-northeast1';

SELECT
  is_active,
  is_changed,
  analysis_status
FROM `audeodb.lineage_repository.lineage_definition_registry`
WHERE object_project = 'audeodb'
  AND object_dataset = 'sample_ds'
  AND object_name = 'v_test_delete_cleanup';

SELECT COUNT(*) AS after_drop_dependency_count
FROM `audeodb.lineage_repository.lineage_direct_dependency`
WHERE target_project = 'audeodb'
  AND target_dataset = 'sample_ds'
  AND target_object = 'v_test_delete_cleanup';

SELECT COUNT(*) AS after_drop_impact_count
FROM `audeodb.lineage_repository.lineage_impact`
WHERE impacted_project = 'audeodb'
  AND impacted_dataset = 'sample_ds'
  AND impacted_object = 'v_test_delete_cleanup';

-- Expected:
--   registry.is_active = FALSE
--   after_drop_dependency_count = 0
--   after_drop_impact_count = 0
