-- Run after:
--   01_sync_view_registry.sql
--   03_analyze_changed_objects.sql
--   04_rebuild_impact_table.sql
SET @@location = 'asia-northeast1';

-- 1. Rank 1/2/3 must exist from the physical column unit_price.
SELECT
  impact_rank,
  impacted_object,
  impacted_column,
  direct_source_object,
  direct_source_object_type,
  dependency_path
FROM `audeodb.lineage_repository.lineage_impact`
WHERE origin_project = 'audeodb'
  AND origin_dataset = 'sample_ds'
  AND origin_object = 'customer_purchase_history'
  AND origin_column = 'unit_price'
  AND impacted_object IN ('v_test_rank_1', 'v_test_rank_2', 'v_test_rank_3')
ORDER BY impact_rank, impacted_object, impacted_column;

-- Expected minimum:
-- rank 1 -> v_test_rank_1.source_unit_price
-- rank 2 -> v_test_rank_2.source_unit_price / price_with_tax
-- rank 3 -> v_test_rank_3.price_with_tax / rounded_price_with_tax

-- 2. Sources that are Views must be classified as VIEW.
SELECT
  source_object,
  source_object_type,
  target_object,
  target_column
FROM `audeodb.lineage_repository.lineage_direct_dependency`
WHERE source_object IN (
  'v_test_rank_1',
  'v_test_rank_2',
  'v_test_struct_rank_1',
  'v_test_array_struct_rank_1'
)
ORDER BY source_object, target_object, target_column;

-- Expected: source_object_type = VIEW for every returned row.

-- 3. STRUCT child field path must be retained and recursively expanded.
SELECT
  impact_rank,
  origin_column,
  impacted_object,
  impacted_column,
  dependency_path
FROM `audeodb.lineage_repository.lineage_impact`
WHERE origin_object = 'customer_purchase_history'
  AND origin_column = 'delivery_address.contact.phone'
  AND impacted_object IN ('v_test_struct_rank_1', 'v_test_struct_rank_2')
ORDER BY impact_rank, impacted_object, impacted_column;

-- 4. ARRAY<STRUCT> child field paths through UNNEST.
SELECT
  impact_rank,
  origin_column,
  impacted_object,
  impacted_column,
  dependency_path
FROM `audeodb.lineage_repository.lineage_impact`
WHERE origin_object = 'customer_purchase_history'
  AND origin_column IN (
    'order_items.product.product_id',
    'order_items.product.category',
    'order_items.quantity'
  )
  AND impacted_object IN (
    'v_test_array_struct_rank_1',
    'v_test_array_struct_rank_2'
  )
ORDER BY origin_column, impact_rank, impacted_object, impacted_column;

-- 5. No mixed-case Repository identifiers should remain.
SELECT
  COUNTIF(source_project != LOWER(source_project)) AS uppercase_source_project,
  COUNTIF(source_dataset != LOWER(source_dataset)) AS uppercase_source_dataset,
  COUNTIF(source_object != LOWER(source_object)) AS uppercase_source_object,
  COUNTIF(source_column != LOWER(source_column)) AS uppercase_source_column,
  COUNTIF(target_project != LOWER(target_project)) AS uppercase_target_project,
  COUNTIF(target_dataset != LOWER(target_dataset)) AS uppercase_target_dataset,
  COUNTIF(target_object != LOWER(target_object)) AS uppercase_target_object,
  COUNTIF(target_column != LOWER(target_column)) AS uppercase_target_column
FROM `audeodb.lineage_repository.lineage_direct_dependency`;
