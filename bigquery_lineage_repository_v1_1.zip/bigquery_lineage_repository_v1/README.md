# BigQuery Lineage Repository v1.1

## v1.1 critical fixes

- Repository identifiers are normalized to lowercase.
- Recursive impact joins are case-insensitive and Rank 2+ paths are preserved.
- `source_object_type` is classified as `VIEW` or `TABLE` using the active registry and `INFORMATION_SCHEMA.TABLES`.
- Dependencies and diagnostics for inactive/deleted Views are removed before analysis.
- Regression Views cover Rank 1/2/3, nested STRUCT, and ARRAY<STRUCT> through `UNNEST`.

### Upgrade from v1.0

Run once:

```text
04_pipeline/00_force_full_reanalysis_v1_1.sql
04_pipeline/01_sync_view_registry.sql
04_pipeline/02_sync_scheduled_ctas_registry.sql
04_pipeline/03_analyze_changed_objects.sql
04_pipeline/04_rebuild_impact_table.sql
05_query/04_regression_test_critical_fixes.sql
```

The one-time reset is required because existing direct-dependency rows retain the old casing and source type until they are reanalyzed.

# BigQuery Physical Column Lineage Repository

物理テーブルまたはViewのカラム変更時に、影響を受ける後続のTable／ViewカラムをRank順に検索する検証用Repositoryです。

## デフォルト構成

- Project: `audeodb`
- 解析対象Dataset: `sample_ds`
- Repository Dataset: `lineage_repository`
- Region: `asia-northeast1`
- Persistent UDF: `audeodb.sample_ds.analyze_lineage_json`

別環境で使用する場合は、各SQLの冒頭にあるプロジェクト名・データセット名・リージョンを置換してください。

## ディレクトリ

```text
01_sample/
  01_create_sample_tables.sql
  02_create_sample_views.sql
02_udf/
  01_create_persistent_lineage_udf.sql
  02_test_persistent_lineage_udf.sql
03_repository/
  01_create_repository_tables.sql
04_pipeline/
  01_sync_view_registry.sql
  02_sync_scheduled_ctas_registry.sql
  03_analyze_changed_objects.sql
  04_rebuild_impact_table.sql
05_query/
  01_validation_queries.sql
  02_query_column_impact.sql
  03_search_object_column_candidates.sql
udf_bundle/
  lineage_udf_bundle.js
```

## 初回構築の実行順

### 1. サンプルデータを作成

```text
01_sample/01_create_sample_tables.sql
01_sample/02_create_sample_views.sql
```

3つの物理テーブルと、依存関係を持つ検証用View群を作成します。物理テーブルにはSTRUCT、ネストSTRUCT、ARRAY<STRUCT>を含み、`INFORMATION_SCHEMA.COLUMN_FIELD_PATHS`の検証もできます。

### 2. JavaScript bundleをGCSへ配置

`udf_bundle/lineage_udf_bundle.js`を任意のGCSパスへアップロードします。

例:

```text
gs://your-lineage-bucket/udf/lineage_udf_bundle.js
```

### 3. Persistent UDFを作成

`02_udf/01_create_persistent_lineage_udf.sql`のGCS URIを変更して実行します。

その後、次のSQLで疎通確認します。

```text
02_udf/02_test_persistent_lineage_udf.sql
```

### 4. Repositoryテーブルを作成

```text
03_repository/01_create_repository_tables.sql
```

作成されるテーブル:

- `lineage_definition_registry`
- `lineage_direct_dependency`
- `lineage_impact`
- `lineage_diagnostic`

### 5. Registryを同期

```text
04_pipeline/01_sync_view_registry.sql
04_pipeline/02_sync_scheduled_ctas_registry.sql
```

Scheduled Queryを利用しない検証では、2本目は実行しても登録対象が0件になる場合があります。

### 6. 変更対象を解析

```text
04_pipeline/03_analyze_changed_objects.sql
```

このSQLは次を行います。

1. `is_changed = TRUE`の定義を取得
2. `COLUMNS`と`COLUMN_FIELD_PATHS`から物理カラムメタデータを生成
3. Persistent UDFを実行
4. `lineage_direct_dependency`を更新
5. diagnosticsを記録
6. 成功した定義の`is_changed`をFALSEに更新

### 7. ImpactをRank展開

```text
04_pipeline/04_rebuild_impact_table.sql
```

`lineage_direct_dependency`から再帰的に経路を展開し、直接参照をRank 1、以降をRank 2、3…として`lineage_impact`へ登録します。

### 8. 検証・検索

```text
05_query/01_validation_queries.sql
05_query/02_query_column_impact.sql
```

影響検索SQLでは冒頭の次の値を変更します。

```sql
DECLARE input_project STRING DEFAULT 'audeodb';
DECLARE input_dataset STRING DEFAULT 'sample_ds';
DECLARE input_object_name STRING DEFAULT 'customer_purchase_history';
DECLARE input_column_name STRING DEFAULT 'unit_price';
```

STRUCT子フィールドも完全なfield pathで指定できます。

```sql
DECLARE input_column_name STRING DEFAULT 'delivery_address.contact.phone';
```

## 日常運用の実行順

ViewまたはScheduled Queryの定義変更を反映するときは次の4本です。

```text
1. 04_pipeline/01_sync_view_registry.sql
2. 04_pipeline/02_sync_scheduled_ctas_registry.sql
3. 04_pipeline/03_analyze_changed_objects.sql
4. 04_pipeline/04_rebuild_impact_table.sql
```

その後、`05_query/02_query_column_impact.sql`で検索します。

## Looker Studio向け

- 検索候補: `05_query/03_search_object_column_candidates.sql`
- 影響結果: `05_query/02_query_column_impact.sql`

手元検証では`DECLARE`を使っています。Looker Studioへ接続するときは、`input_project`、`input_dataset`、`input_object_name`、`input_column_name`をLooker Studioパラメータへ置き換えます。

## 注意事項

- `04_rebuild_impact_table.sql`を実行しないと`lineage_impact`は更新されません。
- `03_analyze_changed_objects.sql`だけでは`lineage_direct_dependency`までの更新です。
- 識別子の大文字・小文字が混在している場合でも検索SQLは`LOWER()`で比較しますが、再帰結合のためRepository登録値の正規化は今後の改善候補です。
- UDF bundleはv1.5.0-014です。
