-- ONE-TIME MIGRATION FOR v1.1
SET @@location = 'asia-northeast1';

-- Existing rows may contain uppercase identifiers and incorrect source types.
-- Force all active definitions through the corrected analyzer.
DELETE FROM `audeodb.lineage_repository.lineage_direct_dependency`;
DELETE FROM `audeodb.lineage_repository.lineage_diagnostic`;
DELETE FROM `audeodb.lineage_repository.lineage_impact`;

UPDATE `audeodb.lineage_repository.lineage_definition_registry`
SET
  is_changed = TRUE,
  analysis_status = 'PENDING',
  last_analyzed_hash = NULL,
  last_analyzed_at = NULL,
  updated_at = CURRENT_TIMESTAMP()
WHERE is_active = TRUE;

SELECT
  COUNTIF(is_active = TRUE AND is_changed = TRUE) AS objects_queued_for_reanalysis
FROM `audeodb.lineage_repository.lineage_definition_registry`;
