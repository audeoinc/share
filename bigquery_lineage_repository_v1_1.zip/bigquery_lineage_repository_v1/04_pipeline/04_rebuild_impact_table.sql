-- EXECUTION ORDER: Initial setup 09 / Daily operation 04
SET @@location = 'asia-northeast1';

-- ============================================================================
-- Direct dependency -> ranked impact paths
-- 初版は毎回全件再構築します。
-- ============================================================================

DECLARE snapshot_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP();
DECLARE max_rank INT64 DEFAULT 100;

CREATE OR REPLACE TABLE `audeodb.lineage_repository.lineage_impact`
PARTITION BY DATE(snapshot_at)
CLUSTER BY origin_project, origin_dataset, origin_object, origin_column
AS
WITH RECURSIVE impact_tree AS (
  -- Rank 1: direct dependency
  SELECT
    LOWER(edge.source_project) AS origin_project,
    LOWER(edge.source_dataset) AS origin_dataset,
    LOWER(edge.source_object) AS origin_object,
    edge.source_object_type AS origin_object_type,
    LOWER(edge.source_column) AS origin_column,

    1 AS impact_rank,

    LOWER(edge.target_project) AS impacted_project,
    LOWER(edge.target_dataset) AS impacted_dataset,
    LOWER(edge.target_object) AS impacted_object,
    edge.target_object_type AS impacted_object_type,
    LOWER(edge.target_column) AS impacted_column,

    LOWER(edge.source_project) AS direct_source_project,
    LOWER(edge.source_dataset) AS direct_source_dataset,
    LOWER(edge.source_object) AS direct_source_object,
    edge.source_object_type AS direct_source_object_type,
    LOWER(edge.source_column) AS direct_source_column,

    [
      CONCAT(
        COALESCE(LOWER(edge.source_project), ''), '.',
        COALESCE(LOWER(edge.source_dataset), ''), '.',
        LOWER(edge.source_object), '.',
        COALESCE(LOWER(edge.source_column), '*')
      ),
      CONCAT(
        COALESCE(LOWER(edge.target_project), ''), '.',
        COALESCE(LOWER(edge.target_dataset), ''), '.',
        LOWER(edge.target_object), '.',
        COALESCE(LOWER(edge.target_column), '*')
      )
    ] AS dependency_path,

    edge.generation_type,
    edge.resolution_status,
    FALSE AS is_cycle
  FROM `audeodb.lineage_repository.lineage_direct_dependency` AS edge
  WHERE edge.resolution_status IN ('RESOLVED', 'SOURCE_RESOLVED', 'PARTIALLY_RESOLVED')

  UNION ALL

  SELECT
    parent.origin_project,
    parent.origin_dataset,
    parent.origin_object,
    parent.origin_object_type,
    parent.origin_column,

    parent.impact_rank + 1,

    LOWER(child.target_project),
    LOWER(child.target_dataset),
    LOWER(child.target_object),
    child.target_object_type,
    LOWER(child.target_column),

    LOWER(child.source_project),
    LOWER(child.source_dataset),
    LOWER(child.source_object),
    child.source_object_type,
    LOWER(child.source_column),

    ARRAY_CONCAT(
      parent.dependency_path,
      [CONCAT(
        COALESCE(LOWER(child.target_project), ''), '.',
        COALESCE(LOWER(child.target_dataset), ''), '.',
        LOWER(child.target_object), '.',
        COALESCE(LOWER(child.target_column), '*')
      )]
    ),

    child.generation_type,
    child.resolution_status,

    CONCAT(
      COALESCE(LOWER(child.target_project), ''), '.',
      COALESCE(LOWER(child.target_dataset), ''), '.',
      LOWER(child.target_object), '.',
      COALESCE(LOWER(child.target_column), '*')
    ) IN UNNEST(parent.dependency_path) AS is_cycle
  FROM impact_tree AS parent
  JOIN `audeodb.lineage_repository.lineage_direct_dependency` AS child
    ON LOWER(child.source_project) = LOWER(parent.impacted_project)
   AND LOWER(child.source_dataset) = LOWER(parent.impacted_dataset)
   AND LOWER(child.source_object) = LOWER(parent.impacted_object)
   AND (
     LOWER(child.source_column) = LOWER(parent.impacted_column)
     OR child.source_column IS NULL
     OR parent.impacted_column IS NULL
   )
  WHERE parent.impact_rank < max_rank
    AND parent.is_cycle = FALSE
    AND child.resolution_status IN ('RESOLVED', 'SOURCE_RESOLVED', 'PARTIALLY_RESOLVED')
)
SELECT DISTINCT
  snapshot_time AS snapshot_at,
  origin_project,
  origin_dataset,
  origin_object,
  origin_object_type,
  origin_column,
  impact_rank,
  impacted_project,
  impacted_dataset,
  impacted_object,
  impacted_object_type,
  impacted_column,
  direct_source_project,
  direct_source_dataset,
  direct_source_object,
  direct_source_object_type,
  direct_source_column,
  dependency_path,
  TO_HEX(SHA256(ARRAY_TO_STRING(dependency_path, ' -> '))) AS path_hash,
  generation_type,
  resolution_status,
  is_cycle
FROM impact_tree;
