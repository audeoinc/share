# Regression Test Result

Version: 1.4.0  
Date: 2026-07-21  
Runtime: Node.js v22.16.0

```text
PASS 01_test_statement_parser.js
PASS 02_test_query_regression.js
PASS 03_test_bigquery_entry.js
PASS 04_test_failure_contract.js
PASS 05_test_statement_integration.js
PASS 06_test_registry_sync_contract.js

Test files: 6
Passed:     6
Failed:     0
```

The Registry synchronization contract verifies:

- VIEW and JOB sources are unified through `definition_inventory`.
- Original JOB SQL is retained as `definition_text` and used for hashing.
- Latest successful job selection is deterministic.
- CTAS extraction is not implemented in synchronization SQL.
- The approved DAG service account is configured.
- Missing VIEW and generated TABLE inactivation remains present.
- Persistent Job Registry DDL belongs to repository setup, not the daily pipeline.
