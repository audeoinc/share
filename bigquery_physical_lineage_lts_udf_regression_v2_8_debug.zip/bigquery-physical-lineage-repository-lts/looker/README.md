# Looker Studio

Looker Studioの画面仕様は`docs/LOOKER_STUDIO_DESIGN.md`を参照してください。

実装時には、接続先View定義、計算フィールド、フィルター、画面キャプチャ、導入手順をこのディレクトリへ追加します。
