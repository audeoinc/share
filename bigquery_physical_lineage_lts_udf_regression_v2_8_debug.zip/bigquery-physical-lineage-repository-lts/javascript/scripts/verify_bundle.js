"use strict";

const assert = require("assert");
const fs = require("fs");
const path = require("path");

const rootDir = path.resolve(__dirname, "..");
const generated = require(path.join(rootDir, "build", "lineage_udf_bundle.js"));
const legacy = require(path.join(rootDir, "legacy", "lineage_udf_bundle_v1_5_0_014.js"));

const sql = "SELECT customer_id, amount * 1.1 AS adjusted_amount FROM `project.dataset.sales`";
const physicalColumns = [
  { project_id: "project", dataset_id: "dataset", table_name: "sales", column_name: "customer_id", field_path: "customer_id", ordinal_position: 1 },
  { project_id: "project", dataset_id: "dataset", table_name: "sales", column_name: "amount", field_path: "amount", ordinal_position: 2 }
];

const generatedResult = new generated.LineageEngine({ physicalColumns, strictMode: false }).analyze(sql);
const legacyResult = new legacy.LineageEngine({ physicalColumns, strictMode: false }).analyze(sql);
assert.deepStrictEqual(generatedResult, legacyResult);
console.log(JSON.stringify({ status: "PASS", check: "generated bundle behavior equals legacy bundle" }, null, 2));
