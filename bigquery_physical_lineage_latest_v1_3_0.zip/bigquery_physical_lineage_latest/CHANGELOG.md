# Changelog

## 1.2.0 - 2026-07-21

- Added `StatementParser` before `QueryParser`.
- Added CTAS query-token extraction inside the lineage bundle.
- Unified VIEW and JOB definition synchronization.
- Removed SQL-side regular-expression CTAS extraction.
- Preserved raw JOB SQL for hashing and auditability.
- Added generated TABLE inactivity detection using regional `INFORMATION_SCHEMA.TABLES`.
- Included STRUCT / ARRAY<STRUCT> validation files.
- Consolidated latest operational files into one versioned package.

## v1.2.1 - 2026-07-21

- Added a Node.js regression test foundation under `06_test/`.
- Added 39 SQL scenarios covering StatementParser, clauses, CTEs, joins,
  scalar subqueries, UNNEST, STRUCT paths, wildcards, set operations,
  BigQuery UDF entry/export contracts, and strict/non-strict failures.
- Fixed set-operation splitting for `UNION DISTINCT`, `INTERSECT DISTINCT`,
  and `EXCEPT DISTINCT`.
- Prevented `SELECT * EXCEPT(...)` from being misclassified as a set operation.
- Confirmed all four regression test suites pass on Node.js v22.16.0.

## v1.3.0 - 2026-07-21

### StatementParser formal integration

- Formally integrated `StatementParser` between Lexer and QueryParser.
- Added support for:
  - plain `SELECT` / `WITH`
  - `CREATE TABLE ... AS SELECT/WITH`
  - `CREATE VIEW ... AS SELECT/WITH`
  - `CREATE MATERIALIZED VIEW ... AS SELECT/WITH`
- Preserved the original SQL in `sql_text` while passing only query tokens to QueryParser.
- Added `statement.statement_type` and `statement.query_start_token_seq` to the engine result.
- Added `statement_type` and `query_start_token_seq` to the exported analysis row.
- Added formal integration regression tests covering the direct engine API and BigQuery UDF entry.
