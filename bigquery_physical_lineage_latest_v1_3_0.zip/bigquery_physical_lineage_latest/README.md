# BigQuery Physical Lineage Latest Package

## Main changes

- `lineage_udf_bundle.js` now includes `StatementParser`.
- Plain `SELECT` / `WITH` and `CREATE TABLE ... AS SELECT/WITH` share the same analysis entry point.
- CTAS source SQL is stored unchanged in the Definition Registry.
- VIEW and JOB definitions are synchronized by one pipeline file.
- Missing VIEWs and physically removed generated TABLEs are marked inactive.
- Dependency refresh uses the re-runnable staging-first implementation.

## Daily execution order

1. `04_pipeline/01_sync_definition_registry.sql`
2. `04_pipeline/02_analyze_changed_objects.sql`
3. `04_pipeline/03_rebuild_impact_table.sql`

## Initial setup

1. Create sample objects if required from `01_sample`.
2. Upload `02_udf/lineage_udf_bundle.js` to GCS.
3. Edit the placeholders in `02_udf/create_persistent_lineage_udf.sql` and execute it.
4. Run `03_repository/01_create_repository_tables.sql`.
5. Run the daily pipeline in order.

## Important configuration

Replace the placeholder DAG service account in:

`04_pipeline/01_sync_definition_registry.sql`

The current metadata scope is `audeodb.sample_ds` in `asia-northeast1`.

## StatementParser behavior

Supported top-level statements:

- `SELECT ...`
- `WITH ... SELECT ...`
- `CREATE [OR REPLACE] [TEMP|TEMPORARY] TABLE ... AS SELECT ...`
- `CREATE ... TABLE ... PARTITION BY ... CLUSTER BY ... OPTIONS (...) AS WITH ...`

The parser uses Lexer tokens and parenthesis depth. It does not rewrite the original SQL text.

## Node.js regression tests

Node.js 18 or later is required.

```bash
npm test
```

The runner executes every `06_test/NN_test_*.js` file in a separate Node.js
process and returns a non-zero exit code if any suite fails.

Current suites:

- `01_test_statement_parser.js`: SELECT/WITH/CTAS statement normalization
- `02_test_query_regression.js`: parser and resolver regression scenarios
- `03_test_bigquery_entry.js`: BigQuery UDF JSON and export contract
- `04_test_failure_contract.js`: strict and non-strict failure behavior

## StatementParser support (v1.3.0)

The public lineage entry accepts the following statement forms directly:

```sql
SELECT ...
WITH ... SELECT ...
CREATE TABLE ... AS SELECT ...
CREATE VIEW ... AS SELECT ...
CREATE MATERIALIZED VIEW ... AS SELECT ...
```

The original SQL is retained in `sql_text`. Only the `SELECT` or `WITH` token range is forwarded to `QueryParser`.
The result includes `statement.statement_type` and `statement.query_start_token_seq`.
