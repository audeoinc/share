# Node.js Regression Test Result

- Product version: 1.3.0
- Execution date: 2026-07-21
- Node.js: v22.16.0

## Result

```text
PASS 01_test_statement_parser.js
PASS 02_test_query_regression.js
PASS 03_test_bigquery_entry.js
PASS 04_test_failure_contract.js
PASS 05_test_statement_integration.js

Test files: 5
Passed:     5
Failed:     0
```

## Formal StatementParser integration checks

- Original SQL is preserved.
- QueryParser receives tokens beginning with `SELECT` or `WITH`.
- Plain query, CTAS, VIEW, and MATERIALIZED VIEW produce equivalent lineage semantics.
- Statement metadata is returned by `LineageEngine`.
- Statement metadata is available through the BigQuery UDF public entry.
- Statement metadata is included in the exported analysis row.
- Unsupported statements fail at the `STATEMENT_PARSER` stage.
