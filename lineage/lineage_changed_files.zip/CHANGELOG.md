# Unreleased

- Implemented `CAST(expr AS type)` and `SAFE_CAST(expr AS type)` in the
  ExpressionParser. Previously the `expr AS type` form was not parsed, so these
  functions only survived inside a top-level SELECT item (via the
  raw-expression fallback) and failed elsewhere with
  `ExpressionParser: expected ")", but found "AS".` — breaking any View that
  used CAST/SAFE_CAST in WHERE, JOIN ON, GROUP BY, HAVING, or ORDER BY. The
  value expression now drives lineage and the target type (including
  parameterized precision like `NUMERIC(10, 2)`, angle-bracket parameters like
  `ARRAY<INT64>` / `STRUCT<a INT64, b STRING>`, and a trailing `FORMAT` clause)
  is consumed without producing spurious physical-column references.
- Fixed a related paren-counting defect in the window sub-expression parser
  (`#parseWindowSubExpression`): the `)` that closes an inner function call
  (e.g. `SAFE_CAST(...)`) was mistaken for the window-clause terminator, so any
  function call inside a window `PARTITION BY` / `ORDER BY` truncated the
  sub-expression. This surfaced as a QUALIFY failure
  (`unexpected token ")"`); it now parses correctly.
- Added `test/test_v1_5_0_032.js` covering CAST/SAFE_CAST across SELECT, WHERE,
  JOIN ON, GROUP BY, HAVING, ORDER BY, and QUALIFY windows, and wired it into
  `test:release`. The 48-case Golden regression and all existing tests still
  pass; the regenerated bundle SHA-256 is recorded in `release_manifest.json`.

- Made repository table names configurable from the declaration block using a
  prefix, a per-table infix, a canonical base name, and a suffix, so
  environments with different naming rules no longer require edits to the body
  of the scripts.
- Added `table_name_prefix`/`table_name_suffix` and seven derived table-name
  variables (with name-format ASSERTs) to `01_setup_lineage_environment.sql`
  and `03_run_daily_lineage_pipeline.sql`. Physical names are assembled as
  `prefix + marker + canonical + suffix` (for example prefix `ope_`, marker
  `m_`, suffix `_tky` gives `ope_m_lineage_config_tky`).
- Wrote the master/transaction marker directly as an inline `'m_'` / `'t_'`
  literal in each table's SET line, since the marker rarely changes, while the
  environment-specific prefix and suffix stay as variables (default empty).
  The marker split is `m_` for the configuration and ledger tables (`config`,
  `execution_account_config`, `definition_registry`, `job_registry`) and `t_`
  for the derived analysis outputs (`direct_dependency`, `impact`,
  `diagnostic`); edit a single SET line to reclassify a table.
- Extended `render_dynamic_sql()` with a `repo_tables STRUCT` argument and
  seven fully qualified `__T_*__` placeholders (`__T_CONFIG__`,
  `__T_EXEC_ACCOUNT__`, `__T_DEF_REGISTRY__`, `__T_DIRECT_DEP__`,
  `__T_IMPACT__`, `__T_DIAGNOSTIC__`, `__T_JOB_REGISTRY__`).
- Converted every remaining static repository-table reference in
  `03_run_daily_lineage_pipeline.sql` to the template -> render -> unresolved
  placeholder ASSERT -> `EXECUTE IMMEDIATE` pattern with named `USING`
  parameters, including the STEP 3 changed-object loop (materialized into a
  temporary table so the `FOR ... IN` query stays static), the COMPLETED and
  non-publishable branches, the EXCEPTION replace/restore handler (with
  captured `@@error.*` values), the recursive impact rebuild, and the run and
  pipeline summaries. Repository DDL in `01_setup_lineage_environment.sql` now
  injects the configured names into its `EXECUTE IMMEDIATE FORMAT` statements.
- Fixed a pre-existing error surfaced on first execution: `ASSERT ... AS
  FORMAT(...)` is invalid because the assertion message must be a string
  literal (BigQuery: "Expected string literal but got keyword Format"). The two
  formatted assertions in the STEP 3 analysis loop (source-discovery status and
  the 900,000-byte scoped-metadata guard) now use `IF ... THEN RAISE USING
  MESSAGE = FORMAT(...); END IF;`, which is caught by the same per-object
  EXCEPTION handler. The identical construct still exists in
  `06_analyze_changed_objects.sql` (lines 302, 395) and
  `07_run_single_view_analysis.sql` (line 292) and will be fixed with the
  Phase 2 changes.
- Scope note: `04_validate_lineage_environment.sql`,
  `05_repository_integration_test.sql`, and
  `06_analyze_changed_objects.sql` still use the canonical names and are the
  next phase of this change.

# v1.5.0-031

- Changed 03, 06, and 07 to discover each SQL definition's physical Source
  names first, then pass only the matching `COLUMNS` and
  `COLUMN_FIELD_PATHS` Metadata rows to the JavaScript UDF.
- Added the `source_discovery_only` UDF option and
  `discoverPhysicalSourcesForBigQuery` bundle API.
- Retained PhysicalColumnResolver-compatible matching for fully qualified,
  dataset-qualified, and unqualified source names.
- Added a 900,000-byte preflight guard for the scoped Metadata JSON so an
  exceptionally wide single Source produces an explicit diagnostic instead of
  the BigQuery Script 1 MiB expression-limit error.

# v1.5.0-030

- Added `docs/REPOSITORY_TABLE_REFERENCE.md`, a column-level reference for all
  Repository tables, including direct-source and impacted-column semantics in
  `lineage_impact`.
- Replaced the sample product brand value `AUDEO` with `BrandXX`.

# v1.5.0-029

- Added `docs/UDF_BUNDLE_BUILD_PROCESS.md`, which documents the generation,
  verification, release, and optional deployment process for
  `lineage_udf_bundle.js`.
- Clarified that `scripts/build_udf.js` directly generates the bundle and
  `scripts/build_everything.js` orchestrates the release workflow.
- Synchronized package version metadata to `1.5.0-029`.

# v1.5.0-028

- Added physical-column lineage resolution for UNPIVOT-generated value and
  name columns.
- Added support for single-column and multiple-column UNPIVOT forms.
- Added parser support for `INCLUDE NULLS` and `EXCLUDE NULLS`.
- Excluded consumed UNPIVOT input columns from `SELECT *` expansion while
  preserving generated output columns.
- Added direct physical-source, CTE, wildcard, derived-expression, and Golden
  regression coverage for UNPIVOT.
- Changed the historical diagnostic-enrichment test to use a genuine missing
  physical column instead of relying on unsupported UNPIVOT semantics.
- Synchronized package version metadata to `1.5.0-028`.

# v1.5.0-027

- Added BigQuery-compatible PIVOT generated-column naming using
  `aggregate_prefix + "_" + pivot_column`.
- Added same-scope resolution for explicit references to PIVOT-generated
  columns.
- Added support for multiple prefixed aggregate expressions in one PIVOT.
- Added release and Golden regression coverage for aggregate prefixes,
  generated-column references, multiple aggregates, and compatibility with
  prefix-free PIVOT expressions.
- Added `sql/sample/02a_create_cost_measurement_view.sql` as an approximately
  500-line cost and performance measurement View.
- Changed `sql/maintenance/07_run_single_view_analysis.sql` to use the new cost
  measurement View by default.
- Synchronized package version metadata to `1.5.0-027`.

# v1.5.0-026

- Added `sql/maintenance/07_run_single_view_analysis.sql` for read-only,
  single-View UDF execution and script-level cost/performance measurement.
- Aligned the single-View physical-column metadata contract with the formal
  daily pipeline and standalone changed-object analysis.
- Removed eight obsolete `sql/bigquery` files tied to the retired staging,
  physical-column catalog, normalized publish, and duplicate test workflow.
- Updated the retained persistent-UDF redeployment and smoke-test helpers to
  use the current four-argument `analyze_lineage_json` contract and deployed
  environment defaults.
- Synchronized package version metadata to `1.5.0-026`.

# v1.5.0-025

- Changed `06_analyze_changed_objects.sql` to declare repository, target, region, and UDF identifiers at the top of the script.
- Added placeholder rendering and `EXECUTE IMMEDIATE` for target `INFORMATION_SCHEMA` references and persistent UDF invocation.
- Kept repository table access aligned with the declared repository project and dataset through `@@dataset_project_id` and `@@dataset_id`.
- Includes the v1.5.0-024 validation corrections: `routine_type = 'FUNCTION'` and C001 expected sales amount `129250`.

# v1.5.0-021

- Diagnosticへ`scope_type`を自動補完。
- `candidate_source_name(s)`と`resolved_source_name`を追加。
- `sql_context`を対象SELECT項目のAST Token範囲から生成。
- 診断補完の回帰テストを追加。

# v1.5.0-020

- Preserve `diagnostic_json` even when `compact_export = TRUE`.
- Suppress derived `LINEAGE_PARTIALLY_RESOLVED` warnings when the same unresolved dependency already has an ERROR diagnostic.
- Add scope and token location details to physical-column diagnostics.
- Verify `error_nodes_json` and compact diagnostics through regression tests.

## 1.5.0-019

- Added `DiagnosticEngine` as the central diagnostic policy and formatting component.
- Added common node, scope, token position, SQL fragment, SQL context, and original SQL fields.
- Added `error_nodes` to engine results and `error_nodes_json` to exported analysis rows.
- Added a dedicated `error_nodes_json` column to non-completed daily pipeline results.
- Added regression test `test_v1_5_0_019.js`.

## 1.5.0-018

- `EXPRESSION_SUBQUERY`内部の無名SELECT出力を`OUTPUT_COLUMN_NAME_UNRESOLVED`の対象外に変更。
- スカラ集約サブクエリと`EXISTS (SELECT 1 ...)`の回帰テストを追加。
- 外側の公開列名と物理カラムリネージは従来どおり保持。

## 1.5.0-017

- Added shared SELECT output-alias resolution for GROUP BY, HAVING, QUALIFY, and ORDER BY.
- Kept WHERE and JOIN ON from resolving SELECT output aliases.
- Promoted diagnostic output into the formal `03_run_daily_lineage_pipeline.sql`.
- Treats only `COMPLETED` as normal during stabilization and returns every other UDF result in the final SELECT.
- Moved generated JavaScript from `build` to `dist`.
- Moved BigQuery helper SQL from `javascript/bigquery` to `sql/bigquery`.
- Removed `javascript/legacy` and the separate debug pipeline.

# Changelog

## [1.5.0-016] - 2026-07-22

### Fixed

- Resolved fields referenced through a correlated `UNNEST` alias to the original physical STRUCT/ARRAY field path.
- Preserved support for conditionless correlated `LEFT JOIN UNNEST` and `ON TRUE`.
- Added the full UDF result JSON to the final debug result set when analysis is not publishable.

### Tests

- Added `test_v1_5_0_016.js` covering `CONTACTS.CONTACT_VALUE` resolution for both JOIN forms.
- Passed the 46-case Golden regression suite and bundle verification.

## 1.5.0-015 - 2026-07-22

- Allow conditionless `LEFT JOIN UNNEST(...)` only when the UNNEST expression is correlated to a previously visible FROM source.
- Preserve the ON/USING requirement for ordinary LEFT JOIN sources.
- Confirm explicit `ON TRUE` support for correlated LEFT JOIN UNNEST.
- Add parser regression test and sample View `v_customer_primary_contact_on_true`.


## [Unreleased]

### Fixed

- Moved per-object analysis variables into an outer `BEGIN` block.
- Wrapped the replace-and-restore operation in an inner `BEGIN ... EXCEPTION` block.
- Fixed `Unrecognized name: replacement_started` caused by BigQuery exception-handler variable scope.


### Changed

- Centralized every dynamic identifier substitution in the temporary SQL function `render_dynamic_sql()`.
- Removed intermediate identifier variables including `repository_identifier`, `target_identifier`, `target_project_identifier`, and `udf_identifier`.
- Standardized all dynamic SQL blocks to: template, render, unresolved-placeholder assertion, and execution.
- Continued to pass runtime values through `EXECUTE IMMEDIATE ... USING`.


### Fixed

- Fully qualified all three daily-pipeline `MERGE` targets with the `__REPOSITORY__` placeholder.
- Added `repository_identifier = repository_project_id || '.' || repository_dataset`.
- Added unresolved-placeholder assertions before repository `MERGE` execution.


### Changed

- Unified dynamic identifier construction in `03_run_daily_lineage_pipeline.sql` using named placeholders and `REPLACE()`.
- Added `__TARGET__`, `__TARGET_PROJECT__`, `__JOB_REGION__`, and `__UDF__` placeholders.
- Retained `USING` parameters for runtime values such as lookback days and UDF arguments.
- Added unresolved-placeholder assertions before every dynamic SQL execution.


### Changed

- `03_run_daily_lineage_pipeline.sql` now declares repository project, repository dataset, target project, target dataset, job region, UDF location, parser strict mode, and maximum impact rank at the beginning of the script.
- The daily pipeline no longer reads scalar environment settings from `lineage_config`.
- Repository tables use `@@dataset_project_id` and `@@dataset_id`; dynamic identifiers for metadata and UDF calls use `EXECUTE IMMEDIATE`.
- Scheduled Query and DAG service-account arrays remain managed in `lineage_execution_account_config`.


### Fixed

- Removed the unsupported `NOT NULL` constraint from the `ARRAY<STRING>` service account column. Non-empty arrays remain enforced by setup assertions and validation checks.

### Fixed

- Changed dynamic configuration reads from `SELECT AS STRUCT` to a single explicit `STRUCT(...)` column so `EXECUTE IMMEDIATE ... INTO config` receives exactly one column.

### Planned

- JavaScript source and regression fixtures
- Actual execution evidence
- Looker Studio operational dashboard
- Retention and cleanup policy
- CI workflow
- License selection

## [1.0.0-lts-udf.1] - 2026-07-21

### Added

- Recovered 23 JavaScript source files from canonical bundle source markers
- Formal source directories for AST, lexer, token reader, parsers, resolvers, exporter, and engine
- Reproducible UDF bundle build script
- Canonical legacy bundle behavior verification
- 46-case Golden parser and lineage regression suite
- Performance regression contract and runner
- BigQuery UDF smoke-test SQL assets
- Supported SQL coverage and regression test design documents

## [1.0.0-lts-docs.1] - 2026-07-21

### Added

- Environment setup SQL
- Sample environment SQL
- Integrated daily pipeline
- Validation SQL
- Repository integration test
- Changed-object analysis SQL
- Execution account configuration using `ARRAY<STRING>`
- Business requirements
- Architecture and system design
- SQL and UDF design
- Operation and troubleshooting guides
- Development guide
- ER diagram
- Initial ADR set

## 1.5.0-022

- Build Everything v1を追加。
- bundle生成、bundle検証、リリース回帰、成果物ステージング、ZIP生成を1コマンドに統合。
- `release_manifest.json`を追加し、version、SHA-256、テスト状態、成果物、デプロイ状態を記録。
- `--deploy`指定時のみGCSアップロードとBigQuery UDF更新を実行する安全な方式を採用。
- ZIPファイル名とトップレベルフォルダ名の一致を自動保証。

## 1.5.0-023

- Added `looker/sql/01_query_column_impact.sql`.
- Added `impact_type`, `dependency_usage_type`, and `dependency_path_display` to the downstream column impact report.
- Added `impacted_expression` to support manual impact review.
- Documented the current clause-level `usage_type` limitation.
